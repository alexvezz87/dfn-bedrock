<?php

/**
 * PHPUnit Bootstrap for Brain Monkey Testing
 */

require_once dirname(__DIR__) . '/vendor/autoload.php';

// Mock ABSPATH if not defined
if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}

// Inizializza Brain Monkey
Brain\Monkey\setUp();

// Nota: Brain Monkey setUp() viene chiamato di solito all'interno di ogni test,
// ma possiamo definire costanti globali qui se necessario.
