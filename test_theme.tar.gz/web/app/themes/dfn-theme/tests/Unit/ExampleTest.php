<?php

namespace DFN\Theme\Tests\Unit;

use PHPUnit\Framework\TestCase;
use Brain\Monkey;
use Brain\Monkey\Filters;

class ExampleTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        Monkey\setUp();
    }

    protected function tearDown(): void
    {
        Monkey\tearDown();
        parent::tearDown();
    }

    /**
     * Verifica che una action venga aggiunta correttamente.
     */
    public function test_add_action_example()
    {
        // Supponiamo di testare una funzione che registra un hook
        add_action('init', 'my_custom_function');

        // Verifichiamo che l'azione sia stata aggiunta
        $this->assertTrue(has_action('init', 'my_custom_function') !== false);
    }

    /**
     * Verifica il funzionamento di un filtro mockato.
     */
    public function test_filter_mocking()
    {
        Filters\expectApplied('my_custom_filter')
            ->once()
            ->with('original_value')
            ->andReturn('modified_value');

        $result = apply_filters('my_custom_filter', 'original_value');

        $this->assertEquals('modified_value', $result);
    }
}
