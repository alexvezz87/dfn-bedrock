<?php

/**
 * PHPStan Bootstrap File for FAI Prenotazioni
 * Defines core WordPress constants and setups.
 */

if (! defined('MINUTE_IN_SECONDS')) {
    define('MINUTE_IN_SECONDS', 60);
}
if (! defined('HOUR_IN_SECONDS')) {
    define('HOUR_IN_SECONDS', 3600);
}
if (! defined('DAY_IN_SECONDS')) {
    define('DAY_IN_SECONDS', 86400);
}
if (! defined('WEEK_IN_SECONDS')) {
    define('WEEK_IN_SECONDS', 604800);
}
if (! defined('YEAR_IN_SECONDS')) {
    define('YEAR_IN_SECONDS', 31536000);
}
