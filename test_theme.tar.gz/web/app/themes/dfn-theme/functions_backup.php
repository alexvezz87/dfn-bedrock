<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

if (!function_exists('chld_thm_cfg_locale_css')):
    function chld_thm_cfg_locale_css($uri)
    {
        if (empty($uri) && is_rtl() && file_exists(get_template_directory() . '/rtl.css')) {
            $uri = get_template_directory_uri() . '/rtl.css';
        }
        return $uri;
    }
endif;
add_filter('locale_stylesheet_uri', 'chld_thm_cfg_locale_css');

if (!function_exists('child_theme_configurator_css')):
    function child_theme_configurator_css()
    {
        wp_enqueue_style('chld_thm_cfg_child', trailingslashit(get_stylesheet_directory_uri()) . 'style.css', [ 'hello-elementor','hello-elementor','hello-elementor-theme-style' ]);
    }
endif;
add_action('wp_enqueue_scripts', 'child_theme_configurator_css', 10);

// END ENQUEUE PARENT ACTION

// Auto-completa l'ordine SOLO dopo aver ricevuto il pagamento effettivo
add_action('woocommerce_payment_complete', 'cv_auto_completa_ordini_pagati');
function cv_auto_completa_ordini_pagati($order_id)
{
    if (! $order_id) {
        return;
    }
    $order = wc_get_order($order_id);
    if ($order) {
        $order->update_status('completed');
    }
}

add_filter('woocommerce_order_button_text', 'misha_custom_button_text');
function misha_custom_button_text($button_text)
{
    return 'Effettua Prenotazione'; // new text is here
}

//add_action('woocommerce_checkout_update_order_review', 'forza_applicazione_coupon_email');

function forza_applicazione_coupon_email($post_data)
{
    parse_str($post_data, $form_data);

    if (!isset($form_data['billing_email'])) {
        return;
    }

    $email = sanitize_email($form_data['billing_email']);
    $coupon_code = 'SOCIO_FAI_NOVARA_2025'; // <-- il tuo codice reale

    // Imposta l'email direttamente nel cliente attivo
    WC()->customer->set_billing_email($email);
    WC()->customer->save(); // importante per forzare WooCommerce ad aggiornare il carrello

    // Ottieni il coupon e verifica le email autorizzate
    $coupon = new WC_Coupon($coupon_code);
    $allowed_emails = array_map('strtolower', $coupon->get_email_restrictions());

    if (empty($allowed_emails)) {
        wc_add_notice('❗ Il coupon non ha restrizioni email impostate.', 'notice');
        return;
    }

    if (in_array(strtolower($email), $allowed_emails)) {
        if (!WC()->cart->has_discount($coupon_code)) {
            WC()->cart->apply_coupon($coupon_code);
            //wc_add_notice('✅ Coupon applicato automaticamente.', 'success');
        }
    } else {
        if (WC()->cart->has_discount($coupon_code)) {
            WC()->cart->remove_coupon($coupon_code);
            wc_add_notice('❌ Coupon rimosso: email non autorizzata.', 'error');
        }
    }
}

function prodotto_condizionale_shortcode($atts)
{
    // 1. Estrazione e validazione dei parametri
    $atts = shortcode_atts(
        [
            'id' => 0,
        ],
        $atts,
        'prodotto_condizionale',
    );

    $product_id = intval($atts['id']);

    if ($product_id <= 0) {
        return '<p style="color:red;">Per favore, inserisci un ID prodotto valido nello shortcode.</p>';
    }

    $product = wc_get_product($product_id);

    if (! $product) {
        return '<p style="color:red;">Prodotto non trovato.</p>';
    }

    // 2. Recupero delle informazioni del prodotto
    $stock       = $product->get_stock_quantity();
    $is_in_stock = $product->is_in_stock();
    $price       = $product->get_price_html();
    $image       = $product->get_image('medium');

    // --- LOGICA VISITATORI LIVE (Solo per Candle Vibes 1627 di giorno) ---
    $show_viewers = false;
    $viewers = 0;

    if ($product_id === 1627 && $stock > 0) {
        $ora_attuale = (int) wp_date('H');
        if ($ora_attuale >= 8 && $ora_attuale < 22) {
            $show_viewers = true;
            $viewers = 12 + (intdiv((int) date('i'), 10) * 3) + ($stock % 10);
        }
    }

    // 3. Avvio del buffer di output
    ob_start();
    ?>
    
    <style>
        .custom-product form.cart {
            display: flex; flex-direction: row; justify-content: center; 
            align-items: center; gap: 15px; flex-wrap: wrap;
        }
        .custom-product form.cart .quantity { margin: 0; }
        .custom-product form.cart .quantity input.qty {
            width: 80px !important; min-width: 80px !important; height: 42px; 
            padding: 5px 10px; text-align: center; border: 1px solid #ccc; border-radius: 4px;
        }
        
        .cv-fomo-social {
            background: #fff3cd; border: 1px solid #ffeeba; color: #856404;
            padding: 10px 15px; border-radius: 5px; margin: 15px 0 10px 0; 
            font-size: 14px; line-height: 1.4;
        }
        
        /* Badge per il pallino verde (Solo 1627) */
        .cv-status-badge {
            color: #16a34a; font-weight: bold; font-size: 16px;
            display: flex; align-items: center; justify-content: center;
            margin-top: 10px; margin-bottom: 20px;
        }
        .cv-green-dot {
            display: inline-block; width: 12px; height: 12px; 
            background-color: #16a34a; border-radius: 50%; 
            margin-right: 8px;
            box-shadow: 0 0 0 0 rgba(22, 163, 74, 0.7);
            animation: cv-pulse-green 2s infinite;
        }
        
        /* Testo stock numerico (Altri prodotti) */
        .cv-stock-numeric {
            color: #16a34a; font-weight: bold; font-size: 16px;
            margin-top: 10px; margin-bottom: 20px; text-align: center;
        }

        @keyframes cv-pulse-green {
            0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(22, 163, 74, 0.7); }
            70% { transform: scale(1); box-shadow: 0 0 0 8px rgba(22, 163, 74, 0); }
            100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(22, 163, 74, 0); }
        }
    </style>

    <div class="prodotti-custom-container" style="display: flex; flex-direction: column;">
        <div class="custom-product" style="display: flex; flex-direction: column; align-items: center; padding: 20px; border: 1px solid #eee; margin-bottom: 10px; margin: auto; background: rgba(255,255,255,0.7); max-width:400px;">
            
            <?php echo $image; ?>
            
            <div class="price" style="font-weight: 600; font-size: 24px; margin-top: 15px;">
                <?php echo wp_kses_post($price); ?>
            </div>

            <?php if (! $is_in_stock || $stock <= 0) : ?>
                <div class="stock-status" style="color: #d63638; font-weight: bold; margin-top: 15px; margin-bottom: 15px; font-size:18px;">
                    ❌ POSTI ESAURITI
                </div>
            <?php else : ?>
                
                <?php if ($show_viewers) : ?>
                    <div class="cv-fomo-social">
                        🔥 <strong>Molto richiesto!</strong><br>
                        <?php echo $viewers; ?> persone stanno valutando questo evento proprio ora.
                    </div>
                <?php endif; ?>
                
                <?php if ($product_id === 1627) : ?>
                    <div class="cv-status-badge">
                        <span class="cv-green-dot"></span> Posti disponibili
                    </div>
                <?php else : ?>
                    <div class="cv-stock-numeric">
                        <?php echo esc_html($stock); ?> posti disponibili
                    </div>
                <?php endif; ?>

                <form class="cart" method="post" action="<?php echo esc_url(wc_get_cart_url()); ?>">
                    <input type="hidden" name="add-to-cart" value="<?php echo esc_attr($product_id); ?>">
                    
                    <?php woocommerce_quantity_input([], $product, true); ?>
                    
                    <button type="submit" class="button alt">Aggiungi al carrello</button>
                </form>
            <?php endif; ?>

        </div>
    </div>

    <?php
    return ob_get_clean();
}

// Registrazione dello shortcode
add_shortcode('prodotto_condizionale', 'prodotto_condizionale_shortcode');

/**
 * 1. AGGIUNGE IL BOTTONE "HUB BIGLIETTI" ALLA MAIL (SOSTITUISCE I QR IN PILA)
 */
add_action('woocommerce_email_order_details', 'cv_aggiungi_link_hub_email', 5, 4);
function cv_aggiungi_link_hub_email($order, $sent_to_admin, $plain_text, $email)
{
    if ($sent_to_admin || $plain_text || ! $order->has_status([ 'processing', 'completed' ])) {
        return;
    }

    $order_id = $order->get_id();
    $tot_biglietti = 0;
    foreach ($order->get_items() as $item) {
        $tot_biglietti += $item->get_quantity();
    }

    // Token sicuro per l'Hub
    $hub_token = hash_hmac('sha256', $order->get_order_key() . '_hub', wp_salt('nonce'));
    $hub_url = site_url('/?cv_hub=1&order_id=' . $order_id . '&token=' . $hub_token);

    echo '<div style="text-align:center; margin: 30px 0; padding: 20px; border: 2px dashed #e5e5e5; border-radius: 10px; background-color: #f9f9f9;">';
    echo '<h2 style="margin-top:0; color: #ff6600;">I tuoi Biglietti (' . $tot_biglietti . ')</h2>';
    echo '<p style="font-size: 16px;">Clicca sul pulsante qui sotto per accedere al tuo Botteghino. Potrai <strong>stamparli su carta</strong> o <strong>inviarli singolarmente</strong> ai tuoi amici su WhatsApp.</p>';
    echo '<a href="' . esc_url($hub_url) . '" style="background-color: #2271b1; color: white; padding: 15px 25px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block; margin-top: 10px; font-size:16px;">🎟️ Gestisci e Stampa Biglietti</a>';
    echo '</div>';
}


/**
 * 2. GESTISCE LA LETTURA DEL QR CODE E IL CHECK-IN (SISTEMA DI EMERGENZA/FALLBACK)
 */
add_action('template_redirect', 'cv_gestisci_scansione_qr');
function cv_gestisci_scansione_qr()
{
    if (isset($_GET['cv_checkin']) && isset($_GET['order_id']) && isset($_GET['token']) && isset($_GET['ticket'])) {

        $order_id     = intval($_GET['order_id']);
        $ticket_index = intval($_GET['ticket']);
        $token        = sanitize_text_field($_GET['token']);

        if (! is_user_logged_in() || ! current_user_can('cv_use_scanner')) {
            wp_die('Accesso negato. Devi effettuare il login come Verificatore o Staff prima di scansionare i biglietti.', 'Errore Autorizzazione', [ 'response' => 403 ]);
        }

        $order = wc_get_order($order_id);
        if (! $order) {
            wp_die('Ordine non trovato nel database.', 'Errore', [ 'response' => 404 ]);
        }

        if (! $order->has_status([ 'processing', 'completed' ])) {
            wp_die('Questo ordine risulta annullato, rimborsato o non valido. Il biglietto NON è utilizzabile.', 'Ordine Non Valido', [ 'response' => 403 ]);
        }

        $expected_token = hash_hmac('sha256', $order->get_order_key() . '_ticket_' . $ticket_index, wp_salt('nonce'));
        if (! hash_equals($expected_token, $token)) {
            wp_die('Token di sicurezza non valido o manomesso.', 'Errore Sicurezza', [ 'response' => 403 ]);
        }

        $lock_key = 'cv_ticket_lock_' . $order_id . '_' . $ticket_index;
        if (get_transient($lock_key)) {
            wp_die('Scansione in corso da un altro operatore. Riprova tra qualche secondo.', 'Attendi', [ 'response' => 429 ]);
        }
        set_transient($lock_key, 1, 5);

        $meta_key = '_cv_ticket_validato_' . $ticket_index;
        $gia_entrato = $order->get_meta($meta_key);
        $status_feedback = '';

        $tot_biglietti_ordine = 0;
        foreach ($order->get_items() as $item) {
            $tot_biglietti_ordine += $item->get_quantity();
        }

        // Recupera il Tavolo se assegnato
        $tavolo_assegnato = $order->get_meta('_cv_assigned_table');

        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Scansione Biglietto</title><style>body{font-family:sans-serif; text-align:center; padding:20px; background:#f0f0f1; margin:0; display:flex; flex-direction:column; justify-content:center; min-height:100vh;} .card{background:#fff; padding:30px; border-radius:10px; box-shadow:0 4px 10px rgba(0,0,0,0.1);} h1{font-size:32px; margin-bottom:10px;} .btn{display:inline-block; margin-top:30px; padding:15px 30px; background:#2271b1; color:#fff; text-decoration:none; border-radius:5px; font-weight:bold; font-size:18px;}</style></head><body>';
        echo '<div class="card">';

        if ($gia_entrato === 'yes') {
            $status_feedback = 'error';
            $orario = $order->get_meta($meta_key . '_orario');
            $operatore_id = $order->get_meta($meta_key . '_operatore');
            $nome_operatore = 'Utente Sconosciuto';
            if ($operatore_id) {
                $user_info = get_userdata($operatore_id);
                if ($user_info) {
                    $nome_operatore = $user_info->display_name;
                }
            }

            echo '<h1 style="color:#d63638;">❌ GIÀ ENTRATO</h1>';
            echo '<p style="font-size:18px;">Il biglietto <strong>' . $ticket_index . ' di ' . $tot_biglietti_ordine . '</strong> (Ordine #' . $order_id . ') è già stato validato.</p>';
            echo '<p style="color:#666;">Data scansione:<br><strong style="color:#333;">' . esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($orario))) . '</strong></p>';
            echo '<p style="color:#666; margin-top:15px;">Validato da:<br><strong style="color:#333;">' . esc_html($nome_operatore) . '</strong></p>';

        } else {
            $status_feedback = 'success';
            $order->update_meta_data($meta_key, 'yes');
            $order->update_meta_data($meta_key . '_orario', current_time('mysql'));
            $order->update_meta_data($meta_key . '_operatore', get_current_user_id());
            $order->save();

            $nome_cliente = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();

            echo '<h1 style="color:#00a32a;">✅ ACCESSO VALIDO</h1>';
            echo '<h2 style="font-size:28px; margin:20px 0;">' . esc_html($nome_cliente) . '</h2>';

            if ($tavolo_assegnato) {
                echo '<div style="background:#fff3cd; border:2px solid #ffc107; padding:15px; border-radius:8px; font-size:22px; color:#856404; font-weight:bold; margin-bottom:15px; text-transform:uppercase;">🍽️ TAVOLO:<br>' . esc_html($tavolo_assegnato) . '</div>';
            }

            echo '<div style="background:#eaf7ea; border:2px solid #00a32a; padding:15px; border-radius:8px; font-size:20px;">';
            echo '<strong>Ingresso per 1 Persona</strong><br><small style="font-size:16px;">(Biglietto ' . $ticket_index . ' di ' . $tot_biglietti_ordine . ')</small>';
            echo '</div>';
            echo '<p style="margin-top:20px; color:#666;">Ordine #' . $order_id . '</p>';
        }

        delete_transient($lock_key);

        echo '<a href="' . admin_url('admin.php?page=cv-scanner-live') . '" class="btn">Torna allo Scanner</a>';
        echo '</div>';
        echo '<script>document.addEventListener("DOMContentLoaded", function() { var status = "' . $status_feedback . '"; if (navigator.vibrate) { if (status === "success") { navigator.vibrate(200); } else { navigator.vibrate([500, 200, 500]); } } try { var AudioContext = window.AudioContext || window.webkitAudioContext; if (AudioContext) { var ctx = new AudioContext(); var osc = ctx.createOscillator(); var gainNode = ctx.createGain(); osc.connect(gainNode); gainNode.connect(ctx.destination); if (status === "success") { osc.type = "sine"; osc.frequency.setValueAtTime(800, ctx.currentTime); gainNode.gain.setValueAtTime(0.1, ctx.currentTime); osc.start(); osc.stop(ctx.currentTime + 0.15); } else { osc.type = "sawtooth"; osc.frequency.setValueAtTime(150, ctx.currentTime); gainNode.gain.setValueAtTime(0.2, ctx.currentTime); osc.start(); osc.stop(ctx.currentTime + 0.5); } } } catch(e) { } });</script></body></html>';
        exit;
    }
}

/**
 * 3. CREA IL PANNELLO DI REPORTISTICA, CASSA MANUALE E ASSEGNAZIONE TAVOLI INTELLIGENTE
 */
add_action('admin_menu', 'cv_aggiungi_pagina_report_checkin');
function cv_aggiungi_pagina_report_checkin()
{
    add_submenu_page(
        'woocommerce',
        'Report Check-in Eventi',
        'Check-in Eventi',
        'manage_woocommerce',
        'cv-report-checkin',
        'cv_render_pagina_report_checkin',
    );
}

// L'INTERFACCIA "SCHELETRO" E IL BOTTONE MAGICO
function cv_render_pagina_report_checkin()
{
    if (! current_user_can('manage_woocommerce')) {
        return;
    }

    $selected_event = isset($_GET['event_id']) ? intval($_GET['event_id']) : 0;
    $products = wc_get_products([ 'limit' => -1, 'status' => 'publish', 'return' => 'objects' ]);

    // Controlliamo se è l'evento con la mappa tavoli (Delitto in Cupola)
    $is_delitto = ($selected_event === 1639);

    echo '<div class="wrap"><h1 class="wp-heading-inline">Report & Cassa Check-in</h1>';
    echo '<p style="font-size:15px; color:#555;">Seleziona un evento per monitorare gli accessi in tempo reale, validare manualmente i biglietti e gestire l\'evento.</p>';

    echo '<form method="GET" style="margin-top:20px; margin-bottom: 20px; background:#fff; padding:15px; border:1px solid #ccd0d4; border-radius:4px; display:inline-block;">';
    echo '<input type="hidden" name="page" value="cv-report-checkin">';
    echo '<label style="font-weight:bold; margin-right:10px;">Seleziona l\'evento:</label>';
    echo '<select name="event_id" id="cv-event-selector" style="min-width:300px;"><option value="">-- Seleziona un Evento --</option>';
    foreach ($products as $product) {
        echo '<option value="' . esc_attr($product->get_id()) . '" ' . selected($selected_event, $product->get_id(), false) . '>' . esc_html($product->get_name()) . '</option>';
    }
    echo '</select><button type="submit" class="button button-primary" style="margin-left:10px;">Carica Partecipanti</button></form>';

    if ($selected_event > 0) {
        echo '<style>
            @keyframes cvSpin { 100% { transform: rotate(360deg); } }
            .cv-is-syncing { animation: cvSpin 1s linear infinite; color: #2271b1 !important; }
            .cv-table-loading { opacity: 0.5; pointer-events: none; }
            .cv-history-item { padding: 8px; border-bottom: 1px solid #eee; font-size: 14px; }
            .cv-history-item:last-child { border-bottom: none; }
            
            /* STILI DEFINITIVI PER LA STAMPA DELLA MAPPA TAVOLI (Anti-Bug Scrollbar) */
            @media print {
                body * { visibility: hidden; }
                #cv-table-map-modal, #cv-table-map-modal * { visibility: visible; }
                
                #cv-table-map-modal { 
                    position: absolute !important; left: 0 !important; top: 0 !important; 
                    width: 100% !important; height: auto !important; min-height: 100% !important; 
                    background: #fff !important; 
                    align-items: flex-start !important; 
                    overflow: visible !important;
                }
                
                #cv-table-map-modal .cv-modal-content { 
                    box-shadow: none !important; border: none !important; 
                    width: 100% !important; max-width: 100% !important; padding: 0 !important; 
                    max-height: none !important; height: auto !important; 
                    overflow: visible !important; background: #fff !important;
                }
                
                #cv-table-map-content { overflow: visible !important; height: auto !important; }
                .cv-no-print { display: none !important; }
                
                .cv-table-grid { display: block !important; } 
                .cv-table-card { border: 2px solid #000 !important; page-break-inside: avoid !important; break-inside: avoid !important; margin-bottom: 25px !important; width: 100% !important; }
            }
        </style>';

        // DASHBOARD RIASSUNTIVA A 4 CELLE
        echo '<div style="background:#fff; border-left:4px solid #2271b1; padding:20px; margin-bottom:20px; box-shadow:0 1px 1px rgba(0,0,0,.04); max-width: 1000px; display:flex; justify-content:space-between; align-items:center; flex-wrap: wrap; gap: 20px;">';

        echo '<div style="flex-grow:1;">';
        echo '<h2 style="margin-top:0; display:flex; align-items:center; font-size:18px;">Riepilogo Ingressi <span id="cv-sync-icon" class="dashicons dashicons-update" style="display:none; margin-left:10px; color:#888;"></span></h2>';
        echo '<div style="display:flex; gap:30px; margin-top:15px; flex-wrap:wrap;">';
        echo '<div style="background:#f0f6fc; padding:10px 20px; border-radius:8px; border:1px solid #c8d7e1; min-width:120px;"><span style="font-size:12px; color:#555; text-transform:uppercase; font-weight:bold;">Venduti</span><br><strong style="font-size:32px; color:#2271b1;" id="cv-tot-venduti">-</strong></div>';
        echo '<div style="background:#eaf7ea; padding:10px 20px; border-radius:8px; border:1px solid #c3e6c3; min-width:120px;"><span style="font-size:12px; color:#555; text-transform:uppercase; font-weight:bold;">Entrati (Check-in)</span><br><strong style="color:#16a34a; font-size:32px;" id="cv-tot-checkin">-</strong></div>';
        echo '<div style="background:#fef2f2; padding:10px 20px; border-radius:8px; border:1px solid #fecaca; min-width:120px;"><span style="font-size:12px; color:#555; text-transform:uppercase; font-weight:bold;">In Attesa</span><br><strong style="color:#d63638; font-size:32px;" id="cv-tot-residui">-</strong></div>';
        echo '<div style="background:#fffbeb; padding:10px 20px; border-radius:8px; border:1px solid #fde68a; min-width:120px;"><span style="font-size:12px; color:#555; text-transform:uppercase; font-weight:bold;">Posti Liberi</span><br><strong style="color:#d97706; font-size:32px;" id="cv-tot-liberi">-</strong></div>';
        echo '</div></div>';

        echo '<div style="text-align:right; border-left: 1px solid #eee; padding-left: 20px; min-width: 250px;">';

        if ($is_delitto) {
            echo '<button id="cv-auto-assign-tables-btn" class="button" style="background:#10b981; color:#fff; border-color:#10b981; font-size: 14px; padding: 5px 15px; margin-bottom: 8px; display:block; width:100%;">🪄 Smistamento Automatico</button>';
            echo '<button id="cv-show-map-btn" class="button" style="background:#8b5cf6; color:#fff; border-color:#8b5cf6; font-size: 14px; padding: 5px 15px; margin-bottom: 8px; display:block; width:100%;">🗺️ Mappa Tavoli (Stampa)</button>';
        }

        echo '<button id="cv-send-reminders-btn" class="button button-primary" style="background:#ff6600; border-color:#ff6600; font-size: 14px; padding: 5px 15px; display:block; width:100%;">📧 Invia Reminder a Tutti</button>';
        echo '</div>';
        echo '</div>';

        // BARRA DI RICERCA + FILTRI DI STATO
        echo '<div style="margin: 20px 0; display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:15px;">';
        echo '<div style="display:flex; gap:10px; flex:1; max-width:600px;">';
        echo '<input type="text" id="cv-search-table" placeholder="🔍 Cerca cliente o numero..." style="width:100%; max-width:300px; padding:0 15px; border-radius:4px; border:1px solid #8c8f94; font-size:15px; height:40px;">';
        echo '<select id="cv-filter-status" style="padding:0 15px; border-radius:4px; border:1px solid #8c8f94; font-size:15px; height:40px; color:#333; font-weight:600;">
                <option value="all">📊 Tutti gli stati</option>
                <option value="pending">🔴 Da validare</option>
                <option value="partial">🟠 In validazione</option>
                <option value="complete">🟢 Validati</option>
              </select>';
        echo '</div>';
        echo '<div id="cv-pagination-top" style="display:flex; gap:5px; align-items:center;"></div>';
        echo '</div>';

        $colspan = $is_delitto ? 11 : 10;
        $colonna_tavolo = $is_delitto ? '<th style="background:#fff9e6; text-align:center;">Tavolo (Modificabile)</th>' : '';

        echo '<table class="wp-list-table widefat fixed striped" style="margin-top: 10px; border-bottom: 1px solid #c3c4c7; transition: opacity 0.2s;">';
        echo '<thead><tr><th>Ordine #</th><th>Cliente</th><th>Qualifica</th><th>Telefono</th><th>Biglietti</th>' . $colonna_tavolo . '<th>Stato Arrivi</th><th>Validato da</th><th style="background:#eaf7ea; text-align:center;">Azioni Cassa</th><th style="background:#eef6fc; text-align:center;">Messaggi</th><th style="background:#f6f7f7; text-align:center;">Storico</th></tr></thead>';
        echo '<tbody id="cv-report-tbody"><tr><td colspan="' . $colspan . '" style="text-align:center; padding:30px;">⏳ Caricamento dati in corso...</td></tr></tbody></table>';

        echo '<div id="cv-pagination-bottom" style="display:flex; gap:5px; align-items:center; justify-content:center; margin-top:20px;"></div>';

        // POPUP 1: CASSA
        echo '<div id="cv-cassa-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.7); z-index:999999; align-items:center; justify-content:center;">
            <div style="background:#fff; padding:25px; border-radius:10px; width:90%; max-width:450px; box-shadow:0 10px 30px rgba(0,0,0,0.4); max-height:85vh; display:flex; flex-direction:column;">
                <h2 style="margin-top:0; font-size:22px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Cassa Check-in</h2>
                <p style="font-size:16px;">Cliente: <strong id="cv-modal-cliente-name" style="color:#2271b1;"></strong></p>
                <div id="cv-modal-buttons-area" style="flex-grow:1; overflow-y:auto; margin: 15px 0; padding-right: 5px;"></div>
                <button type="button" class="button cv-close-modal-btn" style="text-align:center; width:100%; padding: 10px; height: auto; font-size: 16px;">Chiudi Finestra</button>
            </div>
        </div>';

        // POPUP 2: STORICO
        echo '<div id="cv-history-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.7); z-index:999999; align-items:center; justify-content:center;">
            <div style="background:#fff; padding:25px; border-radius:10px; width:90%; max-width:500px; box-shadow:0 10px 30px rgba(0,0,0,0.4); max-height:85vh; display:flex; flex-direction:column;">
                <h2 style="margin-top:0; font-size:22px; border-bottom: 2px solid #eee; padding-bottom: 10px;">📜 Log Operazioni Cliente</h2>
                <p style="font-size:16px;">Ordine Cliente: <strong id="cv-history-cliente-name" style="color:#2271b1;"></strong></p>
                <div id="cv-history-content-area" style="flex-grow:1; overflow-y:auto; margin: 10px 0; padding:10px; background:#f9f9f9; border:1px solid #ddd; border-radius:5px;"></div>
                <button type="button" class="button cv-close-modal-btn" style="text-align:center; width:100%; padding: 10px; height: auto; font-size: 16px; margin-top:10px;">Chiudi Log</button>
            </div>
        </div>';

        // POPUP 3: MAPPA TAVOLI
        echo '<div id="cv-table-map-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); z-index:999999; align-items:center; justify-content:center;">
            <div class="cv-modal-content" style="background:#f0f0f1; padding:30px; border-radius:10px; width:95%; max-width:1200px; box-shadow:0 15px 40px rgba(0,0,0,0.5); max-height:90vh; display:flex; flex-direction:column;">
                <div class="cv-no-print" style="display:flex; justify-content:space-between; align-items:center; border-bottom:2px solid #ddd; padding-bottom:15px; margin-bottom:20px;">
                    <h2 style="margin:0; font-size:26px;">🗺️ Disposizione Tavoli in Sala</h2>
                    <div>
                        <button class="button cv-print-map-btn" style="background:#8b5cf6; color:white; border-color:#8b5cf6; font-size:16px; margin-right:10px;">🖨️ Stampa Foglio Sala</button>
                        <button class="button cv-close-modal-btn" style="font-size:16px;">❌ Chiudi</button>
                    </div>
                </div>
                <div id="cv-table-map-content" style="flex-grow:1; overflow-y:auto; padding-right:10px;">
                    <div style="text-align:center; padding:50px;">⏳ Generazione mappa in corso...</div>
                </div>
            </div>
        </div>';

        // JS CLIENT-SIDE
        echo '<script>
            jQuery(document).ready(function($) {
                var eventId = ' . $selected_event . ';
                var currentPage = 1;
                var currentSearch = "";
                var currentFilter = "all"; 
                var needsReload = false;
                var ajaxNonce = "' . esc_js(wp_create_nonce('cv_fetch_report_nonce')) . '";
                var manualNonce = "' . esc_js(wp_create_nonce('cv_manual_checkin_nonce')) . '";
                var reminderNonce = "' . esc_js(wp_create_nonce('cv_reminder_nonce')) . '";
                var assignTableNonce = "' . esc_js(wp_create_nonce('cv_assign_table_nonce')) . '";

                function fetchReportData(isSilent) {
                    if ($("#cv-cassa-modal").is(":visible") || $("#cv-history-modal").is(":visible") || $("#cv-table-map-modal").is(":visible")) return; 
                    $("#cv-sync-icon").show().addClass("cv-is-syncing");
                    if (!isSilent) $("#cv-report-tbody").addClass("cv-table-loading");

                    $.post(ajaxurl, {
                        action: "cv_fetch_report_data", security: ajaxNonce, event_id: eventId, page: currentPage, search: currentSearch, filter_status: currentFilter
                    }, function(response) {
                        $("#cv-sync-icon").removeClass("cv-is-syncing").hide();
                        $("#cv-report-tbody").removeClass("cv-table-loading");
                        if (response.success) {
                            $("#cv-tot-venduti").text(response.data.tot_venduti);
                            $("#cv-tot-checkin").text(response.data.tot_checkin);
                            $("#cv-tot-residui").text(response.data.tot_residui); 
                            $("#cv-tot-liberi").text(response.data.tot_rimanenti); // Popola i posti liberi
                            $("#cv-report-tbody").html(response.data.html_table_rows);
                            $("#cv-pagination-top, #cv-pagination-bottom").html(response.data.html_pagination);
                        }
                    });
                }

                fetchReportData(false);
                setInterval(function() { fetchReportData(true); }, 60000);

                var searchTimeout;
                $("#cv-search-table").on("input", function() {
                    clearTimeout(searchTimeout); currentSearch = $(this).val(); currentPage = 1; 
                    searchTimeout = setTimeout(function() { fetchReportData(false); }, 500);
                });
                
                $("#cv-filter-status").on("change", function() {
                    currentFilter = $(this).val(); 
                    currentPage = 1; 
                    fetchReportData(false);
                });

                $(document).on("click", ".cv-page-btn", function(e) {
                    e.preventDefault(); currentPage = $(this).data("page"); fetchReportData(false);
                });

                $(document).on("click", ".cv-open-popup-btn", function(e) {
                    e.preventDefault(); needsReload = false;
                    $("#cv-modal-cliente-name").text($(this).data("cliente"));
                    $("#cv-modal-buttons-area").html($(this).siblings(".cv-popup-data-container").html());
                    $("#cv-cassa-modal").css("display", "flex");
                });

                $(document).on("click", ".cv-open-history-btn", function(e) {
                    e.preventDefault();
                    $("#cv-history-cliente-name").text($(this).data("cliente"));
                    $("#cv-history-content-area").html($(this).siblings(".cv-history-data-container").html());
                    $("#cv-history-modal").css("display", "flex");
                });

                $("#cv-show-map-btn").on("click", function(e) {
                    e.preventDefault();
                    $("#cv-table-map-modal").css("display", "flex");
                    $("#cv-table-map-content").html("<div style=\'text-align:center; padding:50px; font-size:18px;\'>⏳ Generazione mappa in corso...</div>");
                    
                    $.post(ajaxurl, { action: "cv_fetch_table_map", security: assignTableNonce, event_id: eventId }, function(response) {
                        if(response.success) {
                            $("#cv-table-map-content").html(response.data);
                        } else {
                            $("#cv-table-map-content").html("<div style=\'color:red; text-align:center;\'>Errore caricamento mappa.</div>");
                        }
                    });
                });

                $(".cv-print-map-btn").on("click", function(e) { e.preventDefault(); window.print(); });

                function closeModals() {
                    $("#cv-cassa-modal, #cv-history-modal, #cv-table-map-modal").hide();
                    if (needsReload) { fetchReportData(false); }
                    $("#cv-cassa-modal .cv-close-modal-btn").text("Chiudi Finestra"); 
                }
                $(".cv-close-modal-btn").on("click", closeModals);
                $("#cv-cassa-modal, #cv-history-modal, #cv-table-map-modal").on("click", function(e) { if (e.target === this) closeModals(); });

                $("#cv-report-tbody").on("change", ".cv-table-selector", function() {
                    var select = $(this); var orderId = select.data("order"); var newTable = select.val();
                    select.css("opacity", "0.5");
                    $.post(ajaxurl, { action: "cv_manual_assign_table", security: assignTableNonce, order_id: orderId, table: newTable }, function(response) {
                        select.css("opacity", "1");
                        if(!response.success) alert("Errore nel salvataggio del tavolo.");
                    });
                });

                $("#cv-auto-assign-tables-btn").on("click", function(e) {
                    e.preventDefault();
                    if(!confirm("⚠️ Vuoi avviare lo smistamento automatico dei tavoli?\n\nQuesto ricalcolerà i posti raggruppando i clienti in modo intelligente e mescolerà l\'ordine di base. Se premi questo pulsante, eventuali modifiche manuali fatte finora verranno sovrascritte!")) return;
                    var btn = $(this); var originalText = btn.text(); btn.prop("disabled", true).text("⏳ Calcolo algoritmo in corso...");
                    $.post(ajaxurl, { action: "cv_auto_assign_tables", security: assignTableNonce, event_id: eventId }, function(response) {
                        if(response.success) { alert("✅ Smistamento tavoli completato con successo!"); fetchReportData(false); } 
                        else { alert("❌ Errore: " + response.data); }
                        btn.prop("disabled", false).text(originalText);
                    }).fail(function() { alert("❌ Errore di rete."); btn.prop("disabled", false).text(originalText); });
                });

                $("#cv-modal-buttons-area").on("click", ".cv-manual-checkin-btn", function(e) {
                    e.preventDefault(); var btn = $(this); var orderId = btn.data("order"); var ticketIdx = btn.data("ticket");
                    btn.prop("disabled", true).css("opacity", "0.5").text("⏳ Elaborazione...");
                    $.post(ajaxurl, { action: "cv_process_manual_checkin", security: manualNonce, order_id: orderId, ticket: ticketIdx }, function(response) {
                        if(response.success) {
                            needsReload = true;
                            var successHtml = \'<div style="margin-bottom:8px; padding:10px; background:#eaf7ea; color:#166534; border: 1px solid #c3e6c3; border-radius: 4px; display:flex; justify-content:space-between; align-items:center;"><span>✅ Biglietto \' + ticketIdx + \' validato</span><button class="button cv-undo-checkin-btn" data-order="\' + orderId + \'" data-ticket="\' + ticketIdx + \'" style="color:#d63638; border-color:#d63638; padding:0 8px; min-height:26px; line-height:24px;">Annulla</button></div>\';
                            btn.replaceWith(successHtml);
                            $("#cv-cassa-modal .cv-close-modal-btn").text("🔄 Chiudi e Aggiorna Tabella");
                        } else { alert("Errore: " + response.data); btn.prop("disabled", false).css("opacity", "1").text("✔️ Valida Biglietto " + ticketIdx); }
                    });
                });

                $("#cv-modal-buttons-area").on("click", ".cv-undo-checkin-btn", function(e) {
                    e.preventDefault(); 
                    if(!confirm("Vuoi davvero annullare la validazione di questo biglietto? Tornerà ad essere valido per l\'ingresso.")) return;
                    var btn = $(this); var orderId = btn.data("order"); var ticketIdx = btn.data("ticket"); var wrapper = btn.closest("div");
                    btn.prop("disabled", true).text("⏳...");
                    $.post(ajaxurl, { action: "cv_process_undo_checkin", security: manualNonce, order_id: orderId, ticket: ticketIdx }, function(response) {
                        if(response.success) {
                            needsReload = true;
                            wrapper.replaceWith(\'<button class="button cv-manual-checkin-btn" data-order="\' + orderId + \'" data-ticket="\' + ticketIdx + \'" style="margin-bottom:8px; display:block; width:100%; border-color:#00a32a; color:#00a32a; height: 40px; cursor:pointer;">✔️ Valida Biglietto \' + ticketIdx + \'</button>\');
                            $("#cv-cassa-modal .cv-close-modal-btn").text("🔄 Chiudi e Aggiorna Tabella");
                        } else { alert("Errore: " + response.data); btn.prop("disabled", false).text("Annulla"); }
                    }).fail(function() { alert("Errore di rete."); btn.prop("disabled", false).text("Annulla"); });
                });

                $("#cv-send-reminders-btn").on("click", function(e) {
                    e.preventDefault();
                    if(!confirm("Sei sicuro di voler inviare l\'email di promemoria a tutti gli acquirenti? L\'invio avverrà in automatico a blocchi di 5 per garantire la massima sicurezza del server.")) return;
                    var btn = $(this); var originalText = btn.text(); btn.prop("disabled", true); var totalSent = 0;
                    function inviaLotto() {
                        btn.text("⏳ Invio in corso (" + totalSent + " inviate)... non chiudere!");
                        $.post(ajaxurl, { action: "cv_send_event_reminders", security: reminderNonce, event_id: eventId }, function(response) {
                            if(response.success) {
                                totalSent += response.data.sent;
                                if (response.data.has_more) { inviaLotto(); } 
                                else {
                                    if(totalSent > 0) alert("✅ Operazione completata! Inviate in totale " + totalSent + " email.");
                                    else alert("✅ Nessuna email inviata. Tutti l\'hanno già ricevuta.");
                                    btn.prop("disabled", false).text(originalText);
                                }
                            } else { alert("❌ Errore: " + response.data); btn.prop("disabled", false).text(originalText); }
                        }).fail(function() { alert("❌ Errore di rete. L\'invio si è interrotto a " + totalSent + " email."); btn.prop("disabled", false).text(originalText); });
                    }
                    inviaLotto();
                });

                $("#cv-report-tbody").on("click", ".cv-single-reminder-btn", function(e) {
                    e.preventDefault();
                    var btn = $(this); var orderId = btn.data("order");
                    if(!confirm("Inviare la mail di promemoria a questo specifico cliente?")) return;
                    var originalText = btn.text(); btn.prop("disabled", true).css("opacity", "0.5").text("⏳...");
                    $.post(ajaxurl, { action: "cv_send_event_reminders", security: reminderNonce, order_id: orderId }, function(response) {
                        if(response.success) {
                            btn.css({"background":"#eaf7ea", "color":"#166534", "border":"1px solid #c3e6c3", "opacity":"1"}).text("✅ Inviato!");
                            setTimeout(function(){ btn.css({"background":"", "color":"", "border":""}).text("📧 Reinvia Reminder"); }, 3000);
                        } else { alert("❌ Errore: " + response.data); btn.prop("disabled", false).css("opacity", "1").text(originalText); }
                    }).fail(function() { alert("❌ Errore di rete."); btn.prop("disabled", false).css("opacity", "1").text(originalText); });
                });
            });
        </script>';
    }
    echo '</div>';
}

add_action('wp_ajax_cv_fetch_report_data', 'cv_fetch_report_data_ajax');
function cv_fetch_report_data_ajax()
{
    check_ajax_referer('cv_fetch_report_nonce', 'security');
    if (! current_user_can('manage_woocommerce')) {
        wp_send_json_error();
    }

    $event_id      = isset($_POST['event_id']) ? intval($_POST['event_id']) : 0;
    $page          = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
    $search        = isset($_POST['search']) ? strtolower(sanitize_text_field(wp_unslash($_POST['search']))) : '';
    $filter_status = isset($_POST['filter_status']) ? sanitize_text_field($_POST['filter_status']) : 'all'; // RECUPERO IL FILTRO
    $per_page      = 50;

    $is_delitto = ($event_id === 1639);
    $tavoli_delitto = ['Miss Marple', 'John Watson', 'Montalbano', 'Barlume', 'Agatha Christie', 'Sherlock Holmes', 'Hercule Poirot', 'Benoit Blank', 'Arthur Conan Doyle', 'Edgard Allan Poe'];

    // Recupera la giacenza effettiva del prodotto (Posti Liberi)
    $tot_rimanenti = '∞';
    $product = wc_get_product($event_id);
    if ($product && $product->managing_stock()) {
        $tot_rimanenti = $product->get_stock_quantity();
    }

    $orders = wc_get_orders([ 'status' => [ 'wc-processing', 'wc-completed' ], 'limit' => -1, 'product_id' => $event_id ]);

    $tot_venduti = 0;
    $tot_checkin = 0;
    $filtered_orders = [];

    foreach ($orders as $order) {
        $qty_prodotto = 0;
        foreach ($order->get_items() as $item) {
            if ($item->get_product_id() == $event_id) {
                $qty_prodotto += $item->get_quantity();
            }
        }
        if ($qty_prodotto === 0) {
            continue;
        }

        $tot_venduti += $qty_prodotto;
        $checkin_fatti = 0;
        for ($i = 1; $i <= $qty_prodotto; $i++) {
            if ($order->get_meta('_cv_ticket_validato_' . $i) === 'yes') {
                $checkin_fatti++;
            }
        }
        $tot_checkin += $checkin_fatti;

        // LOGICA DI FILTRAGGIO DEGLI STATI
        $match_status = true;
        if ($filter_status === 'pending' && $checkin_fatti > 0) {
            $match_status = false;
        }
        if ($filter_status === 'partial' && ($checkin_fatti === 0 || $checkin_fatti === $qty_prodotto)) {
            $match_status = false;
        }
        if ($filter_status === 'complete' && $checkin_fatti < $qty_prodotto) {
            $match_status = false;
        }

        $nome_cliente = strtolower($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        $telefono = strtolower($order->get_billing_phone());
        $id_string = (string) $order->get_id();

        // Se passa sia il filtro di stato che quello di ricerca
        if ($match_status && (empty($search) || strpos($nome_cliente, $search) !== false || strpos($telefono, $search) !== false || strpos($id_string, $search) !== false)) {
            $filtered_orders[] = [ 'order' => $order, 'qty' => $qty_prodotto, 'checkin_fatti' => $checkin_fatti ];
        }
    }

    $tot_residui = $tot_venduti - $tot_checkin; // CALCOLO RESIDUI

    $total_filtered = count($filtered_orders);
    $total_pages = ceil($total_filtered / $per_page);
    $offset = ($page - 1) * $per_page;
    $paged_orders = array_slice($filtered_orders, $offset, $per_page);

    $table_rows = '';
    $colspan = $is_delitto ? 11 : 10;

    if (empty($paged_orders)) {
        $table_rows = '<tr><td colspan="' . $colspan . '" style="text-align:center;">Nessun ordine trovato con questi criteri.</td></tr>';
    } else {
        foreach ($paged_orders as $data) {
            $order = $data['order'];
            $qty_prodotto = $data['qty'];
            $checkin_fatti = $data['checkin_fatti'];
            $nome_cliente = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            $telefono = $order->get_billing_phone();
            $telefono_html = $telefono ? '<a href="tel:' . esc_attr($telefono) . '">' . esc_html($telefono) . '</a>' : '-';

            // UTILIZZA LA NUOVA FUNZIONE DEL BLOCCO 17 PER IL BADGE
            $badge_fai = function_exists('cv_get_order_qualifica_label') ? cv_get_order_qualifica_label($order) : '-';

            $operatori_coinvolti = [];
            $html_bottoni_popup = '<div class="cv-popup-data-container" style="display:none;">';
            for ($i = 1; $i <= $qty_prodotto; $i++) {
                if ($order->get_meta('_cv_ticket_validato_' . $i) === 'yes') {
                    $op_id = $order->get_meta('_cv_ticket_validato_' . $i . '_operatore');
                    if ($op_id) {
                        $user_info = get_userdata($op_id);
                        $nome_op = $user_info ? $user_info->display_name : 'Sconosciuto';
                        isset($operatori_coinvolti[$nome_op]) ? $operatori_coinvolti[$nome_op]++ : $operatori_coinvolti[$nome_op] = 1;
                    }
                    $html_bottoni_popup .= '<div style="margin-bottom:8px; padding:10px; background:#eaf7ea; color:#166534; border: 1px solid #c3e6c3; border-radius: 4px; display:flex; justify-content:space-between; align-items:center;"><span>✅ Biglietto ' . $i . ' validato</span><button class="button cv-undo-checkin-btn" data-order="' . esc_attr($order->get_id()) . '" data-ticket="' . esc_attr($i) . '" style="color:#d63638; border-color:#d63638; padding:0 8px; min-height:26px; line-height:24px;">Annulla</button></div>';
                } else {
                    $html_bottoni_popup .= '<button class="button cv-manual-checkin-btn" data-order="' . esc_attr($order->get_id()) . '" data-ticket="' . esc_attr($i) . '" style="margin-bottom:8px; display:block; width:100%; border-color:#00a32a; color:#00a32a; height: 40px; cursor:pointer;">✔️ Valida Biglietto ' . $i . '</button>';
                }
            }
            $html_bottoni_popup .= '</div>';

            $history_meta = $order->get_meta('_cv_ticket_history');
            $html_history_popup = '<div class="cv-history-data-container" style="display:none;">';
            if (empty($history_meta) || !is_array($history_meta)) {
                $html_history_popup .= '<p style="color:#666; font-style:italic;">Nessuna interazione registrata.</p>';
            } else {
                usort($history_meta, function ($a, $b) {
                    return strtotime($b['time']) - strtotime($a['time']);
                });
                foreach ($history_meta as $log) {
                    $html_history_popup .= '<div class="cv-history-item"><span style="color:#777; margin-right:10px;">🕒 ' . date_i18n('d/m/Y - H:i:s', strtotime($log['time'])) . '</span> <strong>' . esc_html($log['action']) . '</strong></div>';
                }
            }
            $html_history_popup .= '</div>';

            if ($checkin_fatti === 0) {
                $stato_badge = '<span style="color:white; background:#d63638; padding:4px 10px; border-radius:4px; font-weight:bold;">0 / ' . $qty_prodotto . '</span>';
            } elseif ($checkin_fatti < $qty_prodotto) {
                $stato_badge = '<span style="color:white; background:#f59e0b; padding:4px 10px; border-radius:4px; font-weight:bold;">' . $checkin_fatti . ' / ' . $qty_prodotto . '</span>';
            } else {
                $stato_badge = '<span style="color:white; background:#16a34a; padding:4px 10px; border-radius:4px; font-weight:bold;">Completo (' . $qty_prodotto . ')</span>';
            }

            $reminder_sent = $order->get_meta('_cv_reminder_sent') === 'yes';
            $reminder_text = $reminder_sent ? '📧 Reinvia Reminder' : '📧 Invia Reminder';
            $btn_reminder = '<button class="button cv-single-reminder-btn" data-order="' . esc_attr($order->get_id()) . '" style="font-size:11px; padding: 2px 8px; line-height: 1.5; width:100%;">' . $reminder_text . '</button>';

            if ($checkin_fatti < $qty_prodotto) {
                $html_azioni_cassa = '<button class="button cv-open-popup-btn" data-cliente="' . esc_attr($nome_cliente) . '" style="width:100%;">🎟️ Gestisci Ingressi</button>' . $html_bottoni_popup;
            } else {
                $html_azioni_cassa = '<button class="button cv-open-popup-btn" data-cliente="' . esc_attr($nome_cliente) . '" style="width:100%; font-size:11px;">🔍 Modifica validazioni</button>' . $html_bottoni_popup;
            }

            $html_bottone_storico = '<button class="button cv-open-history-btn" data-cliente="' . esc_attr($nome_cliente) . '">📜 Log</button>' . $html_history_popup;

            $html_operatori = '-';
            if (! empty($operatori_coinvolti)) {
                $html_operatori = '';
                foreach ($operatori_coinvolti as $nome => $qta) {
                    $html_operatori .= '<span style="display:block; margin-bottom:4px; font-size:12px;">👤 ' . esc_html($nome) . ' <small style="color:#777;">(x' . $qta . ')</small></span>';
                }
            }

            $html_tavolo = '';
            if ($is_delitto) {
                $tavolo_assegnato = $order->get_meta('_cv_assigned_table');
                $html_tavolo .= '<td style="background:#fff9e6; border-left:1px solid #ddd; text-align:center;">';
                $html_tavolo .= '<select class="cv-table-selector" data-order="' . esc_attr($order->get_id()) . '" style="width:100%; font-size:12px;">';
                $html_tavolo .= '<option value="">-- Da smistare --</option>';
                foreach ($tavoli_delitto as $nt) {
                    $html_tavolo .= '<option value="' . esc_attr($nt) . '" ' . selected($tavolo_assegnato, $nt, false) . '>' . esc_html($nt) . '</option>';
                }
                $html_tavolo .= '</select></td>';
            }

            $edit_url = method_exists($order, 'get_edit_order_url') ? $order->get_edit_order_url() : admin_url('post.php?post=' . $order->get_id() . '&action=edit');

            $table_rows .= '<tr>';
            $table_rows .= '<td><a href="' . esc_url($edit_url) . '"><strong>#' . $order->get_id() . '</strong></a></td>';
            $table_rows .= '<td>' . esc_html($nome_cliente) . '</td>';
            $table_rows .= '<td>' . $badge_fai . '</td>';
            $table_rows .= '<td>' . $telefono_html . '</td>';
            $table_rows .= '<td><strong>' . esc_html($qty_prodotto) . '</strong></td>';
            $table_rows .= $html_tavolo;
            $table_rows .= '<td>' . $stato_badge . '</td>';
            $table_rows .= '<td>' . $html_operatori . '</td>';
            $table_rows .= '<td style="background:#f9f9f9; border-left:1px solid #ddd;">' . $html_azioni_cassa . '</td>';
            $table_rows .= '<td style="background:#fcfdfd; border-left:1px solid #ddd; text-align:center;">' . $btn_reminder . '</td>';
            $table_rows .= '<td style="background:#f6f7f7; border-left:1px solid #ddd; text-align:center;">' . $html_bottone_storico . '</td>';
            $table_rows .= '</tr>';
        }
    }

    $html_pagination = '';
    if ($total_pages > 1) {
        $html_pagination .= '<span style="margin-right:10px;">Pagina ' . $page . ' di ' . $total_pages . '</span>';
        if ($page > 1) {
            $html_pagination .= '<button class="button cv-page-btn" data-page="' . ($page - 1) . '">&laquo; Precedente</button>';
        }
        if ($page < $total_pages) {
            $html_pagination .= '<button class="button cv-page-btn" data-page="' . ($page + 1) . '">Successiva &raquo;</button>';
        }
    }

    // PASSO ANCHE I RESIDUI E I LIBERI NELLA RISPOSTA AJAX
    wp_send_json_success([
        'tot_venduti' => $tot_venduti,
        'tot_checkin' => $tot_checkin,
        'tot_residui' => $tot_residui,
        'tot_rimanenti' => $tot_rimanenti,
        'html_table_rows' => $table_rows,
        'html_pagination' => $html_pagination,
    ]);
}

add_action('wp_ajax_cv_process_manual_checkin', 'cv_process_manual_checkin');
function cv_process_manual_checkin()
{ /* ... [Inalterato] ... */
    check_ajax_referer('cv_manual_checkin_nonce', 'security');
    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
    $ticket_index = isset($_POST['ticket']) ? intval($_POST['ticket']) : 0;
    $order = wc_get_order($order_id);
    $lock_key = 'cv_ticket_lock_' . $order_id . '_' . $ticket_index;
    set_transient($lock_key, 1, 5);
    $meta_key = '_cv_ticket_validato_' . $ticket_index;
    $order->update_meta_data($meta_key, 'yes');
    $order->update_meta_data($meta_key . '_orario', current_time('mysql'));
    $order->update_meta_data($meta_key . '_operatore', get_current_user_id());
    $order->save();
    delete_transient($lock_key);
    wp_send_json_success();
}

add_action('wp_ajax_cv_process_undo_checkin', 'cv_process_undo_checkin');
function cv_process_undo_checkin()
{ /* ... [Inalterato] ... */
    check_ajax_referer('cv_manual_checkin_nonce', 'security');
    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
    $ticket_index = isset($_POST['ticket']) ? intval($_POST['ticket']) : 0;
    $order = wc_get_order($order_id);
    $meta_key = '_cv_ticket_validato_' . $ticket_index;
    $order->delete_meta_data($meta_key);
    $order->delete_meta_data($meta_key . '_orario');
    $order->delete_meta_data($meta_key . '_operatore');
    $current_user = wp_get_current_user();
    $order->add_order_note("🔄 Validazione del Biglietto $ticket_index annullata manualmente dal pannello Check-in dall'utente: {$current_user->display_name}");
    $order->save();
    wp_send_json_success();
}

add_action('wp_ajax_cv_manual_assign_table', 'cv_manual_assign_table_ajax');
function cv_manual_assign_table_ajax()
{ /* ... [Inalterato] ... */
    check_ajax_referer('cv_assign_table_nonce', 'security');
    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
    $table = isset($_POST['table']) ? sanitize_text_field($_POST['table']) : '';
    if ($order_id) {
        $order = wc_get_order($order_id);
        if ($order) {
            $order->update_meta_data('_cv_assigned_table', $table);
            $order->save();
            wp_send_json_success();
        }
    }
    wp_send_json_error();
}

add_action('wp_ajax_cv_auto_assign_tables', 'cv_auto_assign_tables_ajax');
function cv_auto_assign_tables_ajax()
{ /* ... [Inalterato] ... */
    check_ajax_referer('cv_assign_table_nonce', 'security');
    $event_id = isset($_POST['event_id']) ? intval($_POST['event_id']) : 0;
    $tavoli_capienza = ['Miss Marple' => 10,'John Watson' => 10,'Montalbano' => 10,'Barlume' => 10,'Agatha Christie' => 10,'Sherlock Holmes' => 10,'Hercule Poirot' => 10,'Benoit Blank' => 10,'Arthur Conan Doyle' => 10,'Edgard Allan Poe' => 13];
    $orders = wc_get_orders([ 'status' => [ 'wc-processing', 'wc-completed' ], 'limit' => -1, 'product_id' => $event_id ]);
    $gruppi_da_piazzare = [];
    foreach ($orders as $order) {
        $qty = 0;
        foreach ($order->get_items() as $item) {
            if ($item->get_product_id() == $event_id) {
                $qty += $item->get_quantity();
            }
        }
        if ($qty > 0) {
            $gruppi_da_piazzare[] = [ 'order' => $order, 'qty' => $qty ];
        }
    }
    shuffle($gruppi_da_piazzare);
    usort($gruppi_da_piazzare, function ($a, $b) {
        return $b['qty'] - $a['qty'];
    });
    $tavoli_occupati = array_fill_keys(array_keys($tavoli_capienza), 0);
    foreach ($gruppi_da_piazzare as $gruppo) {
        $qty_gruppo = $gruppo['qty'];
        $tavolo_scelto = '';
        $miglior_sforamento = -999;
        foreach ($tavoli_capienza as $nome_tavolo => $cap_max) {
            $posti_rimasti = $cap_max - $tavoli_occupati[$nome_tavolo];
            if ($posti_rimasti >= $qty_gruppo) {
                $tavolo_scelto = $nome_tavolo;
                break;
            } else {
                if ($posti_rimasti > $miglior_sforamento) {
                    $miglior_sforamento = $posti_rimasti;
                    $tavolo_scelto = $nome_tavolo;
                }
            }
        }
        $tavoli_occupati[$tavolo_scelto] += $qty_gruppo;
        $order = $gruppo['order'];
        $order->update_meta_data('_cv_assigned_table', $tavolo_scelto);
        $order->save();
    }
    wp_send_json_success();
}

add_action('wp_ajax_cv_fetch_table_map', 'cv_fetch_table_map_ajax');
function cv_fetch_table_map_ajax()
{ /* ... [Inalterato] ... */
    check_ajax_referer('cv_assign_table_nonce', 'security');
    $event_id = isset($_POST['event_id']) ? intval($_POST['event_id']) : 0;
    $tavoli_capienza = ['Miss Marple' => 10, 'John Watson' => 10, 'Montalbano' => 10, 'Barlume' => 10, 'Agatha Christie' => 10, 'Sherlock Holmes' => 10, 'Hercule Poirot' => 10, 'Benoit Blank' => 10, 'Arthur Conan Doyle' => 10, 'Edgard Allan Poe' => 13];
    $mappa = [];
    foreach ($tavoli_capienza as $nome => $capienza) {
        $mappa[$nome] = [ 'capienza' => $capienza, 'occupati' => 0, 'gruppi' => [] ];
    }
    $mappa['Non Assegnato'] = [ 'capienza' => 0, 'occupati' => 0, 'gruppi' => [] ];
    $orders = wc_get_orders([ 'status' => [ 'wc-processing', 'wc-completed' ], 'limit' => -1, 'product_id' => $event_id ]);
    foreach ($orders as $order) {
        $qty = 0;
        foreach ($order->get_items() as $item) {
            if ($item->get_product_id() == $event_id) {
                $qty += $item->get_quantity();
            }
        }
        if ($qty === 0) {
            continue;
        }
        $nome_cliente = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
        $tavolo = $order->get_meta('_cv_assigned_table');
        if (empty($tavolo) || !isset($mappa[$tavolo])) {
            $tavolo = 'Non Assegnato';
        }
        $mappa[$tavolo]['occupati'] += $qty;
        $mappa[$tavolo]['gruppi'][] = esc_html($nome_cliente) . ' <strong style="color:#2271b1;">(' . $qty . ' posti)</strong>';
    }
    $html = '<div class="cv-table-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">';
    foreach ($mappa as $nome_tavolo => $dati) {
        if ($nome_tavolo === 'Non Assegnato' && $dati['occupati'] === 0) {
            continue;
        }
        $cap = $dati['capienza'];
        $occ = $dati['occupati'];
        $colore_header = '#e5e7eb';
        $colore_testo = '#374151';
        if ($nome_tavolo === 'Non Assegnato' || $occ > $cap) {
            $colore_header = '#fef2f2';
            $colore_testo = '#991b1b';
        } elseif ($occ === $cap) {
            $colore_header = '#dcfce7';
            $colore_testo = '#166534';
        } elseif ($occ > 0) {
            $colore_header = '#fef3c7';
            $colore_testo = '#92400e';
        }
        $html .= '<div class="cv-table-card" style="background:#fff; border-radius:8px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.1); border:1px solid #e5e7eb;">';
        $html .= '<div style="background:' . $colore_header . '; color:' . $colore_testo . '; padding:15px; border-bottom:1px solid rgba(0,0,0,0.05); display:flex; justify-content:space-between; align-items:center;">';
        $html .= '<h3 style="margin:0; font-size:18px;">🍽️ ' . esc_html($nome_tavolo) . '</h3>';
        if ($cap > 0) {
            $html .= '<strong style="font-size:16px;">' . $occ . '/' . $cap . '</strong>';
        } else {
            $html .= '<strong style="font-size:16px;">' . $occ . ' posti</strong>';
        }
        $html .= '</div><div style="padding:15px;">';
        if (empty($dati['gruppi'])) {
            $html .= '<p style="color:#9ca3af; font-style:italic; margin:0;">Tavolo vuoto</p>';
        } else {
            $html .= '<ul style="margin:0; padding-left:20px; color:#4b5563; font-size:16px; line-height:1.6;">';
            foreach ($dati['gruppi'] as $gruppo) {
                $html .= '<li style="margin-bottom:5px;">' . $gruppo . '</li>';
            }
            $html .= '</ul>';
        }
        $html .= '</div></div>';
    }
    $html .= '</div>';
    wp_send_json_success($html);
}

/**
 * 4. AGGIUNGE IL BOTTONE "HUB BIGLIETTI" ALLA PAGINA ORDINE RICEVUTO
 */
add_action('woocommerce_thankyou', 'cv_aggiungi_link_hub_thankyou', 10, 1);
function cv_aggiungi_link_hub_thankyou($order_id)
{
    if (! $order_id) {
        return;
    }
    $order = wc_get_order($order_id);
    if (! $order) {
        return;
    }

    $tot_biglietti = 0;
    foreach ($order->get_items() as $item) {
        $tot_biglietti += $item->get_quantity();
    }

    $hub_token = hash_hmac('sha256', $order->get_order_key() . '_hub', wp_salt('nonce'));
    $hub_url = site_url('/?cv_hub=1&order_id=' . $order_id . '&token=' . $hub_token);

    echo '<div style="text-align:center; margin: 40px auto; padding: 30px; border: 2px dashed #e5e5e5; border-radius: 10px; background-color: #f9f9f9; max-width: 500px;">';
    echo '<h2 style="margin-top:0; color: #ff6600;">I tuoi Biglietti (' . $tot_biglietti . ')</h2>';
    echo '<p style="font-size: 16px;">Accedi al tuo hub personale per <strong>stampare i QR Code</strong> o smistarli su WhatsApp.</p>';
    echo '<a href="' . esc_url($hub_url) . '" style="background-color: #2271b1; color: white; padding: 15px 25px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block; margin-top: 10px; font-size:18px;">🎟️ Gestisci e Stampa Biglietti</a>';
    echo '</div>';
}

/**
 * 5. CAMBIA IL TITOLO NELLA THANK YOU PAGE DA "CONCLUDI" A "GRAZIE"
 */
add_action('wp_footer', 'cv_cambia_titolo_thankyou_page');
function cv_cambia_titolo_thankyou_page()
{
    // Eseguiamo lo script SOLO se ci troviamo nell'endpoint "order-received"
    if (is_wc_endpoint_url('order-received')) {
        ?>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                var titolo = document.querySelector('.titolo-checkout');
                if ( titolo ) {
                    titolo.innerHTML = 'Grazie del tuo ordine';
                }
            });
        </script>
        <?php
    }
}

/**
 * 6A. ELABORA LA SCANSIONE IN BACKGROUND TRAMITE AJAX
 */
add_action('wp_ajax_cv_process_live_scan', 'cv_process_live_scan');
function cv_process_live_scan()
{
    check_ajax_referer('cv_scanner_nonce_action', 'security');

    if (! current_user_can('cv_use_scanner')) {
        wp_send_json_error([ 'message' => 'Non hai i permessi necessari per scansionare i biglietti.' ]);
    }

    $order_id     = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
    $ticket_index = isset($_POST['ticket']) ? intval($_POST['ticket']) : 0;
    $token        = isset($_POST['token']) ? sanitize_text_field($_POST['token']) : '';

    if (! $order_id || ! $token || ! $ticket_index) {
        wp_send_json_error([ 'message' => 'Dati QR code incompleti.' ]);
    }

    $order = wc_get_order($order_id);
    if (! $order) {
        wp_send_json_error([ 'message' => 'Ordine #' . $order_id . ' non trovato.' ]);
    }

    if (! $order->has_status([ 'processing', 'completed' ])) {
        wp_send_json_error([
            'message' => "<span style='font-size:30px;'>🚫 ORDINE NON VALIDO</span><br><br>I biglietti di questo ordine sono stati disattivati poiché l'ordine risulta annullato, rimborsato o non pagato.",
        ]);
    }

    $expected_token = hash_hmac('sha256', $order->get_order_key() . '_ticket_' . $ticket_index, wp_salt('nonce'));
    if (! hash_equals($expected_token, $token)) {
        wp_send_json_error([ 'message' => 'Token di sicurezza non valido (Possibile manomissione).' ]);
    }

    $lock_key = 'cv_ticket_lock_' . $order_id . '_' . $ticket_index;
    if (get_transient($lock_key)) {
        wp_send_json_error([ 'message' => '⏳ Scansione già in elaborazione da un altro dispositivo.' ]);
    }
    set_transient($lock_key, 1, 5);

    $nomi_eventi = [];
    $tot_biglietti_ordine = 0;
    foreach ($order->get_items() as $item) {
        $nomi_eventi[] = $item->get_name();
        $tot_biglietti_ordine += $item->get_quantity();
    }
    $titolo_evento = implode(' + ', $nomi_eventi);
    $nome_cliente = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
    $tavolo_assegnato = $order->get_meta('_cv_assigned_table');

    $meta_key = '_cv_ticket_validato_' . $ticket_index;
    $gia_entrato = $order->get_meta($meta_key);

    if ($gia_entrato === 'yes') {
        $orario = $order->get_meta($meta_key . '_orario');
        $operatore_id = $order->get_meta($meta_key . '_operatore');
        $nome_operatore = 'Sconosciuto';
        if ($operatore_id) {
            $user_info = get_userdata($operatore_id);
            if ($user_info) {
                $nome_operatore = $user_info->display_name;
            }
        }

        delete_transient($lock_key);

        wp_send_json_error([
            'message' => "<span style='font-size:30px;'>❌ GIÀ ENTRATO</span><br><br><strong style='color:#333; font-size:18px;'>" . esc_html($titolo_evento) . "</strong><br><br>Il <strong>Biglietto {$ticket_index} di {$tot_biglietti_ordine}</strong> intestato a " . esc_html($nome_cliente) . " è già stato scansionato.<br><br>Data scansione: " . date_i18n('d/m/Y H:i', strtotime($orario)) . "<br>Validato da: <strong>" . esc_html($nome_operatore) . "</strong>",
        ]);
    } else {
        $order->update_meta_data($meta_key, 'yes');
        $order->update_meta_data($meta_key . '_orario', current_time('mysql'));
        $order->update_meta_data($meta_key . '_operatore', get_current_user_id());
        $order->save();

        delete_transient($lock_key);

        $tavolo_html = $tavolo_assegnato ? "<div style='display:inline-block; padding:15px 20px; background:#fff3cd; border:2px solid #ffc107; border-radius:8px; color:#856404; font-size:20px; font-weight:bold; margin-bottom:15px;'>🍽️ TAVOLO:<br>" . esc_html($tavolo_assegnato) . "</div><br>" : "";

        wp_send_json_success([
            'message' => "<span style='font-size:30px;'>✅ ACCESSO VALIDO</span><br><br><span style='font-size:24px;'><strong>" . esc_html($nome_cliente) . "</strong></span><br><br>{$tavolo_html}<span style='font-size:18px; color:#2271b1;'><strong>Evento:</strong> " . esc_html($titolo_evento) . "</span><br><br><div style='display:inline-block; padding:10px 20px; background:#eaf7ea; border:2px solid green; border-radius:8px; font-size:20px; font-weight:bold;'>Ingresso per 1 Persona<br><small style='font-weight:normal; font-size:14px;'>(Biglietto {$ticket_index} di {$tot_biglietti_ordine})</small></div><br><br><small>Ordine #{$order_id}</small>",
        ]);
    }
}

/**
 * 6B. CREA L'INTERFACCIA DELLO SCANNER CONTINUO COME VOCE PRINCIPALE
 */
add_action('admin_menu', 'cv_aggiungi_pagina_scanner_live');
function cv_aggiungi_pagina_scanner_live()
{
    add_menu_page('Scanner Live Eventi', '🔴 Scanner Live', 'cv_use_scanner', 'cv-scanner-live', 'cv_render_pagina_scanner_live', 'dashicons-camera', 56);
}

function cv_render_pagina_scanner_live()
{
    if (! current_user_can('cv_use_scanner')) {
        return;
    }
    $ajax_nonce = wp_create_nonce('cv_scanner_nonce_action');
    ?>
    <style>
        #wpcontent { padding-left: 0; } 
        .cv-scanner-wrapper { position: relative; width: 100%; height: calc(100vh - 100px); display: flex; flex-direction: column; background: #111; overflow: hidden; margin-top: 10px; }
        .cv-header { padding: 15px; background: #fff; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); z-index: 10; }
        .cv-header h1 { margin: 0; font-size: 20px; font-weight: bold; }
        #reader { flex-grow: 1; width: 100%; display: flex; align-items: center; justify-content: center; }
        #btn-start { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 20; font-size: 20px; padding: 15px 30px; border-radius: 50px; box-shadow: 0 4px 15px rgba(0,0,0,0.3); }
        #scan-result { position: fixed; bottom: 0; left: 0; width: 100%; padding: 30px 20px 40px 20px; box-sizing: border-box; border-radius: 20px 20px 0 0; box-shadow: 0 -10px 25px rgba(0,0,0,0.4); font-size: 18px; text-align: center; z-index: 99999; transform: translateY(100%); transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        #scan-result.show { transform: translateY(0); }
    </style>

    <div class="cv-scanner-wrapper">
        <div class="cv-header"><h1>Scanner Check-in</h1></div>
        <div id="reader"></div>
        <button id="btn-start" class="button button-primary button-hero">📷 Avvia Fotocamera</button>
        <div id="scan-result"></div>
    </div>

    <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js" type="text/javascript"></script>
    <script type="text/javascript">
    document.addEventListener("DOMContentLoaded", function() {
        var html5QrCode; 
        var audioCtx;
        var isProcessing = false;
        var resultDiv = document.getElementById('scan-result');
        var btnStart = document.getElementById('btn-start');
        
        var securityNonce = "<?php echo esc_js($ajax_nonce); ?>"; 

        function initAudioAndVibration() {
            if (!audioCtx) { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
            if (audioCtx.state === 'suspended') { audioCtx.resume(); }
        }

        function playFeedback(type) {
            if(navigator.vibrate) { type === 'success' ? navigator.vibrate(200) : navigator.vibrate([500, 200, 500]); }
            if (audioCtx) {
                var osc = audioCtx.createOscillator(); var gainNode = audioCtx.createGain();
                osc.connect(gainNode); gainNode.connect(audioCtx.destination);
                if (type === 'success') {
                    osc.type = "triangle"; osc.frequency.setValueAtTime(1200, audioCtx.currentTime); 
                    gainNode.gain.setValueAtTime(0.8, audioCtx.currentTime); osc.start(); osc.stop(audioCtx.currentTime + 0.2);
                } else {
                    osc.type = "sawtooth"; osc.frequency.setValueAtTime(150, audioCtx.currentTime); 
                    gainNode.gain.setValueAtTime(0.3, audioCtx.currentTime); osc.start(); osc.stop(audioCtx.currentTime + 0.5);
                }
            }
        }

        window.chiudiPannello = function() {
            resultDiv.classList.remove('show');
            setTimeout(function() { isProcessing = false; }, 300);
        };

        function onScanSuccess(decodedText, decodedResult) {
            if (isProcessing) return;
            isProcessing = true;
            var bottoneChiudi = '<button onclick="chiudiPannello()" style="margin-top:20px; width:100%; padding:15px; font-size:18px; font-weight:bold; border-radius:8px; border:none; background:#111; color:#fff; box-shadow:0 4px 6px rgba(0,0,0,0.2);">Chiudi e scansiona il prossimo</button>';

            if (!decodedText.includes('cv_checkin=1')) {
                playFeedback('error'); resultDiv.style.background = '#fef2f2'; resultDiv.style.color = '#991b1b';
                resultDiv.innerHTML = '<span style="font-size:30px;">❌ QR NON RICONOSCIUTO</span><br><br>Questo QR Code non è un biglietto valido per questo evento.<br>' + bottoneChiudi;
                resultDiv.classList.add('show'); return; 
            }

            resultDiv.style.background = '#ffeb3b'; resultDiv.style.color = '#333';
            resultDiv.innerHTML = '<h2 style="margin:0;">⏳ Verifica in corso...</h2>'; resultDiv.classList.add('show');

            var urlParams = new URL(decodedText).searchParams;
            var orderId = urlParams.get('order_id');
            var token = urlParams.get('token');
            var ticketIndex = urlParams.get('ticket');

            function attemptAjax(tentativi) {
                jQuery.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: { action: 'cv_process_live_scan', security: securityNonce, order_id: orderId, token: token, ticket: ticketIndex },
                    timeout: 8000,
                    success: function(response) {
                        if (response.success) {
                            playFeedback('success'); resultDiv.style.background = '#f0fdf4'; resultDiv.style.color = '#166534'; resultDiv.innerHTML = response.data.message + bottoneChiudi;
                        } else {
                            playFeedback('error'); resultDiv.style.background = '#fef2f2'; resultDiv.style.color = '#991b1b'; resultDiv.innerHTML = response.data.message + bottoneChiudi;
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        if (textStatus === 'timeout' && tentativi < 2) {
                            resultDiv.innerHTML = '<h2 style="margin:0;">⏳ Rete lenta, nuovo tentativo (' + (tentativi + 1) + '/2)...</h2>';
                            attemptAjax(tentativi + 1);
                        } else {
                            playFeedback('error'); resultDiv.style.background = '#fff3cd'; resultDiv.style.color = '#856404';
                            var errorMsg = (textStatus === 'timeout') ? 'Il server non risponde dopo 3 tentativi.' : 'Connessione Internet assente o instabile.';
                            resultDiv.innerHTML = '<span style="font-size:30px;">⚠️ ERRORE DI RETE</span><br><br>' + errorMsg + '<br>Verifica la copertura 4G o Wi-Fi e riprova la scansione.<br>' + bottoneChiudi;
                        }
                    }
                });
            }
            attemptAjax(0);
        }

        btnStart.addEventListener('click', function() {
            initAudioAndVibration(); btnStart.style.display = 'none';
            html5QrCode = new Html5Qrcode("reader");
            html5QrCode.start( { facingMode: "environment" }, { fps: 10, qrbox: { width: 250, height: 250 } }, onScanSuccess )
            .catch(function(err) { alert("Errore fotocamera: " + err); btnStart.style.display = 'block'; });
        });
    });
    </script>
    <?php
}

/**
 * 7A. GENERA DINAMICAMENTE IL FILE MANIFEST.JSON PER LA PWA
 */
add_action('parse_request', 'cv_pwa_manifest_endpoint');
function cv_pwa_manifest_endpoint($wp)
{
    // Intercettiamo una URL specifica per stampare il JSON
    if (isset($_GET['cv_manifest'])) {
        header('Content-Type: application/json; charset=utf-8');

        // ATTENZIONE: Inserisci qui l'URL di un'immagine quadrata (es. 512x512)
        // che hai caricato nella libreria media di WordPress per usarla come icona dell'app.
        $icon_url = site_url('/wp-content/uploads/2023/02/favicon-dfn.png');

        echo json_encode([
            'name'             => 'Scanner CandleVibes',
            'short_name'       => 'Scanner CV',
            'description'      => 'Strumento di Check-in per Eventi',
            'start_url'        => admin_url('admin.php?page=cv-scanner-live'), // La pagina che si apre al tap sull'icona
            'display'          => 'standalone', // Rimuove la UI del browser (barra indirizzi, ecc.)
            'background_color' => '#111111', // Colore di sfondo allo splash screen
            'theme_color'      => '#111111', // Colore della barra di stato superiore
            'icons'            => [
                [
                    'src'   => $icon_url,
                    'sizes' => '192x192',
                    'type'  => 'image/png',
                ],
                [
                    'src'   => $icon_url,
                    'sizes' => '512x512',
                    'type'  => 'image/png',
                ],
            ],
        ]);
        exit;
    }
}

/**
 * 7B. INIETTA I TAG PWA NELLA PAGINA DELLO SCANNER E NASCONDE LA BARRA DI WORDPRESS
 */
add_action('admin_head', 'cv_pwa_add_head_tags');
function cv_pwa_add_head_tags()
{
    // Eseguiamo questo codice SOLO quando siamo sulla pagina dello scanner
    if (isset($_GET['page']) && $_GET['page'] === 'cv-scanner-live') {

        $manifest_url = site_url('/?cv_manifest=1');

        // Tag per Android/Chrome
        echo '<link rel="manifest" href="' . esc_url($manifest_url) . '">';
        echo '<meta name="mobile-web-app-capable" content="yes">';
        echo '<meta name="theme-color" content="#111111">';

        // Tag per iOS/Safari (se un membro dello staff ha un iPhone)
        echo '<meta name="apple-mobile-web-app-capable" content="yes">';
        echo '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">';
        echo '<meta name="apple-mobile-web-app-title" content="Scanner CV">';

        // CSS Extra per nascondere la barra nera di amministrazione di WordPress
        // e rendere l'app davvero "Full Screen"
        echo '<style>
            #wpadminbar { display: none !important; }
            html.wp-toolbar { padding-top: 0 !important; }
            #adminmenumain { display: none !important; }
            #wpcontent { margin-left: 0 !important; }
        </style>';
    }
}

/**
 * 8. AGGIUNGE UN BOTTONE DI PAGAMENTO TRACCIATO NELLE EMAIL DEGLI ORDINI MANUALI
 */
add_action('woocommerce_email_before_order_table', 'cv_aggiungi_bottone_pagamento_email', 10, 4);
function cv_aggiungi_bottone_pagamento_email($order, $sent_to_admin, $plain_text, $email)
{
    if ($sent_to_admin || $plain_text || ! $order->needs_payment()) {
        return;
    }

    if ($email->id === 'customer_invoice') {
        $payment_url = $order->get_checkout_payment_url();

        // Aggiungiamo il parametro magico per il tracciamento
        $tracked_url = add_query_arg('cv_track_pay', '1', $payment_url);

        echo '<div style="text-align: center; margin: 40px 0; padding: 25px; border: 2px solid #d63638; border-radius: 8px; background-color: #fffafb;">';
        echo '<h3 style="color: #d63638; margin-top: 0; font-size: 22px;">⚠️ I tuoi posti sono riservati temporaneamente</h3>';
        echo '<p style="font-size: 16px; color: #333; margin-bottom: 25px;">Abbiamo bloccato i tuoi biglietti, ma questa prenotazione scadrà automaticamente tra <strong>24 ore</strong>. Se il pagamento non verrà finalizzato entro questo termine, l\'ordine verrà annullato in automatico e i posti torneranno liberi per l\'acquisto al pubblico.</p>';
        echo '<a href="' . esc_url($tracked_url) . '" style="background-color: #7016d9; color: #ffffff; padding: 18px 36px; font-size: 20px; font-weight: bold; text-decoration: none; border-radius: 8px; display: inline-block; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">💳 PAGA E CONFERMA I BIGLIETTI</a>';
        echo '</div>';
    }
}

/**
 * 9. BOTTEGHINO LIVE E GENERATORE RAPIDO FAI (CON GESTIONE CONTANTI, CARTE E AUTORITÀ)
 */
add_action('admin_menu', 'cv_aggiungi_generatore_fai');
function cv_aggiungi_generatore_fai()
{
    $hook = add_submenu_page(
        'woocommerce',
        'Botteghino Live',
        '🎟️ Botteghino Live',
        'manage_woocommerce',
        'cv-generatore-fai',
        'cv_render_generatore_fai',
    );

    add_action("admin_print_scripts-{$hook}", function () {
        wp_enqueue_script('selectWoo');
        wp_enqueue_style('select2');
    });
}

// MOTORE 1: Cerca nei clienti registrati E negli Ospiti (Storico Ordini)
add_action('wp_ajax_cv_search_customers', 'cv_search_customers_ajax');
function cv_search_customers_ajax()
{
    check_ajax_referer('cv_ricerca_clienti_nonce', 'security');

    $term = isset($_GET['term']) ? wc_clean(wp_unslash($_GET['term'])) : '';
    if (empty($term)) {
        wp_send_json([]);
    }

    $results = [];
    $emails_found = [];

    $users = new WP_User_Query([
        'search'         => '*' . esc_attr($term) . '*',
        'search_columns' => [ 'user_login', 'user_email', 'user_nicename', 'display_name' ],
        'number'         => 10,
    ]);
    foreach ($users->get_results() as $user) {
        $results[] = [ 'id' => $user->ID, 'text' => $user->display_name . ' (' . $user->user_email . ') - Registrato' ];
        $emails_found[] = strtolower($user->user_email);
    }

    global $wpdb;
    $term_like = '%' . $wpdb->esc_like($term) . '%';
    $query = $wpdb->prepare("
        SELECT email, first_name, last_name, user_id 
        FROM {$wpdb->prefix}wc_customer_lookup 
        WHERE email LIKE %s OR first_name LIKE %s OR last_name LIKE %s 
        GROUP BY email LIMIT 20
    ", $term_like, $term_like, $term_like);

    $lookup_results = $wpdb->get_results($query);

    foreach ($lookup_results as $row) {
        if (! in_array(strtolower($row->email), $emails_found)) {
            $nome = trim($row->first_name . ' ' . $row->last_name);
            if (empty($nome)) {
                $nome = 'Cliente Ospite';
            }

            $results[] = [ 'id' => ($row->user_id > 0) ? $row->user_id : 'email|' . $row->email, 'text' => $nome . ' (' . $row->email . ')' ];
            $emails_found[] = strtolower($row->email);
        }
    }
    wp_send_json($results);
}

// MOTORE 2: Recupera i dati esatti del cliente selezionato
add_action('wp_ajax_cv_get_customer_data', 'cv_get_customer_data_ajax');
function cv_get_customer_data_ajax()
{
    check_ajax_referer('cv_ricerca_clienti_nonce', 'security');
    $customer_id_raw = isset($_POST['customer_id']) ? sanitize_text_field(wp_unslash($_POST['customer_id'])) : '';

    if (is_numeric($customer_id_raw) && $customer_id_raw > 0) {
        $customer = new WC_Customer($customer_id_raw);
        $first_name = $customer->get_billing_first_name() ?: $customer->get_first_name();
        $last_name  = $customer->get_billing_last_name() ?: $customer->get_last_name();
        $email      = $customer->get_billing_email() ?: $customer->get_email();
        $phone      = $customer->get_billing_phone();

        if (empty($phone) || empty($first_name)) {
            $last_orders = wc_get_orders([ 'customer_id' => $customer_id_raw, 'limit' => 1, 'orderby' => 'date', 'order' => 'DESC' ]);
            if (! empty($last_orders)) {
                if (empty($phone)) {
                    $phone = $last_orders[0]->get_billing_phone();
                }
                if (empty($first_name)) {
                    $first_name = $last_orders[0]->get_billing_first_name();
                }
                if (empty($last_name)) {
                    $last_name = $last_orders[0]->get_billing_last_name();
                }
            }
        }
        wp_send_json_success([ 'first_name' => $first_name, 'last_name'  => $last_name, 'email' => $email, 'phone' => $phone ]);

    } elseif (strpos($customer_id_raw, 'email|') === 0) {
        $email = trim(str_replace('email|', '', $customer_id_raw));
        $orders = wc_get_orders([ 'limit' => 1, 'orderby' => 'date', 'order' => 'DESC', 'billing_email' => $email ]);

        if (! empty($orders)) {
            $last_order = $orders[0];
            wp_send_json_success([ 'first_name' => $last_order->get_billing_first_name(), 'last_name' => $last_order->get_billing_last_name(), 'email' => $last_order->get_billing_email(), 'phone' => $last_order->get_billing_phone() ]);
        } else {
            global $wpdb;
            $lookup = $wpdb->get_row($wpdb->prepare("SELECT first_name, last_name FROM {$wpdb->prefix}wc_customer_lookup WHERE email = %s LIMIT 1", $email));
            wp_send_json_success([ 'first_name' => $lookup ? $lookup->first_name : '', 'last_name' => $lookup ? $lookup->last_name : '', 'email' => $email, 'phone' => '' ]);
        }
    }
    wp_send_json_error();
}

// INTERFACCIA E LOGICA DI SALVATAGGIO (BOTTEGHINO)
function cv_render_generatore_fai()
{
    if (! current_user_can('manage_woocommerce')) {
        return;
    }

    $messaggio = '';
    $valore_sconto_singolo = 5;

    if (isset($_POST['cv_genera_fai_nonce']) && wp_verify_nonce($_POST['cv_genera_fai_nonce'], 'cv_genera_fai')) {

        $payment_method = isset($_POST['fai_metodo_pagamento']) ? sanitize_text_field($_POST['fai_metodo_pagamento']) : 'link';
        $prodotto_id    = intval($_POST['fai_prodotto']);
        $quantita       = intval($_POST['fai_qty']);

        // Selezioniamo dati fittizi se è Autorità, altrimenti prendiamo quelli del form
        if ($payment_method === 'autorita') {
            $nome         = 'Riserva';
            $cognome      = 'Autorità';
            $email        = 'autorita_' . time() . '@fainovara.local';
            $telefono     = 'CERIMONIALE';
            $tessere      = 0;
            $auto_checkin = true; // Le autorità saltano la porta
            $customer_id  = 0;
        } else {
            $nome         = sanitize_text_field($_POST['fai_nome']);
            $cognome      = sanitize_text_field($_POST['fai_cognome']);
            $email        = sanitize_email($_POST['fai_email']);
            $telefono     = sanitize_text_field($_POST['fai_telefono']);
            $tessere      = isset($_POST['fai_tessere']) ? intval($_POST['fai_tessere']) : 0;
            $auto_checkin = isset($_POST['fai_auto_checkin']) ? true : false;
            $customer_id_raw = isset($_POST['fai_customer_id']) ? sanitize_text_field($_POST['fai_customer_id']) : '';
            $customer_id     = is_numeric($customer_id_raw) ? intval($customer_id_raw) : 0;
        }

        if ($prodotto_id === 1627) {
            $tessere = 0;
        }

        if (is_email($email) && $prodotto_id > 0 && $quantita > 0) {

            $product = wc_get_product($prodotto_id);

            $is_overbooking = false;
            if ($product->managing_stock() && $product->get_stock_quantity() < $quantita) {
                $is_overbooking = true;
            }

            if ($tessere > $quantita) {
                $tessere = $quantita;
            }

            $order = wc_create_order();
            if ($customer_id > 0) {
                $order->set_customer_id($customer_id);
            }

            $order->set_billing_first_name($nome);
            $order->set_billing_last_name($cognome);
            $order->set_billing_email($email);
            $order->set_billing_phone($telefono);
            $order->add_product($product, $quantita);

            // Gestione Sconti o gratuità Autorità
            if ($payment_method === 'autorita') {
                $order->update_meta_data('_cv_is_authority', 'yes');
                $total_price = $product->get_price() * $quantita;
                $fee = new WC_Order_Item_Fee();
                $fee->set_name('Riserva Posti Autorità (Omaggio)');
                $fee->set_amount(-$total_price);
                $fee->set_total(-$total_price);
                $order->add_item($fee);
            } elseif ($tessere > 0) {
                $sconto_totale = $tessere * $valore_sconto_singolo;
                $fee = new WC_Order_Item_Fee();
                $fee->set_name('Sconto Tessera FAI (' . $tessere . ' validat' . ($tessere == 1 ? 'a' : 'e') . ')');
                $fee->set_amount(-$sconto_totale);
                $fee->set_total(-$sconto_totale);
                $order->add_item($fee);
            }

            $order->calculate_totals();

            // Smistamento flussi di pagamento e completamento
            if ($payment_method === 'contanti' || $payment_method === 'autorita') {
                $order->set_payment_method('cod');
                $order->set_payment_method_title($payment_method === 'autorita' ? 'Cerimoniale Autorità' : 'Contanti in Loco (Botteghino)');
                $order->update_status('completed', 'Operazione registrata dal botteghino.');
                wc_reduce_stock_levels($order->get_id());

                // LOGICA CHECK-IN IMMEDIATO
                if ($auto_checkin) {
                    for ($i = 1; $i <= $quantita; $i++) {
                        $order->update_meta_data('_cv_ticket_validato_' . $i, 'yes');
                        $order->update_meta_data('_cv_ticket_validato_' . $i . '_orario', current_time('mysql'));
                        $order->update_meta_data('_cv_ticket_validato_' . $i . '_operatore', get_current_user_id());
                    }
                    $order->add_order_note('✅ Check-in immediato eseguito dalla cassa.');

                    if ($payment_method === 'autorita') {
                        $messaggio_esito = '🎁 Ordine generato con successo. I posti sono stati <strong>RISERVATI PER LE AUTORITÀ</strong> e scalati dalle scorte.';
                    } else {
                        $messaggio_esito = '✅ Ordine incassato in <strong>CONTANTI</strong> e <strong style="color:#16a34a;">BIGLIETTI VALIDATI PER L\'INGRESSO</strong>.';
                    }
                } else {
                    WC()->mailer()->get_emails()['WC_Email_Customer_Completed_Order']->trigger($order->get_id());
                    $order->add_order_note('📧 Inviata mail con i BIGLIETTI (Pagamento in contanti).');
                    $messaggio_esito = '✅ Ordine incassato in <strong>CONTANTI</strong>. I biglietti sono stati inviati a <strong>' . esc_html($email) . '</strong>.';
                }

                $colore_esito = 'notice-success';

            } else {
                $order->update_status('pending', 'Ordine generato dal Botteghino. In attesa di pagamento tramite link.');
                wc_reduce_stock_levels($order->get_id());
                WC()->mailer()->get_emails()['WC_Email_Customer_Invoice']->trigger($order->get_id());
                $order->add_order_note('📧 L\'email con il link di pagamento elettronico è stata inviata a ' . esc_html($email));
                $messaggio_esito = '💳 Ordine creato. Il link di pagamento è stato inviato a <strong>' . esc_html($email) . '</strong>.';
                $colore_esito = 'notice-info';
            }

            if ($is_overbooking) {
                $order->add_order_note('⚠️ FORZATURA SCORTE: L\'operatore del botteghino ha forzato l\'operazione superando i posti disponibili.');
                $messaggio_esito .= '<br><br><strong style="color:#d63638;">⚠️ NOTA OVERBOOKING:</strong> Hai riservato più biglietti dei posti rimasti in magazzino.';
            }

            // SALVATAGGIO DEFINITIVO NEL DATABASE (La riga mancante!)
            $order->save();

            $edit_url = method_exists($order, 'get_edit_order_url') ? $order->get_edit_order_url() : admin_url('post.php?post=' . $order->get_id() . '&action=edit');
            $sconto_msg = $tessere > 0 ? " (Sconto {$tessere} tessere FAI)" : "";

            $messaggio = '<div class="notice ' . $colore_esito . ' is-dismissible" style="padding:15px; font-size:16px;">' . $messaggio_esito . $sconto_msg . '<br><br><a href="' . esc_url($edit_url) . '">🔍 Clicca qui per vedere l\'ordine #' . $order->get_id() . '</a></div>';

        } else {
            $messaggio = '<div class="notice notice-error is-dismissible"><p>❌ Errore: Controlla email ed evento.</p></div>';
        }
    }

    $args = [ 'limit' => -1, 'status' => 'publish', 'return' => 'objects' ];
    $products = wc_get_products($args);

    echo '<div class="wrap">';
    echo '<h1 class="wp-heading-inline">Botteghino Live e Generatore Ordini</h1>';
    echo '<p style="font-size:16px; color:#555;">Crea l\'ordine ed emetti i biglietti istantaneamente (Contanti), invia il link di pagamento (Carte) o riserva i posti per le Autorità.</p>';

    echo $messaggio;

    echo '<style>
        .cv-fai-container { background: #fff; border: 1px solid #ccd0d4; padding: 30px; max-width: 700px; margin-top: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .cv-form-row { margin-bottom: 22px; }
        .cv-form-row label { display: block; font-weight: 600; margin-bottom: 6px; color: #1d2327; font-size: 14px; }
        .cv-form-row input[type="text"], .cv-form-row input[type="email"], .cv-form-row input[type="tel"],
        .cv-form-row input[type="number"], .cv-form-row select { width: 100%; padding: 8px 12px; border: 1px solid #8c8f94; border-radius: 4px; box-sizing: border-box; min-height: 38px; font-size:15px; }
        .cv-form-row p.description { margin-top: 5px; font-size: 12px; color: #646970; }
        .select2-container { width: 100% !important; margin-top: 5px; display: block; }
        .select2-container .select2-selection--single { height: auto !important; min-height: 38px !important; padding: 5px !important; border: 1px solid #8c8f94 !important; border-radius: 4px !important; }
        .select2-container .select2-selection--single .select2-selection__rendered { padding-right: 30px !important; line-height: 1.6 !important; font-size:15px !important; }
        .select2-container .select2-selection--single .select2-selection__clear { position: absolute !important; right: 25px !important; top: 50% !important; transform: translateY(-50%) !important; }
        .select2-container .select2-selection--single .select2-selection__arrow { position: absolute !important; right: 5px !important; top: 50% !important; transform: translateY(-50%) !important; }
        .select2-container--open { z-index: 999999 !important; }
        .select2-dropdown { position: absolute !important; z-index: 999999 !important; box-shadow: 0 15px 35px rgba(0,0,0,0.25) !important; border: 1px solid #8c8f94 !important; border-radius: 8px !important; background: #ffffff !important; padding: 5px; margin-top: 5px; }
        .select2-search--dropdown { padding: 5px !important; background: #ffffff !important; }
        .select2-search--dropdown .select2-search__field { width: 100% !important; box-sizing: border-box !important; border: 1px solid #8c8f94 !important; border-radius: 4px !important; padding: 6px 10px !important; background: #ffffff !important; }
        .select2-results { background: #ffffff !important; }
        .select2-results__options { max-height: 250px !important; overflow-y: auto !important; background: #ffffff !important; }
        .select2-results__option { padding: 8px 10px !important; border-radius: 4px !important; margin-bottom: 2px !important; background: #ffffff; }
        .select2-results__option--highlighted[aria-selected] { background-color: #2271b1 !important; color: white !important; }
        
        .cv-pos-buttons { display: flex; gap: 15px; margin-top: 20px; flex-wrap: wrap; }
        .cv-pos-btn { flex: 1; min-width: 180px; padding: 15px 20px; font-size: 16px; font-weight: bold; border-radius: 6px; cursor: pointer; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; border: none; transition: transform 0.1s; color: white; line-height:1.3; text-align:center; }
        .cv-pos-btn:active { transform: scale(0.97); }
        .cv-btn-cash { background-color: #16a34a; box-shadow: 0 4px 0 #15803d; }
        .cv-btn-cash:hover { background-color: #15803d; }
        .cv-btn-link { background-color: #2271b1; box-shadow: 0 4px 0 #135e96; }
        .cv-btn-link:hover { background-color: #135e96; }
        .cv-btn-auth { background-color: #6b21a8; box-shadow: 0 4px 0 #581c87; }
        .cv-btn-auth:hover { background-color: #581c87; }
    </style>';

    echo '<div class="cv-fai-container">';
    echo '<form id="cv-botteghino-form" method="POST" action="">';
    wp_nonce_field('cv_genera_fai', 'cv_genera_fai_nonce');
    echo '<input type="hidden" name="fai_metodo_pagamento" id="fai_metodo_pagamento" value="link">';

    echo '<div class="cv-form-row" style="background:#f0f6fc; padding:15px; border-radius:6px; border:1px solid #c8d7e1;">';
    echo '<label for="fai_customer_search">🔍 Cerca Cliente Esistente (Opzionale)</label>';
    echo '<select id="fai_customer_search" name="fai_customer_id" data-placeholder="Digita nome o email..."><option value=""></option></select>';
    echo '</div>';

    echo '<div style="display: flex; gap: 15px;">';
    echo '<div class="cv-form-row" style="flex: 1;"><label for="fai_nome">Nome</label><input type="text" name="fai_nome" id="fai_nome" placeholder="Es. Mario" required></div>';
    echo '<div class="cv-form-row" style="flex: 1;"><label for="fai_cognome">Cognome</label><input type="text" name="fai_cognome" id="fai_cognome" placeholder="Es. Rossi"></div>';
    echo '</div>';

    echo '<div class="cv-form-row">';
    echo '<label for="fai_email" style="display:flex; justify-content:space-between;"><span>Email *</span> <a href="#" id="cv-btn-no-email" style="font-size:12px; color:#d63638; text-decoration:none; border-bottom:1px dashed #d63638;">Il cliente non ha email?</a></label>';
    echo '<input type="email" name="fai_email" id="fai_email" required placeholder="mario.rossi@email.it">';
    echo '</div>';

    echo '<div class="cv-form-row"><label for="fai_telefono">Telefono</label><input type="tel" name="fai_telefono" id="fai_telefono" placeholder="Es. 3331234567"></div>';

    echo '<div class="cv-form-row">';
    echo '<label for="fai_prodotto" style="display:flex; justify-content:space-between;"><span>Evento *</span> <span id="cv-stock-indicator" style="color:#d63638; display:none; background:#fff3cd; padding:2px 8px; border-radius:4px; font-size:12px;"></span></label>';
    echo '<select name="fai_prodotto" id="fai_prodotto" required><option value="" data-stock="">-- Seleziona l\'evento --</option>';
    foreach ($products as $product) {
        $stock = $product->managing_stock() ? $product->get_stock_quantity() : 9999;
        echo '<option value="' . esc_attr($product->get_id()) . '" data-stock="' . esc_attr($stock) . '">' . esc_html($product->get_name()) . ' (' . strip_tags($product->get_price_html()) . ')</option>';
    }
    echo '</select></div>';

    echo '<div style="display: flex; gap: 15px; align-items: flex-start;">';
    echo '<div class="cv-form-row" style="flex: 1;"><label for="fai_qty">Biglietti Totali</label><input type="number" name="fai_qty" id="fai_qty" value="1" min="1" step="1" data-stock-reale="" style="font-size:20px; font-weight:bold;"></div>';
    echo '<div class="cv-form-row" id="cv-fai-discount-wrapper" style="flex: 1;"><label for="fai_tessere">Tessere FAI</label><input type="number" name="fai_tessere" id="fai_tessere" value="0" min="0" step="1" style="font-size:20px;"></div>';
    echo '</div>';

    echo '<div class="cv-form-row" id="cv-auto-checkin-wrapper" style="background:#eaf7ea; padding:15px; border-radius:6px; border:1px solid #c3e6c3;">';
    echo '<label style="margin:0; display:flex; align-items:center; cursor:pointer; color:#166534; font-size:15px;">';
    echo '<input type="checkbox" name="fai_auto_checkin" id="fai_auto_checkin" value="1" style="margin-right:10px; width:20px; height:20px;">';
    echo 'Valida automaticamente i biglietti</label>';
    echo '<p class="description" style="margin-left:30px; color:#166534;">Spunta questa casella <strong>SOLO</strong> se il cliente entra in questo esatto momento (es. gli dai il braccialetto cartaceo). Se entra in un secondo momento, lascia deselezionato.</p>';
    echo '</div>';

    echo '<div class="cv-pos-buttons">';
    echo '<button type="button" id="cv-btn-submit-link" class="cv-pos-btn cv-btn-link"><span style="font-size:24px;">💳</span>Invia Link di<br>Pagamento (Carta)</button>';
    echo '<button type="button" id="cv-btn-submit-cash" class="cv-pos-btn cv-btn-cash"><span style="font-size:24px;">💵</span>Incassa in Contanti<br>ed Emetti Biglietti</button>';
    echo '<button type="button" id="cv-btn-submit-auth" class="cv-pos-btn cv-btn-auth"><span style="font-size:24px;">🎁</span>Riserva Posti<br>Autorità (Omaggio)</button>';
    echo '</div>';

    echo '</form></div></div>';

    echo '<script>
        jQuery(document).ready(function($) {
            var ajaxSecurityNonce = "' . esc_js(wp_create_nonce('cv_ricerca_clienti_nonce')) . '";

            // Generatore Email Finta
            $("#cv-btn-no-email").on("click", function(e) {
                e.preventDefault();
                var randomNum = Math.floor(1000 + Math.random() * 9000);
                $("#fai_email").val("cassa_" + randomNum + "@fainovara.local").css("background-color", "#fff3cd");
            });

            $("#fai_prodotto").on("change", function() {
                var selectedOption = $(this).find("option:selected");
                var selectedId = $(this).val();
                var stock = selectedOption.data("stock");
                
                if(selectedId && stock !== "" && stock !== 9999) {
                    $("#cv-stock-indicator").text("Posti rimasti: " + stock).show();
                    $("#fai_qty").data("stock-reale", stock);
                } else {
                    $("#cv-stock-indicator").hide();
                    $("#fai_qty").removeData("stock-reale");
                }

                if (selectedId == "1627") {
                    $("#cv-fai-discount-wrapper").slideUp();
                    $("#fai_tessere").val(0);
                } else {
                    $("#cv-fai-discount-wrapper").slideDown();
                }
            });
            
            function checkOverbooking() {
                var qty = parseInt($("#fai_qty").val());
                var stock = parseInt($("#fai_qty").data("stock-reale"));
                if (!isNaN(stock) && qty > stock) {
                    return confirm("⚠️ ATTENZIONE OVERBOOKING: Stai prenotando " + qty + " biglietti ma rimangono solo " + stock + " posti.\\n\\nVuoi forzare l\'operazione?");
                }
                return true; 
            }

            var form = $("#cv-botteghino-form");
            var methodInput = $("#fai_metodo_pagamento");

            // Bottone Carta
            $("#cv-btn-submit-link").on("click", function(e) {
                e.preventDefault();
                if(form[0].checkValidity()) {
                    if(!checkOverbooking()) return;
                    methodInput.val("link");
                    $(this).text("⏳ Invio...");
                    form.submit();
                } else {
                    form[0].reportValidity();
                }
            });

            // Bottone Contanti
            $("#cv-btn-submit-cash").on("click", function(e) {
                e.preventDefault();
                if(form[0].checkValidity()) {
                    if(!checkOverbooking()) return;
                    
                    var isAutoCheckin = $("#fai_auto_checkin").is(":checked");
                    var autoCheckinMsg = isAutoCheckin ? "\\n\\n✅ ATTENZIONE: Hai spuntato la validazione automatica. I biglietti non saranno scansionabili all\'ingresso." : "";
                    
                    if(confirm("Confermi di aver incassato l\'importo in CONTANTI?" + autoCheckinMsg)) {
                        methodInput.val("contanti");
                        $(this).text("⏳ Generazione...");
                        form.submit();
                    }
                } else {
                    form[0].reportValidity();
                }
            });

            // Bottone Autorità
            $("#cv-btn-submit-auth").on("click", function(e) {
                e.preventDefault();
                $("#fai_email").removeAttr("required");
                $("#fai_nome").removeAttr("required");
                
                if($("#fai_prodotto").val() === "") {
                    alert("Devi selezionare un evento per riservare i posti.");
                    return;
                }
                
                if(!checkOverbooking()) {
                    $("#fai_email").attr("required", true);
                    $("#fai_nome").attr("required", true);
                    return;
                }
                
                if(confirm("Confermi di voler bloccare i posti come OMAGGIO PER AUTORITÀ? \\nI biglietti verranno scalati e inseriti nel tabellone senza inviare nessuna mail.")) {
                    methodInput.val("autorita");
                    $(this).text("⏳ Generazione...");
                    form.submit();
                } else {
                    $("#fai_email").attr("required", true);
                    $("#fai_nome").attr("required", true);
                }
            });

            if ($.fn.selectWoo) {
                $("#fai_customer_search").selectWoo({
                    allowClear: true,
                    ajax: {
                        url: ajaxurl,
                        dataType: "json",
                        delay: 250,
                        data: function (params) {
                            return { action: "cv_search_customers", term: params.term, security: ajaxSecurityNonce };
                        },
                        processResults: function (data) { return { results: data }; },
                        cache: true
                    },
                    minimumInputLength: 3,
                    language: { inputTooShort: function() { return "Scrivi almeno 3 lettere..."; } }
                }).on("select2:select", function (e) {
                    var data = e.params.data;
                    if(data.id) {
                        $.post(ajaxurl, {
                            action: "cv_get_customer_data", security: ajaxSecurityNonce, customer_id: data.id
                        }, function(response) {
                            if(response.success) {
                                $("#fai_nome").val(response.data.first_name);
                                $("#fai_cognome").val(response.data.last_name);
                                $("#fai_email").val(response.data.email).css("background-color", "");
                                $("#fai_telefono").val(response.data.phone);
                            }
                        });
                    }
                }).on("select2:unselect", function(e) {
                    $("#fai_nome, #fai_cognome, #fai_email, #fai_telefono").val("");
                });
            }

            $("#fai_tessere").on("change", function() {
                var qty = parseInt($("#fai_qty").val());
                if (parseInt(this.value) > qty) { alert("Tessere superiori ai biglietti!"); this.value = qty; }
            });
            $("#fai_qty").on("change", function() {
                var tessere = parseInt($("#fai_tessere").val());
                if (tessere > parseInt(this.value)) { $("#fai_tessere").val(this.value); }
            });
        });
    </script>';
}

/**
 * 10. CREA LA STRINGA SPECIALE {nome_evento} PER LE EMAIL DI WOOCOMMERCE
 */
add_filter('woocommerce_email_format_string', 'cv_custom_email_placeholders', 20, 2);
function cv_custom_email_placeholders($string, $email)
{
    // Verifichiamo che ci sia un ordine associato a questa mail
    if (isset($email->object) && is_a($email->object, 'WC_Order')) {
        $order = $email->object;

        // Se trova la nostra stringa magica nell'oggetto della mail...
        if (strpos($string, '{nome_evento}') !== false) {
            $nomi_eventi = [];

            // ...estrae i nomi dei prodotti acquistati
            foreach ($order->get_items() as $item) {
                $nomi_eventi[] = $item->get_name();
            }

            // Unisce i nomi (se ha comprato più eventi diversi, li unisce col "+")
            $titolo_evento = implode(' + ', $nomi_eventi);

            // Sostituisce la stringa magica col vero nome dell'evento!
            $string = str_replace('{nome_evento}', $titolo_evento, $string);
        }
    }
    return $string;
}
/**
 * 11. INVIA EMAIL AL CLIENTE QUANDO LA PRENOTAZIONE SCADE E FORZA IL RIPRISTINO SCORTE
 */
add_action('woocommerce_order_status_pending_to_cancelled', 'cv_email_cliente_ordine_scaduto', 10, 2);
function cv_email_cliente_ordine_scaduto($order_id, $order)
{
    if (! $order) {
        return;
    }

    // Rimuove il ripristino automatico di WooCommerce per gestirlo manualmente ed evitare duplicati
    remove_action('woocommerce_order_status_pending_to_cancelled', 'wc_maybe_increase_stock_levels');

    // --- FIX DEFINITIVO: RIPRISTINO MATEMATICO DELLE SCORTE CON CRONOLOGIA ---
    foreach ($order->get_items() as $item) {
        $product = $item->get_product();

        // Controlla se il prodotto esiste e se ha la gestione scorte attiva
        if ($product && $product->managing_stock()) {
            $qty = $item->get_quantity();

            // 1. Leggiamo il magazzino PRIMA del ripristino
            $vecchio_stock = $product->get_stock_quantity();

            // 2. Incrementiamo lo stock e salviamo il NUOVO valore
            $nuovo_stock = wc_update_product_stock($product, $qty, 'increase');

            // 3. Generiamo la nota stile WooCommerce con la freccia (→)
            $nome_prodotto = $product->get_name();
            $nota = sprintf('🎟️ Livelli del magazzino ripristinati: %s (%d&rarr;%d) dal sistema CandleVibes.', $nome_prodotto, $vecchio_stock, $nuovo_stock);

            $order->add_order_note($nota);
        }
    }
    // ---------------------------------------------------------------

    $email_cliente = $order->get_billing_email();
    if (empty($email_cliente)) {
        return;
    }

    $nomi_eventi = [];
    foreach ($order->get_items() as $item) {
        $nomi_eventi[] = $item->get_name();
    }
    $titolo_evento = implode(' + ', $nomi_eventi);

    $mailer  = WC()->mailer();
    $subject = 'Prenotazione Scaduta - ' . $titolo_evento;

    $messaggio  = '<p>Ciao <strong>' . esc_html($order->get_billing_first_name()) . '</strong>,</p>';
    $messaggio .= '<p>Ti informiamo che la tua prenotazione temporanea (Ordine #' . $order_id . ') per <strong>' . esc_html($titolo_evento) . '</strong> è stata <strong>annullata in automatico</strong>.</p>';
    $messaggio .= '<p>Come indicato in precedenza, i posti venivano riservati per un massimo di 24 ore in attesa del saldo. Non avendo ricevuto il pagamento entro i termini prestabiliti, i biglietti sono tornati disponibili per l\'acquisto al pubblico.</p>';
    $messaggio .= '<p>Se desideri ancora partecipare al nostro evento, ti invitiamo a effettuare una nuova prenotazione sul nostro sito, compatibilmente con i posti attualmente rimasti liberi.</p>';
    $messaggio .= '<p>A presto!</p>';

    $email_html = $mailer->wrap_message('Prenotazione Scaduta', $messaggio);

    // FORMATO ARRAY: Per una codifica sicura (UTF-8) dei caratteri italiani
    $mailer->send($email_cliente, $subject, $email_html, [ 'Content-Type: text/html; charset=UTF-8' ]);
}

/**
 * 12. HUB BIGLIETTI: PANNELLO CLIENTE IBRIDO CON TRACCIAMENTO ANALITICO E BLOCCO ANNULLATI
 */
add_action('template_redirect', 'cv_render_hub_biglietti');
function cv_render_hub_biglietti()
{
    if (isset($_GET['cv_hub']) && isset($_GET['order_id']) && isset($_GET['token'])) {
        $order_id = intval($_GET['order_id']);
        $token = sanitize_text_field($_GET['token']);
        $order = wc_get_order($order_id);

        if (! $order) {
            wp_die('Ordine non trovato.');
        }

        $expected_token = hash_hmac('sha256', $order->get_order_key() . '_hub', wp_salt('nonce'));
        if (! hash_equals($expected_token, $token)) {
            wp_die('Link non valido o scaduto.', 'Errore di sicurezza');
        }

        if (! $order->has_status([ 'processing', 'completed' ])) {
            echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Ordine Non Valido</title>';
            echo '<style>body{font-family:sans-serif; background:#f0f0f1; padding:20px; display:flex; justify-content:center; align-items:center; min-height:80vh;}</style></head><body>';
            echo '<div style="background:#fff; padding:40px; border-radius:10px; text-align:center; max-width:500px; box-shadow:0 4px 15px rgba(0,0,0,0.1);">';
            echo '<h1 style="color:#d63638; margin-top:0;">🚫 Ordine Non Valido</h1>';
            echo '<p style="font-size:18px; color:#555; line-height:1.5;">I biglietti associati a questo ordine non sono più disponibili poiché la prenotazione risulta <strong>annullata, scaduta o rimborsata</strong>.</p>';
            echo '<a href="' . site_url() . '" style="display:inline-block; margin-top:25px; padding:12px 25px; background:#2271b1; color:#fff; text-decoration:none; border-radius:5px; font-weight:bold;">Torna al sito</a>';
            echo '</div></body></html>';
            exit;
        }

        $tot_biglietti = 0;
        $nomi_eventi = [];
        foreach ($order->get_items() as $item) {
            $tot_biglietti += $item->get_quantity();
            $nomi_eventi[] = $item->get_name();
        }
        $titolo_evento = implode(' + ', $nomi_eventi);
        $nome_cliente = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();

        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>I tuoi Biglietti</title>';
        echo '<style>
            body { font-family:sans-serif; background:#f0f0f1; padding:20px; max-width:600px; margin:0 auto; color:#333; } 
            .ticket-card { background:#fff; padding:20px; border-radius:10px; margin-bottom:20px; box-shadow:0 2px 5px rgba(0,0,0,0.1); text-align:center; } 
            .btn { padding:12px 15px; border-radius:5px; text-decoration:none; font-weight:bold; display:inline-block; margin-top:10px; box-sizing:border-box; width:100%; cursor:pointer; border:none; font-size:16px; } 
            .btn-print { background:#333; color:#fff; }
            .btn-wa { background:#25D366; color:#fff; }
            .btn-link { background:#2271b1; color:#fff; margin-top:5px; }
            .btn-download { background:#8b5cf6; color:#fff; margin-top:5px; }
            .qr-img { width: 200px; height: 200px; margin: 15px auto; display: block; border:1px solid #eee; padding:10px; border-radius:8px;}
            @media print {
                body { background: #fff; padding: 0; }
                .no-print { display: none !important; }
                .ticket-card { box-shadow: none; border: 2px dashed #666; page-break-inside: avoid; break-inside: avoid; margin-bottom: 25px; padding: 15px; }
                .qr-img { width: 250px; height: 250px; border:none; }
            }
        </style></head><body>';

        echo '<div style="text-align:center; margin-bottom:20px;">';
        echo '<h1 style="margin-bottom:5px;">🎟️ I tuoi Biglietti</h1>';
        echo '<p style="margin-top:0;"><strong>' . esc_html($titolo_evento) . '</strong><br>Intestati a: ' . esc_html($nome_cliente) . '<br>Ordine #' . $order_id . '</p>';
        echo '<button onclick="window.print();" class="btn btn-print no-print cv-track-btn" data-action="Stampa massiva di tutti i biglietti (PDF/Carta)">🖨️ Stampa tutti i biglietti su Carta</button>';
        echo '</div>';

        for ($i = 1; $i <= $tot_biglietti; $i++) {
            $ticket_token = hash_hmac('sha256', $order->get_order_key() . '_ticket_' . $i, wp_salt('nonce'));
            $single_ticket_url = site_url('/?cv_ticket=1&order_id=' . $order_id . '&t=' . $i . '&token=' . $ticket_token);
            $download_url = site_url('/?cv_download_qr=1&order_id=' . $order_id . '&t=' . $i . '&token=' . $ticket_token);

            $checkin_url = site_url('/?cv_checkin=1&order_id=' . $order_id . '&ticket=' . $i . '&token=' . $ticket_token);
            $qr_api_url = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($checkin_url) . '&margin=10';

            $is_validato = $order->get_meta('_cv_ticket_validato_' . $i) === 'yes';

            echo '<div class="ticket-card">';
            echo '<h3 style="margin:0 0 10px 0; color:#2271b1; font-size:20px;">Biglietto ' . $i . ' di ' . $tot_biglietti . '</h3>';

            if ($is_validato) {
                echo '<span style="color:green; font-weight:bold; background:#eaf7ea; padding:5px 15px; border-radius:20px; font-size:14px;">✅ Già Utilizzato</span>';
            } else {
                echo '<span style="color:#fff; background:#2271b1; padding:5px 15px; border-radius:20px; font-size:14px; font-weight:bold;">🎫 Valido</span>';
                echo '<img src="' . esc_url($qr_api_url) . '" class="qr-img" alt="QR Code" />';

                echo '<div class="no-print">';
                $wa_text = urlencode("Ecco il tuo biglietto (" . $i . " di " . $tot_biglietti . ") per l'evento '" . $titolo_evento . "'. Apri il link e mostra il QR all'ingresso: " . $single_ticket_url);
                echo '<a href="https://wa.me/?text=' . $wa_text . '" target="_blank" class="btn btn-wa cv-track-btn" data-action="Condivisione WhatsApp del Biglietto ' . $i . '">💬 Invia singolo biglietto su WhatsApp</a>';
                echo '<a href="' . esc_url($single_ticket_url) . '" target="_blank" class="btn btn-link cv-track-btn" data-action="Apertura link web del Biglietto ' . $i . '">🔗 Apri link del biglietto</a>';

                // NUOVO BOTTONE DOWNLOAD
                echo '<a href="' . esc_url($download_url) . '" class="btn btn-download cv-track-btn" data-action="Download Immagine QR Biglietto ' . $i . '">⬇️ Salva QR Code (Immagine)</a>';

                echo '</div>';
            }
            echo '</div>';
        }

        echo '<div class="no-print" style="text-align:center; margin-top:30px;"><a href="' . site_url() . '" style="color:#666; text-decoration:none;">Torna al sito principale</a></div>';

        // JAVASCRIPT INVISIBILE PER IL TRACCIAMENTO
        echo '<script>
            document.addEventListener("DOMContentLoaded", function() {
                var ajaxurl = "' . admin_url('admin-ajax.php') . '";
                function sendTrack(actionDesc) {
                    var formData = new FormData();
                    formData.append("action", "cv_track_ticket_action");
                    formData.append("order_id", "' . $order_id . '");
                    formData.append("token", "' . esc_js($token) . '");
                    formData.append("action_type", actionDesc);
                    fetch(ajaxurl, { method: "POST", body: formData, keepalive: true }).catch(function(){});
                }
                if (!sessionStorage.getItem("cv_hub_viewed_" + ' . $order_id . ')) {
                    sendTrack("Accesso visualizzazione Hub Biglietti");
                    sessionStorage.setItem("cv_hub_viewed_" + ' . $order_id . ', "yes");
                }
                var trackBtns = document.querySelectorAll(".cv-track-btn");
                trackBtns.forEach(function(btn) {
                    btn.addEventListener("click", function() {
                        sendTrack(this.getAttribute("data-action"));
                    });
                });
            });
        </script>';
        echo '</body></html>';
        exit;
    }
}

/**
 * 13. SINGOLO BIGLIETTO: PAGINA WEB ISOLATA CON BLOCCO ANNULLATI E DOWNLOAD
 */
add_action('template_redirect', 'cv_render_singolo_biglietto');
function cv_render_singolo_biglietto()
{
    if (isset($_GET['cv_ticket']) && isset($_GET['order_id']) && isset($_GET['t']) && isset($_GET['token'])) {
        $order_id = intval($_GET['order_id']);
        $ticket_index = intval($_GET['t']);
        $token = sanitize_text_field($_GET['token']);
        $order = wc_get_order($order_id);

        if (! $order) {
            wp_die('Ordine non trovato.');
        }

        $expected_token = hash_hmac('sha256', $order->get_order_key() . '_ticket_' . $ticket_index, wp_salt('nonce'));
        if (! hash_equals($expected_token, $token)) {
            wp_die('Link non valido o manomesso.', 'Errore Sicurezza');
        }

        if (! $order->has_status([ 'processing', 'completed' ])) {
            echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Biglietto Annullato</title>';
            echo '<style>body{font-family:sans-serif; background:#111; color:#fff; display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:100vh; margin:0; padding:20px;}</style></head><body>';
            echo '<div style="background:#fff; color:#000; border-radius:15px; padding:40px 20px; text-align:center; max-width:400px; width:100%;">';
            echo '<h2 style="color:#d63638; margin-top:0;">🚫 Biglietto Non Valido</h2>';
            echo '<p style="font-size:16px;">Questo biglietto è stato disattivato poiché la prenotazione principale risulta annullata o scaduta.</p>';
            echo '</div></body></html>';
            exit;
        }

        $nomi_eventi = [];
        $tot_biglietti = 0;
        foreach ($order->get_items() as $item) {
            $nomi_eventi[] = $item->get_name();
            $tot_biglietti += $item->get_quantity();
        }
        $titolo_evento = implode(' + ', $nomi_eventi);
        $nome_cliente = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();

        $checkin_url = site_url('/?cv_checkin=1&order_id=' . $order_id . '&ticket=' . $ticket_index . '&token=' . $token);
        $qr_api_url = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($checkin_url) . '&margin=10';

        // URL per il download forzato
        $download_url = site_url('/?cv_download_qr=1&order_id=' . $order_id . '&t=' . $ticket_index . '&token=' . $token);

        $is_validato = $order->get_meta('_cv_ticket_validato_' . $ticket_index) === 'yes';

        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Biglietto ' . $ticket_index . '</title>';
        echo '<style>body{font-family:sans-serif; background:#111; color:#fff; display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:100vh; margin:0; padding:20px; box-sizing:border-box;} .ticket-container{background:#fff; color:#000; border-radius:15px; padding:30px; text-align:center; max-width:400px; width:100%; box-shadow:0 10px 30px rgba(0,0,0,0.5);} .qr-image{width:100%; max-width:250px; height:auto; margin:20px auto 10px auto; display:block; border: 1px solid #eee; padding:10px; border-radius:10px;} .badge{background:#eaf7ea; color:#166534; padding:5px 15px; border-radius:20px; font-weight:bold; display:inline-block; margin-bottom:15px;} </style></head><body>';

        echo '<div class="ticket-container">';
        echo '<h4 style="color:#777; margin-top:0; margin-bottom:5px; text-transform:uppercase; font-size:12px;">Ingresso Evento</h4>';
        echo '<h2 style="margin:0 0 20px 0; color:#2271b1; font-size:24px;">' . esc_html($titolo_evento) . '</h2>';

        if ($is_validato) {
            echo '<div style="background:#fef2f2; color:#991b1b; padding:20px; border-radius:8px; font-size:20px; font-weight:bold; margin:30px 0;">❌ BIGLIETTO GIÀ UTILIZZATO</div>';
        } else {
            echo '<div class="badge">Biglietto ' . $ticket_index . ' di ' . $tot_biglietti . '</div>';
            echo '<img src="' . esc_url($qr_api_url) . '" class="qr-image" alt="QR Code" />';

            // IL NUOVO BOTTONE
            echo '<a href="' . esc_url($download_url) . '" style="display:inline-block; margin-bottom:20px; padding:12px 20px; background:#8b5cf6; color:#fff; text-decoration:none; border-radius:8px; font-weight:bold; font-size:16px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">⬇️ Salva QR nel telefono</a>';

            echo '<p style="font-size:14px; color:#555; margin-bottom:0;">Intestatario Ordine:</p>';
            echo '<p style="font-size:18px; margin-top:5px; margin-bottom:0;"><strong>' . esc_html($nome_cliente) . '</strong></p>';
            echo '<p style="font-size:13px; margin-top:20px; border-top:1px dashed #ccc; padding-top:15px; color:#666;">Puoi salvare il QR Code sul telefono, fare uno screenshot, oppure tenere aperto questo link per mostrarlo all\'ingresso.</p>';
        }

        echo '</div>';
        echo '</body></html>';
        exit;
    }
}

/**
 * 14. MOTORE AJAX PER IL TRACCIAMENTO DELLE AZIONI CLIENTE (STORICO BIGLIETTI)
 */
add_action('wp_ajax_nopriv_cv_track_ticket_action', 'cv_track_ticket_action_ajax');
add_action('wp_ajax_cv_track_ticket_action', 'cv_track_ticket_action_ajax');
function cv_track_ticket_action_ajax()
{
    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
    $action   = isset($_POST['action_type']) ? sanitize_text_field($_POST['action_type']) : '';
    $token    = isset($_POST['token']) ? sanitize_text_field($_POST['token']) : '';

    if (! $order_id || ! $action || ! $token) {
        wp_send_json_error();
    }

    $order = wc_get_order($order_id);
    if (! $order) {
        wp_send_json_error();
    }

    // Verifichiamo che la richiesta arrivi davvero da un link valido (Sicurezza)
    $expected_token = hash_hmac('sha256', $order->get_order_key() . '_hub', wp_salt('nonce'));
    if (! hash_equals($expected_token, $token)) {
        wp_send_json_error();
    }

    // Recupera lo storico esistente o crea un array vuoto
    $history = $order->get_meta('_cv_ticket_history');
    if (! is_array($history)) {
        $history = [];
    }

    // Aggiunge la nuova azione con data e ora
    $history[] = [
        'time'   => current_time('mysql'),
        'action' => $action,
    ];

    // FIX CLAUDE: Mantieni solo gli ultimi 50 eventi per evitare di intasare il DB
    if (count($history) > 50) {
        $history = array_slice($history, -50);
    }

    // Salva nel database
    $order->update_meta_data('_cv_ticket_history', $history);
    $order->save();

    wp_send_json_success();
}

/**
 * 15. SPAZZINO AUTOMATICO: FORZA L'ANNULLAMENTO DEGLI ORDINI IN ATTESA DA OLTRE 24 ORE
 */
add_action('init', 'cv_forza_annullamento_ordini_scaduti');
function cv_forza_annullamento_ordini_scaduti()
{
    // Il "Lucchetto": Eseguiamo la query pesante al massimo una volta ogni 15 minuti
    if (get_transient('cv_spazzino_ordini_lock')) {
        return;
    }
    set_transient('cv_spazzino_ordini_lock', 1, 15 * MINUTE_IN_SECONDS);

    // Calcoliamo l'esatto momento di "24 ore fa"
    $limite_tempo = time() - (24 * 60 * 60); // 24 ore in secondi

    // Cerchiamo nel DB tutti gli ordini 'pending' più vecchi del limite
    $ordini_scaduti = wc_get_orders([
        'status'       => 'pending',
        'limit'        => -1,
        'date_created' => '<' . $limite_tempo,
    ]);

    // Se ne troviamo, li annulliamo uno per uno
    if (! empty($ordini_scaduti)) {
        foreach ($ordini_scaduti as $order) {
            // L'update_status su 'cancelled' farà scattare la nostra funzione di ripristino scorte (Blocco 11)
            $order->update_status('cancelled', '⏰ Ordine annullato automaticamente dal sistema (scadute le 24 ore in attesa).');
        }
    }
}

/**
 * 16. SENSORE DI TRACCIAMENTO CLICK SUL LINK DI PAGAMENTO
 */
add_action('template_redirect', 'cv_track_payment_page_visit');
function cv_track_payment_page_visit()
{
    // Verifichiamo se l'utente si trova sulla pagina di pagamento di WooCommerce
    if (is_wc_endpoint_url('order-pay')) {
        global $wp;
        $order_id = absint($wp->query_vars['order-pay']);

        // Se c'è un ordine e c'è il nostro parametro magico nell'URL...
        if ($order_id && isset($_GET['cv_track_pay'])) {
            $order = wc_get_order($order_id);

            if ($order) {
                // Mettiamo un lucchetto di 12 ore per evitare di riempire le note
                // se il cliente ricarica la pagina più volte
                $lock_key = 'cv_tracked_pay_' . $order_id;

                if (! get_transient($lock_key)) {
                    $order->add_order_note('👀 <strong>TRACCIAMENTO:</strong> Il cliente ha aperto la mail e ha cliccato sul link di pagamento.');
                    set_transient($lock_key, 1, 12 * HOUR_IN_SECONDS);
                }
            }
        }
    }
}

/**
 * 17. ETICHETTA QUALIFICA (SOCIO FAI / AUTORITÀ / CASSA LIVE / STANDARD) NEGLI ORDINI WOOCOMMERCE
 */

// Funzione helper 1: Scopre se l'ordine ha lo sconto FAI (da backend o frontend)
function cv_is_order_fai($order)
{
    if (! $order) {
        return false;
    }

    // 1. Controllo Coupon usato dal cliente
    $coupons = $order->get_coupon_codes();
    if (in_array('socio_fai_novara_2025', array_map('strtolower', $coupons))) {
        return true;
    }

    // 2. Controllo sconto applicato dal Generatore Rapido Backend
    foreach ($order->get_items('fee') as $item) {
        if (strpos(strtolower($item->get_name()), 'fai') !== false) {
            return true;
        }
    }

    return false;
}

// NUOVA Funzione helper 2: Genera le etichette visive corrette (Supporta Multi-Badge)
function cv_get_order_qualifica_label($order)
{
    if (! $order) {
        return '';
    }

    $badges = [];

    // 1. Autorità
    if ($order->get_meta('_cv_is_authority') === 'yes') {
        $badges[] = '<span style="background:#6b21a8; color:#fff; padding:4px 8px; border-radius:4px; font-weight:bold; font-size:11px; white-space:nowrap; display:inline-block; margin-right:4px; margin-bottom:4px;">🌟 AUTORITÀ</span>';
    }

    // 2. Botteghino Contanti (Retroattivo tramite titolo metodo di pagamento)
    if ($order->get_payment_method_title() === 'Contanti in Loco (Botteghino)') {
        $badges[] = '<span style="background:#16a34a; color:#fff; padding:4px 8px; border-radius:4px; font-weight:bold; font-size:11px; white-space:nowrap; display:inline-block; margin-right:4px; margin-bottom:4px;">💵 CASSA LIVE</span>';
    }

    // 3. Socio FAI
    if (cv_is_order_fai($order)) {
        $badges[] = '<span style="background:#ff6600; color:#fff; padding:4px 8px; border-radius:4px; font-weight:bold; font-size:11px; white-space:nowrap; display:inline-block; margin-right:4px; margin-bottom:4px;">SOCIO FAI</span>';
    }

    // 4. Standard (Si attiva solo se non ha nessun altro badge speciale)
    if (empty($badges)) {
        return '<span style="color:#aaa; font-size:12px;">Standard</span>';
    }

    // Unisce tutti i badge trovati
    return implode('', $badges);
}

// Aggiunge la colonna "Qualifica" alla lista Ordini nativa di WooCommerce
add_filter('manage_woocommerce_page_wc-orders_columns', 'cv_add_fai_column_to_orders');
add_filter('manage_edit-shop_order_columns', 'cv_add_fai_column_to_orders');
function cv_add_fai_column_to_orders($columns)
{
    $new_columns = [];
    foreach ($columns as $key => $column) {
        $new_columns[$key] = $column;
        if ('order_status' === $key) { // La posizioniamo subito dopo lo Stato dell'ordine
            $new_columns['cv_fai_status'] = 'Qualifica';
        }
    }
    return $new_columns;
}

// Stampa i Badge dentro la colonna di WooCommerce usando la nuova funzione
add_action('manage_woocommerce_page_wc-orders_custom_column', 'cv_populate_fai_column', 10, 2);
add_action('manage_shop_order_posts_custom_column', 'cv_populate_fai_column', 10, 2);
function cv_populate_fai_column($column, $order_id)
{
    if ('cv_fai_status' === $column) {
        $order = wc_get_order($order_id);
        echo cv_get_order_qualifica_label($order);
    }
}

/**
 * 18. SHORTCODE PER WIDGET FLUTTUANTE "BOLLA PURA" (Morphing B&W, Senza Chevron)
 * Uso: Inserire [cv_login_biglietti] nell'header o in Elementor.
 */
add_shortcode('cv_login_biglietti', 'cv_render_login_biglietti_shortcode');
function cv_render_login_biglietti_shortcode()
{
    $account_url = wc_get_page_permalink('myaccount');

    // ICONE VETTORIALI INLINE (Infallibili e pulite)
    $icona_utente = '<svg class="cv-main-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>';
    $icona_ticket = '<svg class="cv-main-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"></path><path d="M9 9h.01"></path><path d="M15 9h.01"></path><path d="M12 9h.01"></path><path d="M9 15h.01"></path><path d="M15 15h.01"></path><path d="M12 15h.01"></path></svg>';

    // CSS MINIMALISTA PURO (Bianco e Nero, Senza Chevron)
    $style = '<style>
        .cv-dynamic-login-btn {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            position: relative;
            
            /* --- STATO DI DEFAULT: BOLLA BIANCA PURA E CIRCOLARE --- */
            width: 60px; /* Cerchio perfetto compressa */
            height: 60px;
            padding: 0;
            border-radius: 50px;
            
            background: #ffffff !important;
            color: #111111 !important; /* Testo e icone neri */
            text-decoration: none !important;
            
            /* Ombra e Bordo sottile stile Carrello */
            box-shadow: 0 4px 15px rgba(0,0,0,0.1) !important;
            border: 1px solid #eaeaea !important;
            
            /* Transizione burrosa e rallentata */
            transition: width 0.8s cubic-bezier(0.19, 1, 0.22, 1), 
                        box-shadow 0.3s ease,
                        background 0.3s ease;
            
            overflow: hidden; /* Nasconde il testo quando compressa */
            white-space: nowrap;
            cursor: pointer;
            z-index: 99990;
            will-change: width, box-shadow;
        }

        /* Stile dell\'icona Vettoriale Principale */
        .cv-main-icon {
            width: 60px; /* Centrata perfettamente nella bolla compressa */
            height: 24px;
            flex-shrink: 0;
            color: #111111;
            transition: transform 0.3s ease;
        }

        /* Leggera animazione icona all\'hover */
        .cv-dynamic-login-btn:hover .cv-main-icon {
            transform: scale(1.05);
        }

        /* --- GESTIONE DEL TESTO (Nascosto di default) --- */
        .cv-btn-text {
            font-weight: 700;
            font-size: 15px;
            opacity: 0;
            visibility: hidden;
            transform: translateX(-15px); /* Parte più a sinistra */
            /* Appare con ritardo per seguire il morphing lento */
            transition: opacity 0.5s ease 0.4s, transform 0.5s ease 0.4s;
            margin-left: -5px; /* Avvicina il testo all\'icona */
        }

        /* --- STATO ESPANSO (Hover e Click) --- */
        .cv-dynamic-login-btn:hover,
        .cv-dynamic-login-btn:active,
        .cv-dynamic-login-btn:focus {
            width: 220px; /* Espansione a pillola */
            box-shadow: 0 10px 30px rgba(0,0,0,0.18) !important;
            background: #ffffff !important; /* Mantiene sfondo bianco */
        }
        
        /* Larghezze specifiche per i testi */
        .cv-dynamic-login-btn.logged-out:hover { width: 220px; } /* "Accedi / Registrati" */
        .cv-dynamic-login-btn.logged-in:hover { width: 180px; }  /* "I Miei Biglietti" */

        /* Il testo appare */
        .cv-dynamic-login-btn:hover .cv-btn-text,
        .cv-dynamic-login-btn:active .cv-btn-text,
        .cv-dynamic-login-btn:focus .cv-btn-text {
            opacity: 1;
            visibility: visible;
            transform: translateX(0);
        }

        /* --- COLORI DI STATO (Bagliore Soft) --- */
        
        /* Animazione Pulsazione Soft centrata sulla bolla pulita */
        @keyframes cvStatePulseSoft {
            0% { box-shadow: 0 4px 15px rgba(0,0,0,0.1) !important; }
            50% { box-shadow: 0 4px 25px var(--pulse-color) !important; }
            100% { box-shadow: 0 4px 15px rgba(0,0,0,0.1) !important; }
        }

        /* Logged-out (Blu) */
        .cv-dynamic-login-btn.logged-out {
            --pulse-color: rgba(34, 113, 177, 0.25);
            animation: cvPremiumSlideIn 0.8s ease, cvStatePulseSoft 2.5s infinite 1s;
        }
        .cv-dynamic-login-btn.logged-out:hover {
            animation: none; /* Ferma pulsazione all\'hover */
            box-shadow: 0 10px 30px rgba(34, 113, 177, 0.3) !important;
        }

        /* Logged-in (Arancione) */
        .cv-dynamic-login-btn.logged-in {
            --pulse-color: rgba(255, 102, 0, 0.25);
            animation: cvPremiumSlideIn 0.8s ease, cvStatePulseSoft 2.5s infinite 1s;
        }
        .cv-dynamic-login-btn.logged-in:hover {
            animation: none; /* Ferma pulsazione all\'hover */
            box-shadow: 0 10px 30px rgba(255, 102, 0, 0.3) !important;
        }

        /* --- ADATTAMENTO MOBILE --- */
        @media (max-width: 768px) {
            .cv-dynamic-login-btn {
                width: 50px;
                height: 50px;
            }
            .cv-main-icon {
                width: 50px;
                height: 20px;
            }
            .cv-dynamic-login-btn:active,
            .cv-dynamic-login-btn:focus {
                width: 190px;
            }
            .cv-dynamic-login-btn.logged-in:active,
            .cv-dynamic-login-btn.logged-in:focus {
                width: 165px;
            }
        }
    </style>';

    // STRUTTURA HTML PULITA (Senza Span per Chevron)
    if (is_user_logged_in()) {
        $ordini_url = wc_get_endpoint_url('orders', '', $account_url);
        $bottone = '<a href="' . esc_url($ordini_url) . '" class="cv-dynamic-login-btn logged-in">' . $icona_ticket . '<span class="cv-btn-text">I Miei Biglietti</span></a>';
    } else {
        $bottone = '<a href="' . esc_url($account_url) . '" class="cv-dynamic-login-btn logged-out">' . $icona_utente . '<span class="cv-btn-text">Accedi / Registrati</span></a>';
    }

    return $style . $bottone;
}

/**
 * 19. INIETTA IL BOTTONE LOGIN/BIGLIETTI COME ELEMENTO FLUTTUANTE (NUOVA POSIZIONE E ANIMAZIONE)
 */
add_action('wp_footer', 'cv_inietta_bottone_fluttuante');
function cv_inietta_bottone_fluttuante()
{
    // Nascondiamo il bottone nelle pagine critiche ( checkout, carrello e MIO ACCOUNT )
    if (is_checkout() || is_cart() || is_account_page()) {
        return;
    }

    echo '<div class="cv-floating-widget">';
    echo do_shortcode('[cv_login_biglietti]');
    echo '</div>';

    echo '<style>
        .cv-floating-widget {
            position: fixed;
            /* Leggermente più allontanato dal bordo per un effetto più equilibrato */
            top: 30px;
            right: 30px;
            z-index: 99990; /* Sotto ai popup/carrello, sopra alla pagina */
            
            /* NUOVA ANIMAZIONE DI INGRESSO SLIDE-IN */
            animation: cvPremiumSlideIn 0.8s cubic-bezier(0.23, 1, 0.32, 1) both;
            
            /* Previene lag su mobile */
            will-change: transform, opacity;
        }

        /* Definizione dell\'animazione SLIDE-IN (dal basso-destra, con rotazione) */
        @keyframes cvPremiumSlideIn {
            0% {
                opacity: 0;
                transform: translate(30px, 30px) rotate(5deg) scale(0.9);
            }
            100% {
                opacity: 1;
                transform: translate(0, 0) rotate(0) scale(1);
            }
        }
        
        @media (max-width: 768px) {
            .cv-floating-widget {
                top: 20px;
                right: 20px;
            }
        }
    </style>';
}

/**
 * 20. ASSOCIA GLI ORDINI PASSATI (OSPITI) AL NUOVO ACCOUNT APPENA CREATO
 */
add_action('woocommerce_created_customer', 'cv_associa_ordini_passati_al_nuovo_account', 10, 1);
function cv_associa_ordini_passati_al_nuovo_account($customer_id)
{
    // Sfruttiamo una potentissima ma poco conosciuta funzione nativa di WooCommerce
    // che va a cercare nel database tutti gli ordini "Ospite" fatti in passato con questa email
    // e li aggancia al nuovo account appena nato.
    if (function_exists('wc_update_new_customer_past_orders')) {
        wc_update_new_customer_past_orders($customer_id);
    }
}

/**
 * 21. AGGIUNGE IL BOTTONE "MOSTRA BIGLIETTI" NELLA BACHECA DEL CLIENTE
 */
add_filter('woocommerce_my_account_my_orders_actions', 'cv_aggiungi_bottone_hub_ordini', 10, 2);
function cv_aggiungi_bottone_hub_ordini($actions, $order)
{
    // Mostriamo il bottone ESCLUSIVAMENTE se l'ordine non è annullato o in attesa
    if ($order->has_status([ 'processing', 'completed' ])) {

        $hub_token = hash_hmac('sha256', $order->get_order_key() . '_hub', wp_salt('nonce'));
        $hub_url = site_url('/?cv_hub=1&order_id=' . $order->get_id() . '&token=' . $hub_token);

        // Creiamo la nostra azione personalizzata
        $azione_biglietti = [
            'cv_biglietti' => [
                'url'  => $hub_url,
                'name' => '🎟️ Mostra Biglietti',
            ],
        ];

        // La inseriamo come primissimo bottone (prima di "Visualizza" o "Fattura")
        $actions = array_merge($azione_biglietti, $actions);
    }
    return $actions;
}

// Coloriamo il bottone per farlo risaltare rispetto agli altri tasti grigi di WooCommerce
add_action('wp_head', 'cv_stile_bottone_hub_ordini');
function cv_stile_bottone_hub_ordini()
{
    // Iniettiamo il CSS solo se l'utente si trova nella sua area riservata
    if (is_account_page()) {
        echo '<style>
            a.button.cv_biglietti {
                background-color: #2271b1 !important;
                color: #ffffff !important;
                font-weight: bold;
                border: none !important;
            }
            a.button.cv_biglietti:hover {
                background-color: #135e96 !important;
            }
        </style>';
    }
}

/**
 * 22. STILE MODERNO E APP-LIKE PER LA PAGINA "MIO ACCOUNT" (BOTTEGHINO PERSONALE, TABELLE E DETTAGLI)
 */
add_action('wp_head', 'cv_stile_moderno_mio_account');
function cv_stile_moderno_mio_account()
{
    if (is_account_page()) {
        echo '<style>
            /* FORZIAMO LA VISIBILITA\' DEL MESSAGGIO VUOTO CHE IL TEMA NASCONDEVA */
            .woocommerce-account .woocommerce-info {
                display: block !important; visibility: visible !important; opacity: 1 !important;
                background: #eaf7ea !important; color: #166534 !important; border-top: 4px solid #166534 !important;
                padding: 20px !important; border-radius: 8px !important; font-size: 16px !important; line-height: 1.5;
            }
            .woocommerce-account .woocommerce-info::before, .woocommerce-account .woocommerce-info .button {
                display: none !important;
            }

            /* SPEGNIMENTO DEFINITIVO DEL PLUGIN CARRELLO (Massima Specificità) */
            html body.woocommerce-account .xoo-wsc-basket,
            html body.woocommerce-account .xoo-wsc-modal,
            html body.woocommerce-account .xoo-wsc-cart-active { 
                display: none !important; visibility: hidden !important; opacity: 0 !important; 
                pointer-events: none !important; z-index: -9999 !important;
            }

            /* --- STILE DESKTOP (Effetto Vetro Allargato) --- */
            .woocommerce-account .woocommerce {
                max-width: 1300px; margin: 40px auto; background: rgba(255, 255, 255, 0.95);
                padding: 50px; border-radius: 20px; box-shadow: 0 15px 50px rgba(0,0,0,0.1);
            }
            .woocommerce-account.logged-in .woocommerce { display: flex; flex-wrap: wrap; gap: 50px; }
            .woocommerce-MyAccount-navigation { flex: 1 1 250px; }
            .woocommerce-MyAccount-navigation ul { list-style: none !important; padding: 0 !important; margin: 0 !important; }
            .woocommerce-MyAccount-navigation ul li { margin-bottom: 8px; }
            .woocommerce-MyAccount-navigation ul li a {
                display: block; padding: 15px 20px; background: #f8f9fa; color: #1d2327 !important;
                text-decoration: none; border-radius: 10px; font-weight: 600; font-size: 15px;
                transition: all 0.3s ease; border: 1px solid transparent;
            }
            .woocommerce-MyAccount-navigation ul li a:hover { background: #fff; border-color: #e2e4e7; transform: translateX(5px); box-shadow: 0 4px 10px rgba(0,0,0,0.03); }
            .woocommerce-MyAccount-navigation ul li.is-active a {
                background: #2271b1 !important; color: #ffffff !important; border-color: #2271b1 !important; box-shadow: 0 6px 15px rgba(34, 113, 177, 0.25);
            }

            .woocommerce-MyAccount-content { flex: 3 1 750px; color: #444; font-size: 16px; line-height: 1.6; }
            .woocommerce-MyAccount-content mark { background: transparent; color: #2271b1; font-weight: bold; }
            
            /* --- 🎨 RESTYLING PREMIUM TABELLA ORDINI PRINCIPALE --- */
            .woocommerce-orders-table {
                border: none !important; border-collapse: separate !important; border-spacing: 0 16px !important;
                width: 100% !important; margin-top: -16px;
            }
            .woocommerce-orders-table thead th {
                background: transparent !important; border: none !important;
                color: #9ca3af !important; text-transform: uppercase; font-size: 12px; font-weight: 700;
                letter-spacing: 1px; padding: 0 25px 10px 25px !important; text-align: left;
            }
            .woocommerce-orders-table tbody tr {
                box-shadow: 0 4px 15px rgba(0,0,0,0.05) !important;
                border-radius: 12px !important; background: #ffffff !important;
                transition: transform 0.25s ease, box-shadow 0.25s ease;
            }
            .woocommerce-orders-table tbody tr:hover {
                transform: translateY(-3px); box-shadow: 0 10px 25px rgba(0,0,0,0.08) !important;
            }
            .woocommerce-orders-table tbody th, .woocommerce-orders-table tbody td {
                background: #ffffff !important; border: none !important;
                padding: 25px !important; vertical-align: middle !important; color: #4b5563 !important;
            }
            .woocommerce-orders-table tbody th:first-child, .woocommerce-orders-table tbody td:first-child { border-radius: 12px 0 0 12px !important; }
            .woocommerce-orders-table tbody td:last-child { border-radius: 0 12px 12px 0 !important; }

            .woocommerce-orders-table tbody th.woocommerce-orders-table__cell-order-number a {
                background: #f0f6fc !important; color: #2271b1 !important; padding: 10px 18px !important; border-radius: 8px !important;
                text-decoration: none !important; font-weight: 800 !important; font-size: 16px !important; display: inline-block !important; transition: all 0.2s;
            }
            .woocommerce-orders-table tbody th.woocommerce-orders-table__cell-order-number a:hover { background: #e1effa !important; color: #135e96 !important; }

            .woocommerce-orders-table tbody td.woocommerce-orders-table__cell-order-actions {
                text-align: right !important; white-space: nowrap !important; width: 1% !important;
            }
            .woocommerce-orders-table__cell-order-actions .button {
                display: inline-block !important; margin: 0 0 0 10px !important; padding: 10px 20px !important; border-radius: 50px !important;
                font-size: 13px !important; font-weight: 700 !important; text-transform: uppercase !important; letter-spacing: 0.5px !important;
                background: #f3f4f6 !important; color: #4b5563 !important; border: none !important;
                transition: all 0.3s ease !important; text-decoration: none !important;
            }
            .woocommerce-orders-table__cell-order-actions .button:hover { background: #e5e7eb !important; transform: translateY(-1px); }
            
            /* --- 🎨 RESTYLING DETTAGLI ORDINE (PAGINA SINGOLA) --- */
            .woocommerce-order-details { margin-top: 30px; margin-bottom: 40px; }
            .woocommerce-order-details h2, .woocommerce-customer-details h2 {
                font-size: 22px; color: #1d2327; margin-bottom: 20px; font-weight: 700;
            }
            
            .woocommerce-table--order-details {
                background: #ffffff !important; border-radius: 15px !important;
                box-shadow: 0 4px 15px rgba(0,0,0,0.05) !important; border: none !important;
                overflow: hidden; width: 100% !important; border-collapse: collapse !important;
            }
            .woocommerce-table--order-details thead th {
                background: #f8f9fa !important; color: #6b7280 !important; text-transform: uppercase; 
                font-size: 12px; font-weight: 700; letter-spacing: 1px; padding: 20px 25px !important; border: none !important;
            }
            .woocommerce-table--order-details tbody td, 
            .woocommerce-table--order-details tfoot td, 
            .woocommerce-table--order-details tfoot th {
                padding: 20px 25px !important; border: none !important; border-bottom: 1px solid #f3f4f6 !important;
                color: #4b5563 !important; background: #ffffff !important; vertical-align: middle;
            }
            .woocommerce-table--order-details tbody tr:last-child td { border-bottom: 2px solid #e5e7eb !important; }
            .woocommerce-table--order-details tfoot tr:last-child th, 
            .woocommerce-table--order-details tfoot tr:last-child td { border-bottom: none !important; }
            .woocommerce-table--order-details tfoot th { font-weight: 600; color: #1d2327 !important; }
            .woocommerce-table--order-details tfoot td { font-weight: 700; }

            .woocommerce-table--order-details td.woocommerce-table__product-name a {
                color: #2271b1 !important; text-decoration: none !important; font-weight: 700; font-size: 16px;
            }
            .woocommerce-table--order-details td.woocommerce-table__product-name a:hover { color: #135e96 !important; }
            
            .woocommerce-table--order-details tfoot .button {
                display: inline-block !important; margin: 5px 10px 5px 0 !important; padding: 10px 20px !important; border-radius: 50px !important;
                font-size: 13px !important; font-weight: 700 !important; text-transform: uppercase !important; letter-spacing: 0.5px !important;
                border: none !important; transition: all 0.3s ease !important; text-decoration: none !important;
            }

            .woocommerce-customer-details address {
                background: #ffffff !important; border-radius: 15px !important; box-shadow: 0 4px 15px rgba(0,0,0,0.05) !important;
                border: none !important; padding: 30px !important; font-style: normal !important; line-height: 1.8 !important; color: #4b5563 !important;
            }

            .button.pay { background: #10b981 !important; color: white !important; box-shadow: 0 4px 10px rgba(16, 185, 129, 0.2); }
            .button.pay:hover { background: #059669 !important; box-shadow: 0 6px 14px rgba(16, 185, 129, 0.3); transform: translateY(-1px); }
            .button.cancel { background: #fee2e2 !important; color: #ef4444 !important; }
            .button.cancel:hover { background: #fecaca !important; transform: translateY(-1px); }
            .button.cv_biglietti { background: #2271b1 !important; color: white !important; box-shadow: 0 4px 10px rgba(34, 113, 177, 0.2); }
            .button.cv_biglietti:hover { background: #135e96 !important; transform: translateY(-1px); }

            /* --- STILE MOBILE --- */
            @media (max-width: 768px) {
                body { padding-bottom: 85px !important; }
                .woocommerce-account .woocommerce { padding: 30px 20px; margin: 15px 10px; gap: 30px; border-radius: 15px; }
                
                .woocommerce-MyAccount-navigation {
                    position: fixed; bottom: 0; left: 0; width: 100%; background: #ffffff; box-shadow: 0 -5px 20px rgba(0,0,0,0.08);
                    z-index: 99999; padding: 10px 0 15px 0; border-top: 1px solid #f3f4f6;
                }
                .woocommerce-MyAccount-navigation ul { display: flex !important; flex-direction: row !important; justify-content: space-around !important; align-items: center !important; }
                .woocommerce-MyAccount-navigation ul li { margin-bottom: 0 !important; flex: 1; text-align: center; }
                .woocommerce-MyAccount-navigation ul li a { background: transparent !important; border: none !important; padding: 5px !important; font-size: 11px !important; color: #9ca3af !important; box-shadow: none !important; line-height: 1.2; }
                
                /* FIX MENU MOBILE: Rimosso lo sfondo e l\'ombra per la voce attiva */
                .woocommerce-MyAccount-navigation ul li.is-active a { 
                    background: transparent !important; 
                    box-shadow: none !important; 
                    color: #2271b1 !important; 
                    font-weight: bold; 
                }
                
                .woocommerce-MyAccount-navigation-link--dashboard a::before { content: "🏠"; }
                .woocommerce-MyAccount-navigation-link--orders a::before { content: "🎟️"; }
                .woocommerce-MyAccount-navigation-link--cart a::before { content: "🛍️"; }
                .woocommerce-MyAccount-navigation-link--edit-account a::before { content: "⚙️"; }
                .woocommerce-MyAccount-navigation-link--customer-logout a::before { content: "🚪"; }
                .woocommerce-MyAccount-navigation ul li a::before { font-size: 22px; display: block; margin-bottom: 4px; filter: grayscale(100%); opacity: 0.6; transition: all 0.2s; }
                .woocommerce-MyAccount-navigation ul li.is-active a::before { filter: none; opacity: 1; }

                /* Tabella ordini Mobile */
                .woocommerce-orders-table thead { display: none; }
                .woocommerce-orders-table tbody tr { display: block; margin-bottom: 25px; padding: 10px 0; }
                .woocommerce-orders-table tbody th, .woocommerce-orders-table tbody td { display: flex !important; justify-content: space-between; align-items: center; border: none !important; border-bottom: 1px solid #f3f4f6 !important; padding: 15px 20px !important; border-radius: 0 !important; }
                .woocommerce-orders-table tbody td:last-child { border-bottom: none !important; flex-direction: column; align-items: stretch; gap: 12px; margin-top: 5px; }
                .woocommerce-orders-table tbody th::before, .woocommerce-orders-table tbody td::before { content: attr(data-title); font-weight: 700; color: #9ca3af; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px; }
                .woocommerce-orders-table tbody td.woocommerce-orders-table__cell-order-actions { white-space: normal !important; width: 100% !important; flex-direction: column !important; gap: 10px !important; }
                .woocommerce-orders-table__cell-order-actions .button { width: 100%; margin: 0 !important; padding: 15px !important; text-align: center; }
                
                /* Dettagli Ordine Mobile */
                .woocommerce-table--order-details tfoot .button { width: 100% !important; margin: 10px 0 0 0 !important; text-align: center; }
            }
        </style>';
    }
}

/**
 * 23. PULIZIA MENU WOOCOMMERCE E AGGIUNTA CARRELLO NELLA NAVIGAZIONE
 */
add_filter('woocommerce_account_menu_items', 'cv_rimuovi_voci_menu_account');
function cv_rimuovi_voci_menu_account($items)
{
    unset($items['downloads']);
    unset($items['edit-address']);
    unset($items['payment-methods']);

    if (isset($items['orders'])) {
        $items['orders'] = 'I Miei Biglietti';
    }

    // Aggiungiamo la voce Carrello prima del logout
    $nuovo_menu = [];
    foreach ($items as $key => $value) {
        if ('customer-logout' === $key) {
            $nuovo_menu['cart'] = 'Carrello';
        }
        $nuovo_menu[$key] = $value;
    }

    return $nuovo_menu;
}

// Associamo il bottone "Carrello" all'URL reale della pagina carrello
add_filter('woocommerce_get_endpoint_url', 'cv_collega_bottone_carrello', 10, 2);
function cv_collega_bottone_carrello($url, $endpoint)
{
    if ('cart' === $endpoint) {
        return wc_get_cart_url();
    }
    return $url;
}

/**
 * 24. MESSAGGIO PERSONALIZZATO SE L'UTENTE NON HA ANCORA ACQUISTATO BIGLIETTI
 */
add_filter('gettext', 'cv_personalizza_testo_ordini_vuoti', 10, 3);
function cv_personalizza_testo_ordini_vuoti($translated_text, $text, $domain)
{
    if ('woocommerce' === $domain) {
        if ('No order has been made yet.' === $text) {
            $translated_text = 'Non hai ancora acquistato nessun biglietto. Visita il nostro calendario per scoprire i prossimi eventi e accendere la magia!';
        }
    }
    return $translated_text;
}

/**
 * 25. STILE MODERNO PER LA PAGINA DI LOGIN E REGISTRAZIONE WOOCOMMERCE
 */
add_action('wp_head', 'cv_stile_moderno_login');
function cv_stile_moderno_login()
{
    // Applichiamo questo stile SOLO nella pagina account e SOLO se l'utente NON è loggato
    if (is_account_page() && ! is_user_logged_in()) {
        echo '<style>
            /* Contenitore principale con effetto Vetro */
            .woocommerce-account:not(.logged-in) .woocommerce {
                max-width: 1200px;
                margin: 40px auto;
                background: rgba(255, 255, 255, 0.95);
                padding: 40px;
                border-radius: 15px;
                box-shadow: 0 15px 40px rgba(0,0,0,0.15);
            }

            /* Layout a due colonne per Login (sx) e Registrazione (dx) */
            .woocommerce-account:not(.logged-in) #customer_login {
                display: flex;
                flex-wrap: wrap;
                gap: 40px;
            }

            /* Stile dei singoli box (Accedi / Registrati) */
            .woocommerce-account:not(.logged-in) .u-column1,
            .woocommerce-account:not(.logged-in) .u-column2 {
                flex: 1 1 300px;
                width: 100%;
                background: #f8f9fa;
                padding: 30px;
                border-radius: 10px;
                border: 1px solid #e2e4e7;
            }

            .woocommerce-account:not(.logged-in) h2 {
                margin-top: 0;
                color: #2271b1;
                font-size: 24px;
                margin-bottom: 20px;
                border-bottom: 2px solid #eee;
                padding-bottom: 10px;
            }

            /* Stile dei campi di testo */
            .woocommerce-account:not(.logged-in) form.login input[type="text"],
            .woocommerce-account:not(.logged-in) form.login input[type="password"],
            .woocommerce-account:not(.logged-in) form.register input[type="email"] {
                width: 100%;
                padding: 12px 15px;
                border: 1px solid #ccc;
                border-radius: 6px;
                margin-bottom: 15px;
                font-size: 16px;
            }

            /* Stile dei bottoni (Accedi / Registrati) */
            .woocommerce-account:not(.logged-in) button.woocommerce-button {
                background-color: #2271b1 !important;
                color: #fff !important;
                border: none;
                padding: 12px 25px;
                font-size: 16px;
                font-weight: bold;
                border-radius: 6px;
                width: 100%;
                margin-top: 10px;
                cursor: pointer;
                transition: background-color 0.3s;
            }
            
            .woocommerce-account:not(.logged-in) button.woocommerce-button:hover {
                background-color: #135e96 !important;
            }

            /* Link "Password dimenticata?" */
            .woocommerce-account:not(.logged-in) .woocommerce-LostPassword a {
                color: #ff6600;
                text-decoration: none;
                display: block;
                margin-top: 15px;
                text-align: center;
                font-weight: bold;
            }

            /* Testo descrittivo WooCommerce */
            .woocommerce-account:not(.logged-in) p.woocommerce-FormRow {
                margin-bottom: 15px;
                color: #555;
            }

            /* Mobile */
            @media (max-width: 768px) {
                .woocommerce-account:not(.logged-in) .woocommerce {
                    padding: 20px;
                    margin: 20px 10px;
                }
                .woocommerce-account:not(.logged-in) #customer_login {
                    gap: 30px;
                }
            }
        </style>';
    }
}

/**
 * 26. BLOCCO LOGIN AUTOMATICO DOPO LA REGISTRAZIONE E AVVISO VERIFICA EMAIL
 */

// 1. Impedisce a WooCommerce di loggare automaticamente il nuovo cliente
add_filter('woocommerce_registration_auth_new_customer', '__return_false');

// 2. Aggiunge un messaggio chiaro e lo reindirizza al modulo di accesso
add_filter('woocommerce_registration_redirect', 'cv_avviso_dopo_registrazione', 10, 1);
function cv_avviso_dopo_registrazione($redirect_url)
{

    // Generiamo il banner verde di successo con le istruzioni
    wc_add_notice('Registrazione completata! 📧 Ti abbiamo inviato una password sicura via email. Controlla la posta (anche nello Spam) e usala per accedere al tuo Botteghino Personale.', 'success');

    // Lo facciamo restare sulla pagina "Mio Account" per permettergli di fare il login vero e proprio
    return wc_get_page_permalink('myaccount');
}

/**
 * 27. MOTORE AJAX PER L'INVIO DEI REMINDER (MASSIVO A SCAGLIONI O SINGOLO)
 */
add_action('wp_ajax_cv_send_event_reminders', 'cv_send_event_reminders_ajax');
function cv_send_event_reminders_ajax()
{
    check_ajax_referer('cv_reminder_nonce', 'security');
    if (! current_user_can('manage_woocommerce')) {
        wp_send_json_error('Permessi insufficienti.');
    }

    $event_id = isset($_POST['event_id']) ? intval($_POST['event_id']) : 0;
    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;

    if (! $event_id && ! $order_id) {
        wp_send_json_error('Nessun ordine o evento specificato.');
    }

    if ($order_id) {
        $order = wc_get_order($order_id);
        if (! $order) {
            wp_send_json_error('Ordine non trovato.');
        }
        $orders = [ $order ];
        $is_single = true;
    } else {
        $orders = wc_get_orders([
            'status'     => [ 'wc-processing', 'wc-completed' ],
            'limit'      => -1,
            'product_id' => $event_id,
        ]);
        $is_single = false;
    }

    $invii = 0;
    $has_more = false;
    $mailer = WC()->mailer();
    $account_url = wc_get_page_permalink('myaccount');

    foreach ($orders as $order) {
        if (! $order) {
            continue;
        }

        // Se è un invio massivo e ha già ricevuto la mail, lo saltiamo
        if (! $is_single && $order->get_meta('_cv_reminder_sent') === 'yes') {
            continue;
        }

        // LIMITE ANTI-BLOCCO: Processiamo massimo 5 email per ogni chiamata AJAX
        if (! $is_single && $invii >= 5) {
            $has_more = true;
            break;
        }

        $email_cliente = $order->get_billing_email();
        $nome_cliente  = $order->get_billing_first_name();

        $hub_token = hash_hmac('sha256', $order->get_order_key() . '_hub', wp_salt('nonce'));
        $hub_url = site_url('/?cv_hub=1&order_id=' . $order->get_id() . '&token=' . $hub_token);

        ob_start();
        $email_heading = 'I tuoi biglietti digitali';
        wc_get_template('emails/email-header.php', [ 'email_heading' => $email_heading ]);

        // --- CORPO DELLA MAIL ---
        echo '<p>Ciao <strong>' . esc_html($nome_cliente) . '</strong>,</p>';
        echo '<p>Manca sempre meno al nostro evento! Ti scriviamo per ricordarti la tua prenotazione e per presentarti una bellissima novità del nostro portale.</p>';
        echo '<p>Abbiamo aggiornato il nostro sistema: ora puoi visualizzare, scaricare o inviare comodamente su WhatsApp i tuoi biglietti digitali (dotati di QR Code) per un accesso ancora più rapido all\'ingresso.</p>';

        echo '<div style="text-align: center; margin: 35px 0;">';
        echo '<a href="' . esc_url($hub_url) . '" style="background-color: #2271b1; color: #ffffff; padding: 16px 32px; font-size: 18px; font-weight: bold; text-decoration: none; border-radius: 8px; display: inline-block;">🎟️ MOSTRA I MIEI BIGLIETTI</a>';
        echo '</div>';

        echo '<h2 style="color: #2271b1; font-size: 20px; margin-top: 30px;">Il tuo Botteghino Personale</h2>';
        echo '<p>Abbiamo anche creato una nuova Area Riservata sul nostro sito. Accedendo con l\'email che hai usato per l\'acquisto (<strong>' . esc_html($email_cliente) . '</strong>), potrai entrare nel tuo "Botteghino Personale", ritrovare lo storico degli acquisti e avere i biglietti sempre a portata di mano.</p>';
        echo '<p><a href="' . esc_url($account_url) . '" style="color: #ff6600; font-weight: bold; text-decoration: underline;">Clicca qui per scoprire la tua Area Riservata</a></p>';

        echo '<p style="margin-top: 40px;">Ti aspettiamo!<br><em>Lo Staff della Delegazione FAI Novara</em></p>';
        // --- FINE CORPO DELLA MAIL ---

        wc_get_template('emails/email-footer.php');
        $message = ob_get_clean();

        $subject = 'I tuoi biglietti e una novità per te! 🎟️';

        $mailer->send($email_cliente, $subject, $message, [ 'Content-Type: text/html' ]);

        $nota = $is_single ? '📧 Reinviata email manuale SINGOLA di Reminder Biglietti.' : '📧 Inviata email manuale di Reminder Biglietti (Invio Massivo).';
        $order->add_order_note($nota);
        $order->update_meta_data('_cv_reminder_sent', 'yes');
        $order->save();

        $invii++;
    }

    wp_send_json_success([ 'sent' => $invii, 'has_more' => $has_more ]);
}

/**
 * 28. GESTIONE MANUALE LISTE DI ATTESA (BACKEND) CON SCONTO FAI E MAIL DI CONFERMA
 */
add_action('admin_menu', 'cv_aggiungi_pagina_liste_attesa');
function cv_aggiungi_pagina_liste_attesa()
{
    add_submenu_page(
        'woocommerce',
        'Liste di Attesa',
        '⏳ Liste di Attesa',
        'manage_woocommerce',
        'cv-liste-attesa',
        'cv_render_pagina_liste_attesa',
    );
}

function cv_render_pagina_liste_attesa()
{
    if (! current_user_can('manage_woocommerce')) {
        return;
    }

    $messaggio = '';
    $selected_event = isset($_REQUEST['event_id']) ? intval($_REQUEST['event_id']) : 0;
    $valore_sconto_singolo = 5; // Valore dello sconto per singola tessera FAI

    // --- LOGICA DI SALVATAGGIO NUOVO UTENTE IN CODA E INVIO MAIL ---
    if (isset($_POST['cv_add_waitlist_nonce']) && wp_verify_nonce($_POST['cv_add_waitlist_nonce'], 'cv_add_waitlist')) {
        $nome    = sanitize_text_field($_POST['wl_nome']);
        $cognome = sanitize_text_field($_POST['wl_cognome']);
        $email   = sanitize_email($_POST['wl_email']);
        $tel     = sanitize_text_field($_POST['wl_tel']);
        $qty     = intval($_POST['wl_qty']);
        $tessere = isset($_POST['wl_tessere']) ? intval($_POST['wl_tessere']) : 0;

        if (is_email($email) && $selected_event > 0 && $qty > 0) {
            // Controllo di sicurezza sulle tessere
            if ($tessere > $qty) {
                $tessere = $qty;
            }

            $waitlist = get_option('cv_waitlist_data', []);
            if (! isset($waitlist[ $selected_event ])) {
                $waitlist[ $selected_event ] = [];
            }

            // Aggiungiamo l'utente alla coda
            $waitlist[ $selected_event ][] = [
                'id'      => uniqid('wl_'),
                'nome'    => $nome,
                'cognome' => $cognome,
                'email'   => $email,
                'tel'     => $tel,
                'qty'     => $qty,
                'tessere' => $tessere,
                'date'    => current_time('mysql'),
            ];

            update_option('cv_waitlist_data', $waitlist);

            // --- INIZIO: INVIO MAIL DI CONFERMA INSERIMENTO IN LISTA D'ATTESA ---
            $product = wc_get_product($selected_event);
            $nome_evento = $product ? $product->get_name() : 'Evento';

            ob_start();
            $email_heading = 'Sei in Lista d\'Attesa';
            wc_get_template('emails/email-header.php', [ 'email_heading' => $email_heading ]);

            echo '<p>Ciao <strong>' . esc_html($nome) . '</strong>,</p>';
            echo '<p>Ti confermiamo di aver preso in carico la tua richiesta. Sei stato inserito ufficialmente nella lista d\'attesa per l\'evento <strong>' . esc_html($nome_evento) . '</strong>.</p>';
            echo '<p>Hai richiesto <strong>' . intval($qty) . ' bigliett' . ($qty == 1 ? 'o' : 'i') . '</strong>.</p>';

            echo '<h2 style="color: #2271b1; font-size: 20px; margin-top: 30px;">Cosa succede ora?</h2>';
            echo '<p>Nel caso in cui dovessero liberarsi i posti da te richiesti, ti invieremo immediatamente un\'altra email contenente il link per effettuare il pagamento.</p>';
            echo '<p style="color: #d63638; font-size: 16px; font-weight: bold; border-left: 4px solid #d63638; padding-left: 10px; margin-top: 20px;">Attenzione: dal momento in cui riceverai l\'eventuale link di pagamento, avrai un massimo di 24 ore di tempo per completare l\'acquisto, dopodiché i posti verranno riassegnati alla persona successiva in lista.</p>';

            echo '<p style="margin-top: 40px;">A presto!<br><em>Lo Staff della Delegazione FAI Novara</em></p>';

            wc_get_template('emails/email-footer.php');
            $message = ob_get_clean();

            $subject = 'Conferma inserimento in Lista d\'Attesa - ' . $nome_evento;
            WC()->mailer()->send($email, $subject, $message, [ 'Content-Type: text/html' ]);
            // --- FINE: INVIO MAIL DI CONFERMA ---

            $messaggio = '<div class="notice notice-success is-dismissible"><p>✅ <strong>' . esc_html($nome . ' ' . $cognome) . '</strong> aggiunto correttamente alla lista d\'attesa e <strong>mail di conferma inviata!</strong></p></div>';
        }
    }

    // --- LOGICA DI RIMOZIONE O PROMOZIONE A ORDINE ---
    if (isset($_POST['cv_action_waitlist_nonce']) && wp_verify_nonce($_POST['cv_action_waitlist_nonce'], 'cv_action_waitlist')) {
        $wl_id_to_action = sanitize_text_field($_POST['wl_id']);
        $action_type     = sanitize_text_field($_POST['wl_action']);

        $waitlist = get_option('cv_waitlist_data', []);

        if (isset($waitlist[ $selected_event ])) {
            foreach ($waitlist[ $selected_event ] as $index => $entry) {
                if ($entry['id'] === $wl_id_to_action) {

                    if ($action_type === 'delete') {
                        // Rimuove e basta
                        unset($waitlist[ $selected_event ][ $index ]);
                        $waitlist[ $selected_event ] = array_values($waitlist[ $selected_event ]); // re-indicizza
                        update_option('cv_waitlist_data', $waitlist);
                        $messaggio = '<div class="notice notice-warning is-dismissible"><p>🗑️ Utente rimosso dalla lista d\'attesa.</p></div>';
                    } elseif ($action_type === 'promote') {
                        // Promuove a vero ordine WooCommerce!
                        $order = wc_create_order();
                        $order->set_billing_first_name($entry['nome']);
                        $order->set_billing_last_name($entry['cognome']);
                        $order->set_billing_email($entry['email']);
                        $order->set_billing_phone($entry['tel']);

                        $product = wc_get_product($selected_event);
                        $order->add_product($product, $entry['qty']);

                        // --- APPLICAZIONE SCONTO FAI SE PRESENTE ---
                        $tessere_fai = isset($entry['tessere']) ? intval($entry['tessere']) : 0;
                        if ($tessere_fai > 0) {
                            $sconto_totale = $tessere_fai * $valore_sconto_singolo;
                            $fee = new WC_Order_Item_Fee();
                            $fee->set_name('Sconto Tessera FAI (' . $tessere_fai . ' validat' . ($tessere_fai == 1 ? 'a' : 'e') . ')');
                            $fee->set_amount(-$sconto_totale);
                            $fee->set_total(-$sconto_totale);
                            $order->add_item($fee);
                        }

                        $order->calculate_totals();
                        $order->update_status('pending', '⏳ Ordine generato automaticamente da Lista d\'Attesa.');

                        // Scala lo stock
                        wc_reduce_stock_levels($order->get_id());

                        // Invia la mail di pagamento
                        WC()->mailer()->get_emails()['WC_Email_Customer_Invoice']->trigger($order->get_id());
                        $order->add_order_note('📧 Inviato link di pagamento a ' . esc_html($entry['email']));

                        // Rimuove l'utente dalla lista d'attesa
                        unset($waitlist[ $selected_event ][ $index ]);
                        $waitlist[ $selected_event ] = array_values($waitlist[ $selected_event ]);
                        update_option('cv_waitlist_data', $waitlist);

                        $edit_url = method_exists($order, 'get_edit_order_url') ? $order->get_edit_order_url() : admin_url('post.php?post=' . $order->get_id() . '&action=edit');
                        $messaggio = '<div class="notice notice-success is-dismissible"><p>🎉 <strong>Successo!</strong> È stato creato l\'ordine <strong>#' . $order->get_id() . '</strong> e la mail con il link di pagamento è stata inviata a ' . esc_html($entry['email']) . '. <a href="' . esc_url($edit_url) . '">Visualizza Ordine</a></p></div>';
                    }
                    break;
                }
            }
        }
    }

    // --- INTERFACCIA GRAFICA ---
    $products = wc_get_products([ 'limit' => -1, 'status' => 'publish', 'return' => 'objects' ]);

    echo '<div class="wrap">';
    echo '<h1 class="wp-heading-inline">Gestione Liste di Attesa</h1>';
    echo '<p style="font-size:15px; color:#555;">Seleziona un evento per aggiungere clienti in coda o promuoverli a ordini veri e propri quando si liberano i posti.</p>';
    echo $messaggio;

    // Form di selezione evento
    echo '<form method="GET" style="margin:20px 0; background:#fff; padding:15px; border:1px solid #ccd0d4; border-radius:4px; display:inline-block;">';
    echo '<input type="hidden" name="page" value="cv-liste-attesa">';
    echo '<label style="font-weight:bold; margin-right:10px;">Seleziona l\'evento Sold Out:</label>';
    echo '<select name="event_id" style="min-width:300px;"><option value="">-- Scegli Evento --</option>';
    foreach ($products as $product) {
        echo '<option value="' . esc_attr($product->get_id()) . '" ' . selected($selected_event, $product->get_id(), false) . '>' . esc_html($product->get_name()) . '</option>';
    }
    echo '</select><button type="submit" class="button button-primary" style="margin-left:10px;">Gestisci Coda</button></form>';

    if ($selected_event > 0) {
        $product = wc_get_product($selected_event);
        $stock = $product->get_stock_quantity();
        $stock_text = ($stock > 0) ? '<span style="color:green; font-weight:bold;">' . $stock . ' posti liberi!</span>' : '<span style="color:#d63638; font-weight:bold;">0 posti liberi</span>';

        echo '<div style="display:flex; gap:20px; flex-wrap:wrap; align-items:flex-start;">';

        // Colonna Sinistra: Aggiungi
        echo '<div style="flex:1; min-width:300px; max-width:350px; background:#fff; border:1px solid #ccd0d4; padding:20px; border-radius:8px; box-shadow:0 2px 5px rgba(0,0,0,0.05);">';
        echo '<h3 style="margin-top:0; border-bottom:1px solid #eee; padding-bottom:10px;">➕ Aggiungi in Coda</h3>';
        echo '<form method="POST" action="">';
        wp_nonce_field('cv_add_waitlist', 'cv_add_waitlist_nonce');
        echo '<p><label>Nome:</label><br><input type="text" name="wl_nome" required style="width:100%;"></p>';
        echo '<p><label>Cognome:</label><br><input type="text" name="wl_cognome" style="width:100%;"></p>';
        echo '<p><label>Email *:</label><br><input type="email" name="wl_email" required style="width:100%;"></p>';
        echo '<p><label>Telefono:</label><br><input type="text" name="wl_tel" style="width:100%;"></p>';

        // Nuova struttura flessibile per Quantità e Tessere FAI
        echo '<div style="display: flex; gap: 15px;">';
        echo '<p style="flex: 1;"><label>Biglietti:</label><br><input type="number" name="wl_qty" id="wl_qty" value="1" min="1" required style="width:100%;"></p>';
        echo '<p style="flex: 1;"><label>Tessere FAI:</label><br><input type="number" name="wl_tessere" id="wl_tessere" value="0" min="0" style="width:100%;"></p>';
        echo '</div>';

        echo '<button type="submit" class="button button-primary" style="width:100%;">Inserisci in Lista d\'Attesa</button>';
        echo '</form>';

        // Script per evitare più tessere che biglietti
        echo '<script>
            jQuery(document).ready(function($){
                $("#wl_tessere").on("change", function(){
                    var max = parseInt($("#wl_qty").val());
                    if(parseInt(this.value) > max) this.value = max;
                });
                $("#wl_qty").on("change", function(){
                    var val = parseInt($("#wl_tessere").val());
                    if(val > parseInt(this.value)) $("#wl_tessere").val(this.value);
                });
            });
        </script>';
        echo '</div>';

        // Colonna Destra: La Coda
        echo '<div style="flex:3; min-width:500px; background:#fff; border:1px solid #ccd0d4; padding:20px; border-radius:8px; box-shadow:0 2px 5px rgba(0,0,0,0.05);">';
        echo '<h3 style="margin-top:0; border-bottom:1px solid #eee; padding-bottom:10px; display:flex; justify-content:space-between;">';
        echo '<span>👥 Persone in Coda</span> <span>Disponibilità attuale: ' . $stock_text . '</span></h3>';

        $waitlist_all = get_option('cv_waitlist_data', []);
        $coda_attuale = isset($waitlist_all[ $selected_event ]) ? $waitlist_all[ $selected_event ] : [];

        if (empty($coda_attuale)) {
            echo '<p style="color:#777; font-style:italic;">Nessuno in lista d\'attesa per questo evento.</p>';
        } else {
            echo '<table class="wp-list-table widefat fixed striped" style="margin-top:10px;">';
            echo '<thead><tr><th style="width:50px;">#</th><th>Data Richiesta</th><th>Cliente</th><th>Contatti</th><th>Biglietti</th><th style="text-align:right;">Azioni</th></tr></thead><tbody>';

            foreach ($coda_attuale as $index => $entry) {
                $pos = $index + 1;
                $data_req = date_i18n('d/m/Y H:i', strtotime($entry['date']));

                // Generazione badge FAI visivo in riga col numero biglietti (corretto <br>)
                $tessere_fai = isset($entry['tessere']) ? intval($entry['tessere']) : 0;
                $badge_fai = $tessere_fai > 0 ? '<span style="background:#ff6600; color:#fff; padding:3px 6px; border-radius:3px; font-size:10px; font-weight:bold; display:inline-block; margin-left:8px; vertical-align:middle;">' . $tessere_fai . ' FAI</span>' : '';

                echo '<tr>';
                echo '<td style="vertical-align:middle;"><strong>' . $pos . '°</strong></td>';
                echo '<td style="vertical-align:middle;">' . esc_html($data_req) . '</td>';
                echo '<td style="vertical-align:middle;"><strong>' . esc_html($entry['nome'] . ' ' . $entry['cognome']) . '</strong></td>';
                echo '<td style="vertical-align:middle;"><a href="mailto:' . esc_attr($entry['email']) . '">' . esc_html($entry['email']) . '</a><br><small>' . esc_html($entry['tel']) . '</small></td>';
                echo '<td style="vertical-align:middle;"><strong>' . esc_html($entry['qty']) . '</strong>' . $badge_fai . '</td>';

                // Colonna azioni sistemata con flexbox per tenere i bottoni in riga
                echo '<td style="text-align:right; vertical-align:middle;">';
                echo '<form method="POST" style="display:flex; justify-content:flex-end; gap:5px; margin:0;" onsubmit="return confirm(\'Confermi l\\\'operazione?\');">';
                wp_nonce_field('cv_action_waitlist', 'cv_action_waitlist_nonce');
                echo '<input type="hidden" name="wl_id" value="' . esc_attr($entry['id']) . '">';

                echo '<button type="submit" name="wl_action" value="promote" class="button" style="background:#2271b1; color:#fff; border-color:#2271b1;" title="Crea Ordine e Invia link di pagamento">🎟️ Promuovi</button>';
                echo '<button type="submit" name="wl_action" value="delete" class="button" style="color:#d63638; border-color:#d63638;" title="Rimuovi dalla lista">❌ Rimuovi</button>';
                echo '</form>';
                echo '</td></tr>';
            }
            echo '</tbody></table>';

            if ($stock > 0) {
                echo '<p style="margin-top:15px; color:#166534; background:#eaf7ea; padding:10px; border-radius:5px; border:1px solid #c3e6c3;">💡 <strong>Suggerimento:</strong> Ci sono posti liberi! Puoi cliccare su "Promuovi" per il primo della lista: il sistema creerà la sua prenotazione applicando gli sconti e gli invierà automaticamente la mail per pagare entro 24 ore.</p>';
            }
        }
        echo '</div></div>';
    }
    echo '</div>';
}

/**
 * 29. TRACCIAMENTO ATTIVITÀ UTENTE (Login, Registrazione, Accesso Biglietti)
 */

// 1. REGISTRA IL LOGIN
add_action('wp_login', 'cv_track_user_login', 10, 2);
function cv_track_user_login($user_login, $user)
{
    cv_aggiungi_log_utente($user->ID, '🔑 Login effettuato');
}

// 2. REGISTRA LA REGISTRAZIONE (E controlla se era già un cliente)
add_action('user_register', 'cv_track_user_registration', 10, 1);
function cv_track_user_registration($user_id)
{
    $user_info = get_userdata($user_id);
    $email = $user_info->user_email;

    // Controlliamo se esistono ordini passati con questa mail
    $ordini_passati = wc_get_orders(['billing_email' => $email, 'limit' => 1]);

    $messaggio = '🆕 Registrazione completata';
    if (!empty($ordini_passati)) {
        $messaggio .= ' (Riconosciuto come vecchio cliente FAI)';
    }

    cv_aggiungi_log_utente($user_id, $messaggio);
}

// 3. REGISTRA L'ACCESSO ALLA SEZIONE "I MIEI BIGLIETTI"
add_action('template_redirect', 'cv_track_access_tickets');
function cv_track_access_tickets()
{
    if (is_user_logged_in() && is_account_page() && is_wc_endpoint_url('orders')) {
        $user_id = get_current_user_id();

        // Usiamo un lucchetto di 1 ora per non loggare ogni singolo refresh di pagina
        $lock_key = 'cv_log_tickets_lock_' . $user_id;
        if (!get_transient($lock_key)) {
            cv_aggiungi_log_utente($user_id, '🎟️ Visualizzata sezione "I Miei Biglietti"');
            set_transient($lock_key, 1, HOUR_IN_SECONDS);
        }
    }
}

// FUNZIONE HELPER PER SCRIVERE IL LOG
function cv_aggiungi_log_utente($user_id, $azione)
{
    $log = get_user_meta($user_id, '_cv_user_activity_log', true);
    if (!is_array($log)) {
        $log = [];
    }

    $log[] = [
        'data'   => current_time('mysql'),
        'azione' => $azione,
        'ip'     => $_SERVER['REMOTE_ADDR'], // Opzionale: traccia anche l'IP per sicurezza
    ];

    // Teniamo solo gli ultimi 50 eventi per utente
    if (count($log) > 50) {
        $log = array_slice($log, -50);
    }

    update_user_meta($user_id, '_cv_user_activity_log', $log);
}

// 4. MOSTRA I LOG NEL PROFILO UTENTE (BACKEND)
add_action('show_user_profile', 'cv_mostra_log_nel_profilo');
add_action('edit_user_profile', 'cv_mostra_log_nel_profilo');
function cv_mostra_log_nel_profilo($user)
{
    $log = get_user_meta($user->ID, '_cv_user_activity_log', true);
    ?>
    <div style="margin-top: 30px; background: #fff; padding: 20px; border: 1px solid #ccd0d4; border-radius: 5px;">
        <h3>📜 Log Attività CandleVibes</h3>
        <?php if (empty($log)) : ?>
            <p>Nessuna attività registrata per questo utente.</p>
        <?php else :
            $log = array_reverse($log); // Mostra i più recenti in alto
            ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 180px;">Data e Ora</th>
                        <th>Azione</th>
                        <th style="width: 120px;">Indirizzo IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($log as $entry) : ?>
                        <tr>
                            <td><strong><?php echo date_i18n('d/m/Y - H:i:s', strtotime($entry['data'])); ?></strong></td>
                            <td><?php echo esc_html($entry['azione']); ?></td>
                            <td><small><?php echo esc_html($entry['ip']); ?></small></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * 30. CREAZIONE RUOLO "VERIFICATORE BIGLIETTI" E PERMESSI SCANNER
 */
add_action('admin_init', 'cv_crea_ruolo_operatore_scanner');
function cv_crea_ruolo_operatore_scanner()
{
    // 1. Aggiunge il nuovo ruolo limitato
    add_role(
        'cv_scanner',
        'Verificatore Biglietti',
        [
            'read' => true, // Permette solo di fare login e vedere la dashboard base
            'cv_use_scanner' => true, // La nostra chiave magica personalizzata
        ],
    );

    // 2. Diamo la chiave magica anche agli Amministratori
    $admin = get_role('administrator');
    if ($admin && ! $admin->has_cap('cv_use_scanner')) {
        $admin->add_cap('cv_use_scanner');
    }

    // 3. Diamo la chiave magica anche ai Gestori del Negozio
    $shop_manager = get_role('shop_manager');
    if ($shop_manager && ! $shop_manager->has_cap('cv_use_scanner')) {
        $shop_manager->add_cap('cv_use_scanner');
    }
}

/**
 * 31. GESTORE DOWNLOAD FORZATO DEL QR CODE (SALVATAGGIO IMMAGINE)
 */
add_action('template_redirect', 'cv_gestisci_download_qr');
function cv_gestisci_download_qr()
{
    if (isset($_GET['cv_download_qr']) && isset($_GET['order_id']) && isset($_GET['t']) && isset($_GET['token'])) {

        $order_id = intval($_GET['order_id']);
        $ticket_index = intval($_GET['t']);
        $token = sanitize_text_field($_GET['token']);

        $order = wc_get_order($order_id);
        if (! $order) {
            wp_die('Ordine non trovato.');
        }

        // Verifichiamo il token di sicurezza
        $expected_token = hash_hmac('sha256', $order->get_order_key() . '_ticket_' . $ticket_index, wp_salt('nonce'));
        if (! hash_equals($expected_token, $token)) {
            wp_die('Token di sicurezza non valido.', 'Errore Sicurezza');
        }

        // Generiamo il link del checkin
        $checkin_url = site_url('/?cv_checkin=1&order_id=' . $order_id . '&ticket=' . $ticket_index . '&token=' . $token);

        // Chiediamo all'API di generare il QR Code un po' più grande e definito per il download
        $qr_api_url = 'https://api.qrserver.com/v1/create-qr-code/?size=600x600&data=' . urlencode($checkin_url) . '&margin=20';

        // Scarichiamo l'immagine dall'API usando il server WordPress
        $response = wp_remote_get($qr_api_url, [ 'timeout' => 10 ]);

        if (is_wp_error($response)) {
            wp_die('Errore di connessione durante la generazione del file. Riprova tra poco.');
        }

        $image_data = wp_remote_retrieve_body($response);
        $content_type = wp_remote_retrieve_header($response, 'content-type');

        if (empty($image_data)) {
            wp_die('Impossibile scaricare il file in questo momento.');
        }

        // Forziamo il browser a scaricare il file impostando gli header corretti
        $filename = 'Biglietto-' . $order_id . '-Posto-' . $ticket_index . '.png';

        header('Content-Description: File Transfer');
        header('Content-Type: ' . $content_type);
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . strlen($image_data));

        // Sputiamo l'immagine pura al browser
        echo $image_data;
        exit;
    }
}

/**
 * 32. SBLOCCO BACKEND E REINDIRIZZAMENTO AUTOMATICO PER I VERIFICATORI
 */

// 1. Impedisce a WooCommerce di bloccare l'accesso al backend per i Verificatori
add_filter('woocommerce_prevent_admin_access', 'cv_sblocca_backend_verificatori', 20, 1);
function cv_sblocca_backend_verificatori($prevent_access)
{
    // Se l'utente ha la nostra chiave magica, gli apriamo i cancelli
    if (current_user_can('cv_use_scanner')) {
        return false;
    }
    return $prevent_access;
}

// 2. Reindirizza direttamente allo scanner al momento del login (se fa login dal sito / carrello)
add_filter('woocommerce_login_redirect', 'cv_redirect_scanner_wc', 99, 2);
function cv_redirect_scanner_wc($redirect, $user)
{
    if (is_a($user, 'WP_User') && in_array('cv_scanner', (array) $user->roles)) {
        return admin_url('admin.php?page=cv-scanner-live');
    }
    return $redirect;
}

// 3. Reindirizza direttamente allo scanner al momento del login (se fa login da /wp-admin)
add_filter('login_redirect', 'cv_redirect_scanner_wp', 99, 3);
function cv_redirect_scanner_wp($redirect_to, $request, $user)
{
    if (is_a($user, 'WP_User') && in_array('cv_scanner', (array) $user->roles)) {
        return admin_url('admin.php?page=cv-scanner-live');
    }
    return $redirect_to;
}
