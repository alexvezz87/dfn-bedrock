/**
 * DFN Mobile App & PWA Hub — JavaScript Controller
 * 
 * Gestisce la navigazione a schede (TabBar), il Service Worker PWA,
 * le azioni rapide AJAX sulla Dashboard, il Check-in mobile per evento,
 * l'invio email del biglietto e lo Scanner QR Code Automatico con Html5Qrcode.
 *
 * @package DFN_Theme
 * @since   2.1.5
 */

document.addEventListener('DOMContentLoaded', function () {
    const root = document.getElementById('dfn-mobile-app-root');
    if (!root) return;

    // Recupero Nonces e Config
    let nonces = {};
    try {
        nonces = JSON.parse(root.getAttribute('data-nonces') || '{}');
    } catch (e) {
        console.error('Errore parsing nonces:', e);
    }

    const ajaxUrl = typeof dfn_mobile_params !== 'undefined' ? dfn_mobile_params.ajax_url : '/wp-admin/admin-ajax.php';

    // -------------------------------------------------------------------
    // 0. GESTIONE TEMA GRAFICO (LIGHT DEFAULT / DARK)
    // -------------------------------------------------------------------
    const savedTheme = localStorage.getItem('dfn_mobile_theme') || 'light';
    root.setAttribute('data-theme', savedTheme);

    const themeSelect = document.getElementById('dfn-theme-toggle-select');
    if (themeSelect) {
        themeSelect.value = savedTheme;
        themeSelect.addEventListener('change', function () {
            const chosen = this.value;
            root.setAttribute('data-theme', chosen);
            localStorage.setItem('dfn_mobile_theme', chosen);
            showToast(chosen === 'dark' ? '🌙 Tema Scuro Attivato' : '☀️ Tema Chiaro Attivato', 'info');
        });
    }

    // -------------------------------------------------------------------
    // 1. REGISTRAZIONE SERVICE WORKER PWA & PROMPT INSTALLAZIONE
    // -------------------------------------------------------------------
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/app/themes/dfn-theme/sw.js')
            .then(reg => console.log('Service Worker DFN PWA registrato:', reg.scope))
            .catch(err => console.warn('Registrazione Service Worker fallita:', err));
    }

    let deferredPrompt = null;
    const installBtn = document.getElementById('dfn-pwa-install-btn');

    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        if (installBtn) {
            installBtn.style.display = 'inline-flex';
        }
    });

    if (installBtn) {
        installBtn.addEventListener('click', () => {
            if (!deferredPrompt) return;
            deferredPrompt.prompt();
            deferredPrompt.userChoice.then((choiceResult) => {
                if (choiceResult.outcome === 'accepted') {
                    showToast('App installata con successo!', 'success');
                }
                deferredPrompt = null;
                installBtn.style.display = 'none';
            });
        });
    }

    // -------------------------------------------------------------------
    // 2. UTILITY FEEDBACK (VIBRAZIONE & TOAST)
    // -------------------------------------------------------------------
    function showToast(message, type = 'info') {
        const toast = document.getElementById('dfn-mobile-toast');
        if (!toast) return;

        toast.textContent = message;
        toast.style.borderColor = type === 'success' ? '#10b981' : (type === 'error' ? '#ef4444' : '#0284c7');
        toast.style.display = 'block';

        setTimeout(() => {
            toast.style.display = 'none';
        }, 3000);
    }

    function vibrate(pattern = 50) {
        if ('vibrate' in navigator) {
            try { navigator.vibrate(pattern); } catch (e) {}
        }
    }

    // Refresh Button
    const refreshBtn = document.getElementById('dfn-mobile-refresh-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => {
            vibrate(40);
            showToast('Aggiornamento dati in corso...', 'info');
            setTimeout(() => window.location.reload(), 400);
        });
    }

    // -------------------------------------------------------------------
    // 3. NAVIGAZIONE TABBAR MOBILE
    // -------------------------------------------------------------------
    const tabBtns = document.querySelectorAll('.dfn-tab-btn');
    const tabPanes = document.querySelectorAll('.dfn-mobile-tab-pane');

    function switchTab(tabId) {
        tabBtns.forEach(btn => {
            if (btn.getAttribute('data-tab') === tabId) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });

        tabPanes.forEach(pane => {
            if (pane.id === 'dfn-tab-' + tabId) {
                pane.classList.add('active');
            } else {
                pane.classList.remove('active');
            }
        });

        window.scrollTo({ top: 0, behavior: 'smooth' });

        if (tabId === 'scanner') {
            startHtml5Scanner();
        } else {
            stopHtml5Scanner();
        }
    }

    tabBtns.forEach(btn => {
        btn.addEventListener('click', function () {
            const targetTab = this.getAttribute('data-tab');
            switchTab(targetTab);
            vibrate(30);
        });
    });

    document.querySelectorAll('[data-target-tab]').forEach(elem => {
        elem.addEventListener('click', function () {
            const targetTab = this.getAttribute('data-target-tab');
            const scrollToId = this.getAttribute('data-scroll-to');
            switchTab(targetTab);

            if (scrollToId) {
                setTimeout(() => {
                    const el = document.getElementById(scrollToId);
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                }, 200);
            }
        });
    });

    // -------------------------------------------------------------------
    // 4. SCANNER QR CODE AUTOMATICO (Html5Qrcode Engine)
    // -------------------------------------------------------------------
    let html5QrScanner = null;
    let isScanningActive = false;
    let isProcessingScan = false;

    function startHtml5Scanner() {
        if (isScanningActive || typeof Html5Qrcode === 'undefined') return;

        const readerElem = document.getElementById('dfn-mobile-qr-reader');
        if (!readerElem) return;

        try {
            html5QrScanner = new Html5Qrcode("dfn-mobile-qr-reader");
            isScanningActive = true;

            html5QrScanner.start(
                { facingMode: "environment" },
                { fps: 10, qrbox: { width: 200, height: 200 } },
                onQrScanSuccess,
                onQrScanError
            ).catch(err => {
                console.warn('Errore avvio fotocamera scanner:', err);
                showToast('Impossibile accedere alla fotocamera.', 'info');
                isScanningActive = false;
            });
        } catch (e) {
            console.error('Errore inizializzazione Html5Qrcode:', e);
        }
    }

    function stopHtml5Scanner() {
        if (html5QrScanner && isScanningActive) {
            html5QrScanner.stop().then(() => {
                html5QrScanner.clear();
                isScanningActive = false;
            }).catch(err => {
                isScanningActive = false;
            });
        }
    }

    function onQrScanSuccess(decodedText, decodedResult) {
        if (isProcessingScan) return;
        isProcessingScan = true;

        vibrate([100, 50, 100]);
        checkInToken(decodedText, function() {
            setTimeout(() => {
                isProcessingScan = false;
            }, 2500);
        });
    }

    function onQrScanError(errorMessage) {
        // Ignora gli errori di frame intermedi senza QR
    }

    function checkInToken(token, callback) {
        if (!token) return;

        const resultBox = document.getElementById('dfn-scanner-result-box');
        if (resultBox) {
            resultBox.style.display = 'block';
            resultBox.className = 'dfn-scanner-result-box';
            resultBox.innerHTML = '<div style="text-align:center; padding:12px;">⏳ <strong>Verifica in corso...</strong></div>';
        }

        const formData = new FormData();
        formData.append('action', 'dfn_process_scan');
        formData.append('qr_token', token);
        formData.append('security', nonces.scanner || '');

        fetch(ajaxUrl, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    const data = res.data;

                    // CASO 1: Pagamento in loco richiesto
                    if (data.payment_required) {
                        vibrate([200, 100, 200]);
                        if (resultBox) {
                            resultBox.className = 'dfn-scanner-result-box warning';
                            resultBox.innerHTML = `
                                <div class="dfn-scan-card warning">
                                    <span class="dfn-scan-badge warning">💶 PAGAMENTO IN LOCO RICHIESTO</span>
                                    <h4>${data.customer_name}</h4>
                                    <p>📅 ${data.event_title}</p>
                                    <p>👥 <strong>${data.total_persons} Persone</strong> (Interi: ${data.persons_standard}, FAI: ${data.persons_fai})</p>
                                    <div class="dfn-scan-amount-due">Quota da versare: <strong>${data.amount_due_formatted}</strong></div>
                                    <button type="button" class="dfn-mobile-btn success large btn-collect-in-loco" style="margin-top:10px;">
                                        💶 Incassa & Valida Check-in
                                    </button>
                                </div>
                            `;

                            resultBox.querySelector('.btn-collect-in-loco').addEventListener('click', function() {
                                this.disabled = true;
                                this.textContent = 'Registrazione incasso...';
                                consolidatePayment(token, resultBox);
                            });
                        }
                        showToast('💶 Pagamento in loco necessario', 'info');
                    } 
                    // CASO 2: Già entrato in precedenza
                    else if (data.status === 'checked_in') {
                        vibrate([150, 100, 150]);
                        if (resultBox) {
                            resultBox.className = 'dfn-scanner-result-box info';
                            resultBox.innerHTML = `
                                <div class="dfn-scan-card info">
                                    <span class="dfn-scan-badge info">ℹ️ GIÀ CONVALIDATO</span>
                                    <h4>${data.customer_name}</h4>
                                    <p>👥 ${data.total_persons} Persone</p>
                                    <p>⏰ Entrato il: <strong>${data.checked_in_at}</strong> (${data.checked_in_by || 'Staff'})</p>
                                </div>
                            `;
                        }
                        showToast('ℹ️ Biglietto già validato', 'info');
                    } 
                    // CASO 3: Check-in confermato con successo (pagato online / omaggio)
                    else {
                        vibrate([100, 50, 100]);
                        if (resultBox) {
                            resultBox.className = 'dfn-scanner-result-box success';
                            resultBox.innerHTML = `
                                <div class="dfn-scan-card success">
                                    <span class="dfn-scan-badge success">✅ CHECK-IN VALIDATO!</span>
                                    <h4>${data.customer_name || 'Biglietto Valido'}</h4>
                                    <p>📅 ${data.event_title || ''}</p>
                                    <p>👥 <strong>${data.total_persons || 1} Persone</strong> — Stato: Pagato</p>
                                </div>
                            `;
                        }
                        showToast('✅ Check-in effettuato!', 'success');
                    }
                } else {
                    vibrate([200, 100, 200]);
                    const msg = (res.data && res.data.message) ? res.data.message : (res.data || 'Codice non riconosciuto.');
                    if (resultBox) {
                        resultBox.className = 'dfn-scanner-result-box error';
                        resultBox.innerHTML = `
                            <div class="dfn-scan-card danger">
                                <span class="dfn-scan-badge danger">❌ QR NON VALIDO</span>
                                <p style="margin-top:6px;">${msg}</p>
                            </div>
                        `;
                    }
                    showToast('❌ Codice non valido', 'error');
                }
                if (callback) callback();
            })
            .catch(() => {
                if (resultBox) {
                    resultBox.className = 'dfn-scanner-result-box error';
                    resultBox.innerHTML = '<div class="dfn-scan-card danger">⚠️ Errore di connessione col server.</div>';
                }
                if (callback) callback();
            });
    }

    function consolidatePayment(token, resultBox) {
        const formData = new FormData();
        formData.append('action', 'dfn_consolidate_in_loco_payment');
        formData.append('qr_token', token);
        formData.append('security', nonces.scanner || '');

        fetch(ajaxUrl, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    vibrate([100, 50, 100]);
                    if (resultBox) {
                        resultBox.className = 'dfn-scanner-result-box success';
                        resultBox.innerHTML = `
                            <div class="dfn-scan-card success">
                                <span class="dfn-scan-badge success">✅ INCASSO & CHECK-IN COMPLETATI!</span>
                                <h4>${res.data.customer_name || 'Acquirente'}</h4>
                                <p>💶 Pagamento registrato in loco con successo.</p>
                            </div>
                        `;
                    }
                    showToast('✅ Incasso completato!', 'success');
                } else {
                    showToast('⚠️ Errore incasso: ' + (res.data ? res.data.message : ''), 'error');
                }
            });
    }

    // -------------------------------------------------------------------
    // 5. CHECK-IN MOBILE PER EVENTO & MODALE
    // -------------------------------------------------------------------
    const checkinModal = document.getElementById('dfn-mobile-checkin-modal');
    const closeCheckinBtn = document.getElementById('dfn-btn-close-checkin-modal');
    const checkinSearchInput = document.getElementById('dfn-mci-search-input');
    const checkinBookingsList = document.getElementById('dfn-mci-bookings-list');

    let currentEventCheckinData = null;

    if (closeCheckinBtn && checkinModal) {
        closeCheckinBtn.addEventListener('click', () => {
            checkinModal.style.display = 'none';
        });
    }

    document.querySelectorAll('.btn-open-checkin-event').forEach(btn => {
        btn.addEventListener('click', function () {
            const eventId = this.getAttribute('data-event-id');
            openEventCheckinModal(eventId);
        });
    });

    function openEventCheckinModal(eventId) {
        if (!checkinModal) return;

        checkinModal.style.display = 'flex';
        checkinBookingsList.innerHTML = '<p style="text-align:center; padding:20px; color:#64748b;">Caricamento lista prenotazioni...</p>';

        const formData = new FormData();
        formData.append('action', 'dfn_mobile_get_event_checkin_list');
        formData.append('event_id', eventId);
        formData.append('nonce', nonces.admin || '');

        fetch(ajaxUrl, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    currentEventCheckinData = res.data;
                    renderCheckinModalData(currentEventCheckinData, '');
                } else {
                    checkinBookingsList.innerHTML = '<p style="text-align:center; padding:20px; color:#ef4444;">Erroe: ' + (res.data || 'Impossibile caricare') + '</p>';
                }
            })
            .catch(() => {
                checkinBookingsList.innerHTML = '<p style="text-align:center; padding:20px; color:#ef4444;">Errore di connessione di rete.</p>';
            });
    }

    function renderCheckinModalData(data, filterQuery = '') {
        document.getElementById('dfn-mci-event-title').textContent = data.event_title;
        document.getElementById('dfn-mci-event-subtitle').textContent = '📅 ' + data.event_date + ' • ⏰ ' + data.event_time;

        document.getElementById('dfn-mci-stat-booked').textContent = data.total_booked;
        document.getElementById('dfn-mci-stat-checked').textContent = data.total_checked_in;
        document.getElementById('dfn-mci-stat-remaining').textContent = data.total_remaining;

        const pct = data.total_booked > 0 ? Math.min(100, Math.round((data.total_checked_in / data.total_booked) * 100)) : 0;
        document.getElementById('dfn-mci-progress-fill').style.width = pct + '%';

        const query = filterQuery.toLowerCase().trim();
        const filtered = data.bookings.filter(b => {
            if (!query) return true;
            return b.customer_name.toLowerCase().includes(query) ||
                   b.customer_email.toLowerCase().includes(query) ||
                   b.customer_phone.toLowerCase().includes(query) ||
                   b.qr_token.toLowerCase().includes(query);
        });

        if (filtered.length === 0) {
            checkinBookingsList.innerHTML = '<p style="text-align:center; padding:20px; color:#64748b;">Nessuna prenotazione trovata.</p>';
            return;
        }

        let html = '';
        filtered.forEach(b => {
            const statusClass = b.checked_in ? 'success' : 'pending';
            const statusLabel = b.checked_in ? '✅ Entrato (' + b.checked_in_time + ')' : '⏳ In Attesa';

            html += `
                <div class="dfn-mobile-card dfn-mci-booking-card" id="dfn-mci-card-${b.id}">
                    <div class="dfn-booking-card-header">
                        <strong class="dfn-customer-name">${b.customer_name}</strong>
                        <span class="dfn-event-status-pill ${statusClass}">${statusLabel}</span>
                    </div>
                    <div class="dfn-booking-details">
                        <p>📧 ${b.customer_email}</p>
                        ${b.customer_phone ? '<p>📞 ' + b.customer_phone + '</p>' : ''}
                        <p>👥 <strong>${b.total_persons} Persone</strong> (Interi: ${b.persons_std}, FAI: ${b.persons_fai})</p>
                    </div>
                    <div class="dfn-booking-actions 2-col" style="display:grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top:10px;">
                        <button type="button" class="dfn-mobile-btn ${b.checked_in ? 'secondary' : 'success'} btn-mci-do-checkin" data-booking-id="${b.id}" data-token="${b.qr_token}">
                            ${b.checked_in ? '✓ Già Entrato' : '✅ Check-in'}
                        </button>
                        <button type="button" class="dfn-mobile-btn secondary btn-mci-resend-email" data-booking-id="${b.id}">
                            ✉️ Invia Email
                        </button>
                    </div>
                </div>
            `;
        });

        checkinBookingsList.innerHTML = html;

        // Binding azioni della modale
        checkinBookingsList.querySelectorAll('.btn-mci-do-checkin').forEach(btn => {
            btn.addEventListener('click', function () {
                const token = this.getAttribute('data-token');
                btn.disabled = true;
                btn.textContent = 'Check-in...';

                checkInToken(token, function() {
                    btn.textContent = '✓ Già Entrato';
                    btn.className = 'dfn-mobile-btn secondary btn-mci-do-checkin';
                });
            });
        });

        checkinBookingsList.querySelectorAll('.btn-mci-resend-email').forEach(btn => {
            btn.addEventListener('click', function () {
                const bookingId = this.getAttribute('data-booking-id');
                btn.disabled = true;
                btn.textContent = 'Invio email...';

                const formData = new FormData();
                formData.append('action', 'dfn_mobile_resend_ticket_email');
                formData.append('booking_id', bookingId);
                formData.append('nonce', nonces.booking || '');

                fetch(ajaxUrl, { method: 'POST', body: formData })
                    .then(r => r.json())
                    .then(res => {
                        if (res.success) {
                            vibrate([100, 50, 100]);
                            showToast('✉️ Email inviata al cliente!', 'success');
                        } else {
                            showToast('⚠️ Errore: ' + (res.data || 'Impossibile inviare'), 'error');
                        }
                        btn.disabled = false;
                        btn.textContent = '✉️ Invia Email';
                    })
                    .catch(() => {
                        showToast('⚠️ Errore di connessione', 'error');
                        btn.disabled = false;
                        btn.textContent = '✉️ Invia Email';
                    });
            });
        });
    }

    if (checkinSearchInput) {
        checkinSearchInput.addEventListener('input', function () {
            if (currentEventCheckinData) {
                renderCheckinModalData(currentEventCheckinData, this.value);
            }
        });
    }

    // -------------------------------------------------------------------
    // 6. AZIONI DASHBOARD HOME (AZIONI RAPIDE 1-TAP)
    // -------------------------------------------------------------------

    // A. Conferma Prenotazione Pendente
    document.querySelectorAll('.btn-confirm-booking').forEach(btn => {
        btn.addEventListener('click', function () {
            const bookingId = this.getAttribute('data-booking-id');
            const cardItem = document.getElementById('dfn-booking-card-' + bookingId);

            if (!confirm('Vuoi confermare definitivamente questa prenotazione?')) return;

            btn.disabled = true;
            btn.textContent = 'Conferma in corso...';

            const formData = new FormData();
            formData.append('action', 'dfn_confirm_booking');
            formData.append('booking_id', bookingId);
            formData.append('nonce', nonces.booking || '');

            fetch(ajaxUrl, { method: 'POST', body: formData })
                .then(r => r.json())
                .then(res => {
                    if (res.success) {
                        vibrate([50, 50, 100]);
                        showToast('✅ Prenotazione confermata!', 'success');
                        if (cardItem) {
                            cardItem.style.opacity = '0';
                            setTimeout(() => cardItem.remove(), 300);
                        }
                    } else {
                        showToast('⚠️ Errore: ' + (res.data || 'Impossibile confermare'), 'error');
                        btn.disabled = false;
                        btn.textContent = '✅ Conferma subito';
                    }
                })
                .catch(() => {
                    showToast('⚠️ Errore di connessione', 'error');
                    btn.disabled = false;
                    btn.textContent = '✅ Conferma subito';
                });
        });
    });

    // B. Valida Tessera FAI al volo
    document.querySelectorAll('.btn-validate-fai').forEach(btn => {
        btn.addEventListener('click', function () {
            const faiId = this.getAttribute('data-fai-id');
            const cardItem = document.getElementById('dfn-fai-card-' + faiId);

            btn.disabled = true;
            btn.textContent = 'Validazione...';

            const formData = new FormData();
            formData.append('action', 'dfn_verify_fai_member');
            formData.append('member_id', faiId);
            formData.append('nonce', nonces.fai || nonces.admin || '');

            fetch(ajaxUrl, { method: 'POST', body: formData })
                .then(r => r.json())
                .then(res => {
                    if (res.success) {
                        vibrate([100, 50, 100]);
                        showToast('🪪 Tessera FAI verificata!', 'success');
                        if (cardItem) {
                            cardItem.style.opacity = '0';
                            setTimeout(() => cardItem.remove(), 300);
                        }
                    } else {
                        showToast('⚠️ Errore: ' + (res.data || 'Impossibile verificare'), 'error');
                        btn.disabled = false;
                        btn.textContent = '🪪 Valida Tessera';
                    }
                })
                .catch(() => {
                    showToast('⚠️ Errore di connessione', 'error');
                    btn.disabled = false;
                    btn.textContent = '🪪 Valida Tessera';
                });
        });
    });

    // C. Collegamento Evento → Inserimento Rapido & Botteghino
    document.querySelectorAll('.btn-quick-book-event').forEach(btn => {
        btn.addEventListener('click', function () {
            const eventId = this.getAttribute('data-event-id');
            const select = document.getElementById('dfn-m-qb-event') || document.getElementById('dfn-qb-event');
            if (select) {
                select.value = eventId;
                select.dispatchEvent(new Event('change'));
            }
            switchTab('quick');
        });
    });

    document.querySelectorAll('.btn-botteghino-event').forEach(btn => {
        btn.addEventListener('click', function () {
            const eventId = this.getAttribute('data-event-id');
            const select = document.getElementById('dfn-bot-event');
            if (select) select.value = eventId;
            switchTab('botteghino');
        });
    });

    // -------------------------------------------------------------------
    // 7. INSERIMENTO RAPIDO (MOBILE APP) — CASCADE & SUBMIT
    // -------------------------------------------------------------------
    const mQbEventSel    = document.getElementById('dfn-m-qb-event');
    const mQbDateSel     = document.getElementById('dfn-m-qb-date');
    const mQbDateWrap    = document.getElementById('dfn-m-qb-date-wrap');
    const mQbSlotSel     = document.getElementById('dfn-m-qb-slot');
    const mQbSlotWrap    = document.getElementById('dfn-m-qb-slot-wrap');
    const mQbGuestWrap   = document.getElementById('dfn-m-qb-guest-wrap');
    const mQbQtyFaiInput = document.getElementById('dfn-m-qb-qty-fai');
    const mQbFaiCardsWrap= document.getElementById('dfn-m-qb-fai-cards-wrap');
    const mQbFaiCardsList= document.getElementById('dfn-m-qb-fai-cards-list');

    if (mQbEventSel) {
        mQbEventSel.addEventListener('change', function () {
            const evId = parseInt(this.value, 10);
            if (mQbDateWrap) mQbDateWrap.style.display = 'none';
            if (mQbSlotWrap) mQbSlotWrap.style.display = 'none';
            if (mQbGuestWrap) mQbGuestWrap.style.display = 'none';
            if (mQbDateSel) mQbDateSel.innerHTML = '<option value="">— Seleziona una data —</option>';

            if (!evId) return;

            if (mQbDateWrap) mQbDateWrap.style.display = 'block';
            if (mQbDateSel) {
                mQbDateSel.disabled = true;
                mQbDateSel.innerHTML = '<option value="">⏳ Caricamento date…</option>';
            }

            const fd = new FormData();
            fd.append('action', 'dfn_quick_get_dates');
            fd.append('nonce', nonces.admin || nonces.booking || '');
            fd.append('event_id', evId);

            fetch(ajaxUrl, { method: 'POST', body: fd })
                .then(r => r.json())
                .then(res => {
                    if (res.success && res.data.dates && res.data.dates.length > 0) {
                        let html = res.data.dates.length > 1 ? '<option value="">— Seleziona una data —</option>' : '';
                        res.data.dates.forEach(d => {
                            const p = d.split('-');
                            const fmt = p.length === 3 ? `${p[2]}/${p[1]}/${p[0]}` : d;
                            html += `<option value="${d}">${fmt}</option>`;
                        });
                        if (mQbDateSel) {
                            mQbDateSel.innerHTML = html;
                            mQbDateSel.disabled = false;
                            if (res.data.dates.length === 1) {
                                mQbDateSel.value = res.data.dates[0];
                                mQbDateSel.dispatchEvent(new Event('change'));
                            }
                        }
                    } else if (mQbDateSel) {
                        mQbDateSel.innerHTML = '<option value="">Nessuna data disponibile</option>';
                    }
                })
                .catch(() => {
                    if (mQbDateSel) mQbDateSel.innerHTML = '<option value="">Errore caricamento date</option>';
                });
        });
    }

    if (mQbDateSel) {
        mQbDateSel.addEventListener('change', function () {
            const date = this.value;
            const evId = mQbEventSel ? parseInt(mQbEventSel.value, 10) : 0;
            const selectedOpt = mQbEventSel ? mQbEventSel.options[mQbEventSel.selectedIndex] : null;
            const accessType = selectedOpt ? selectedOpt.getAttribute('data-access') : 'time_slots';

            if (mQbSlotWrap) mQbSlotWrap.style.display = 'none';
            if (mQbGuestWrap) mQbGuestWrap.style.display = 'none';

            if (!date || !evId) return;

            if (accessType === 'free_flow') {
                if (mQbGuestWrap) mQbGuestWrap.style.display = 'block';
                return;
            }

            if (mQbSlotWrap) mQbSlotWrap.style.display = 'block';
            if (mQbSlotSel) {
                mQbSlotSel.disabled = true;
                mQbSlotSel.innerHTML = '<option value="0">⏳ Caricamento turni…</option>';
            }

            const fd = new FormData();
            fd.append('action', 'dfn_quick_get_slots');
            fd.append('nonce', nonces.admin || nonces.booking || '');
            fd.append('event_id', evId);
            fd.append('date', date);

            fetch(ajaxUrl, { method: 'POST', body: fd })
                .then(r => r.json())
                .then(res => {
                    let html = '<option value="0">🤖 Auto — Smistamento automatico</option>';
                    if (res.success && res.data.slots && res.data.slots.length > 0) {
                        res.data.slots.forEach(s => {
                            const locked = s.is_locked;
                            const avail = s.available;
                            const icon = locked ? '🔒' : (avail === 0 ? '🔴' : avail <= 3 ? '🟡' : '🟢');
                            const label = locked ? `${s.time_start} → ${s.time_end} ${icon} Bloccato` : `${s.time_start} → ${s.time_end} ${icon} ${avail} liberi`;
                            html += `<option value="${s.id}" ${locked || avail === 0 ? 'disabled' : ''}>${label}</option>`;
                        });
                    }
                    if (mQbSlotSel) {
                        mQbSlotSel.innerHTML = html;
                        mQbSlotSel.disabled = false;
                    }
                    if (mQbGuestWrap) mQbGuestWrap.style.display = 'block';
                })
                .catch(() => {
                    if (mQbSlotSel) {
                        mQbSlotSel.innerHTML = '<option value="0">🤖 Auto — Smistamento automatico</option>';
                        mQbSlotSel.disabled = false;
                    }
                    if (mQbGuestWrap) mQbGuestWrap.style.display = 'block';
                });
        });
    }

    if (mQbQtyFaiInput) {
        mQbQtyFaiInput.addEventListener('input', function () {
            const qty = parseInt(this.value, 10) || 0;
            if (!mQbFaiCardsWrap || !mQbFaiCardsList) return;
            if (qty <= 0) {
                mQbFaiCardsWrap.style.display = 'none';
                mQbFaiCardsList.innerHTML = '';
                return;
            }
            mQbFaiCardsWrap.style.display = 'block';
            let html = '';
            for (let i = 0; i < qty; i++) {
                html += `
                    <div class="dfn-m-fai-card" style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:10px; margin-bottom:8px;">
                        <div style="font-size:12px; font-weight:700; color:#004b23; margin-bottom:6px;">Socio FAI #${i + 1}</div>
                        <div style="display:flex; gap:8px; margin-bottom:6px;">
                            <input type="text" name="fai_cards[${i}][cognome]" placeholder="Cognome" style="flex:1; padding:6px 10px; font-size:13px; border:1px solid #cbd5e1; border-radius:6px;" />
                            <input type="text" name="fai_cards[${i}][nome]" placeholder="Nome" style="flex:1; padding:6px 10px; font-size:13px; border:1px solid #cbd5e1; border-radius:6px;" />
                        </div>
                        <input type="text" name="fai_cards[${i}][tessera]" placeholder="N° Tessera FAI" style="width:100%; padding:6px 10px; font-size:13px; border:1px solid #cbd5e1; border-radius:6px;" />
                    </div>
                `;
            }
            mQbFaiCardsList.innerHTML = html;
        });
    }

    const quickForm = document.getElementById('dfn-mobile-quick-booking-form');
    if (quickForm) {
        quickForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const lastName = document.getElementById('dfn-m-qb-lastname')?.value.trim();
            if (!lastName) {
                showToast('⚠️ Il cognome è obbligatorio.', 'error');
                return;
            }

            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.textContent = 'Salvataggio in corso...';

            const formData = new FormData(this);
            formData.append('action', 'dfn_admin_add_booking');
            formData.append('nonce', nonces.admin || nonces.booking || '');

            fetch(ajaxUrl, { method: 'POST', body: formData })
                .then(r => r.json())
                .then(res => {
                    if (res.success) {
                        vibrate([100, 50, 100]);
                        showToast('⚡ Prenotazione creata con successo!', 'success');
                        quickForm.reset();
                        if (mQbDateWrap) mQbDateWrap.style.display = 'none';
                        if (mQbSlotWrap) mQbSlotWrap.style.display = 'none';
                        if (mQbGuestWrap) mQbGuestWrap.style.display = 'none';
                        switchTab('home');
                    } else {
                        showToast('⚠️ Errore: ' + (res.data?.message || res.data || 'Impossibile registrare'), 'error');
                    }
                    submitBtn.disabled = false;
                    submitBtn.textContent = '✅ Salva e Conferma Prenotazione';
                })
                .catch(() => {
                    showToast('⚠️ Errore di rete', 'error');
                    submitBtn.disabled = false;
                    submitBtn.textContent = '✅ Salva e Conferma Prenotazione';
                });
        });
    }

    const botteghinoForm = document.getElementById('dfn-mobile-botteghino-form');
    if (botteghinoForm) {
        botteghinoForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.textContent = 'Emissione biglietto...';

            const formData = new FormData(this);
            formData.append('action', 'dfn_process_quick_booking');
            formData.append('nonce', nonces.booking || nonces.admin || '');
            formData.append('is_botteghino', '1');

            fetch(ajaxUrl, { method: 'POST', body: formData })
                .then(r => r.json())
                .then(res => {
                    if (res.success) {
                        vibrate([100, 100, 100]);
                        showToast('💶 Biglietto emesso e incasso registrato!', 'success');
                        botteghinoForm.reset();
                        switchTab('home');
                    } else {
                        showToast('⚠️ Errore: ' + (res.data || 'Impossibile completare incasso'), 'error');
                    }
                    submitBtn.disabled = false;
                    submitBtn.textContent = '💶 Emetti Biglietto & Registra Incasso';
                })
                .catch(() => {
                    showToast('⚠️ Errore di rete', 'error');
                    submitBtn.disabled = false;
                    submitBtn.textContent = '💶 Emetti Biglietto & Registra Incasso';
                });
        });
    }
});
